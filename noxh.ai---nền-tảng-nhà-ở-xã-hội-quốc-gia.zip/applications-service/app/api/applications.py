from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from ..db.session import get_db
from ..models import models
from ..schemas import schemas
from .deps import RoleChecker, get_current_user_payload
from ..rabbitmq import publish_application_event

router = APIRouter()

def update_status(db: Session, application: models.Application, new_status: str, user_id: int, comment: str = None):
    old_status = application.status
    application.status = new_status
    
    history = models.ApplicationStatusHistory(
        application_id=application.id,
        from_status=old_status,
        to_status=new_status,
        changed_by=user_id,
        comment=comment
    )
    db.add(history)
    db.commit()
    
    # Publish event for specific status changes
    if new_status in ["SUBMITTED", "APPROVED", "REJECTED"]:
        publish_application_event(f"APPLICATION_{new_status}", application.id, application.customer_id, new_status)

@router.post("/", response_model=schemas.ApplicationResponse, dependencies=[Depends(RoleChecker(["customer"]))])
def create_application(
    app_in: schemas.ApplicationCreate,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    application = models.Application(
        customer_id=user.sub,
        sale_batch_id=app_in.sale_batch_id,
        data=app_in.data
    )
    db.add(application)
    db.commit()
    db.refresh(application)
    return application

@router.patch("/{id}", response_model=schemas.ApplicationResponse, dependencies=[Depends(RoleChecker(["customer"]))])
def update_application(
    id: int,
    app_in: schemas.ApplicationUpdate,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    application = db.query(models.Application).filter(models.Application.id == id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    if application.customer_id != user.sub:
        raise HTTPException(status_code=403, detail="Not your application")
    if application.status != "DRAFT":
        raise HTTPException(status_code=400, detail="Can only update DRAFT applications")

    if app_in.data is not None:
        application.data = app_in.data
    
    db.commit()
    db.refresh(application)
    return application

@router.post("/{id}/submit", response_model=schemas.ApplicationResponse, dependencies=[Depends(RoleChecker(["customer"]))])
def submit_application(
    id: int,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    application = db.query(models.Application).filter(models.Application.id == id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    if application.customer_id != user.sub:
        raise HTTPException(status_code=403, detail="Not your application")
    
    update_status(db, application, "SUBMITTED", user.sub)
    return application

@router.post("/{id}/approve", response_model=schemas.ApplicationResponse, dependencies=[Depends(RoleChecker(["developer", "admin"]))])
def approve_application(
    id: int,
    status_in: schemas.ApplicationStatusUpdate,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    application = db.query(models.Application).filter(models.Application.id == id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    
    update_status(db, application, "APPROVED", user.sub, status_in.comment)
    return application

@router.post("/{id}/reject", response_model=schemas.ApplicationResponse, dependencies=[Depends(RoleChecker(["developer", "admin"]))])
def reject_application(
    id: int,
    status_in: schemas.ApplicationStatusUpdate,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    application = db.query(models.Application).filter(models.Application.id == id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    
    update_status(db, application, "REJECTED", user.sub, status_in.comment)
    return application

@router.get("/{id}", response_model=schemas.ApplicationResponse)
def get_application(
    id: int,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    application = db.query(models.Application).filter(models.Application.id == id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    
    # Access control: customer can only see their own, developer/admin can see all
    if "admin" not in user.roles and "developer" not in user.roles:
        if application.customer_id != user.sub:
            raise HTTPException(status_code=403, detail="Access denied")
            
    return application

@router.get("/", response_model=List[schemas.ApplicationResponse])
def list_applications(
    mine: bool = False,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    query = db.query(models.Application)
    if mine or ("admin" not in user.roles and "developer" not in user.roles):
        query = query.filter(models.Application.customer_id == user.sub)
    
    return query.all()
