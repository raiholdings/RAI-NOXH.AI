from typing import Optional, List, Any
from pydantic import BaseModel
from datetime import datetime

class ApplicationBase(BaseModel):
    sale_batch_id: int
    data: Optional[dict] = {}

class ApplicationCreate(ApplicationBase):
    pass

class ApplicationUpdate(BaseModel):
    data: Optional[dict] = None

class ApplicationStatusUpdate(BaseModel):
    comment: Optional[str] = None

class ApplicationResponse(ApplicationBase):
    id: int
    customer_id: int
    status: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class TokenPayload(BaseModel):
    sub: Optional[int] = None
    roles: List[str] = []
