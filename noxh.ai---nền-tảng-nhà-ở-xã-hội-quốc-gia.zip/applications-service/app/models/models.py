from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, JSON, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

class ApplicationStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    UNDER_REVIEW = "UNDER_REVIEW"
    NEED_MORE_INFO = "NEED_MORE_INFO"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, nullable=False, index=True)
    sale_batch_id = Column(Integer, nullable=False, index=True)
    status = Column(String, default=ApplicationStatus.DRAFT)
    data = Column(JSON, default={}) # Application form data
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    history = relationship("ApplicationStatusHistory", back_populates="application")

class ApplicationStatusHistory(Base):
    __tablename__ = "application_status_history"
    id = Column(Integer, primary_key=True, index=True)
    application_id = Column(Integer, ForeignKey("applications.id"))
    from_status = Column(String)
    to_status = Column(String)
    changed_by = Column(Integer) # User ID who changed it
    comment = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    application = relationship("Application", back_populates="history")
