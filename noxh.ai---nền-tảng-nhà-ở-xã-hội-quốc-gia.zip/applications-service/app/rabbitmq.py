import pika
import json
import logging
from .core.config import settings

logger = logging.getLogger(__name__)

def publish_application_event(event_type: str, application_id: int, customer_id: int, status: str):
    try:
        connection = pika.BlockingConnection(pika.URLParameters(settings.RABBITMQ_URL))
        channel = connection.channel()
        
        channel.exchange_declare(exchange='application_events', exchange_type='topic')
        
        message = {
            "event_type": event_type,
            "application_id": application_id,
            "customer_id": customer_id,
            "status": status,
            "timestamp": str(logging.datetime.datetime.utcnow())
        }
        
        routing_key = f"application.{status.lower()}"
        channel.basic_publish(
            exchange='application_events',
            routing_key=routing_key,
            body=json.dumps(message)
        )
        logger.info(f"Published event {event_type} for application {application_id}")
        connection.close()
    except Exception as e:
        logger.error(f"Failed to publish RabbitMQ event: {e}")
