# noxh.ai Applications Service

## Overview
Dịch vụ quản lý hồ sơ đăng ký mua nhà ở xã hội. Khách hàng có thể tạo hồ sơ nháp, nộp hồ sơ và theo dõi trạng thái. Developer/Admin có thể duyệt hoặc từ chối hồ sơ.

## Application Status Flow
1. **DRAFT**: Khách hàng đang soạn thảo.
2. **SUBMITTED**: Khách hàng đã nộp (Gửi event RabbitMQ).
3. **UNDER_REVIEW**: Đang trong quá trình xét duyệt.
4. **NEED_MORE_INFO**: Yêu cầu bổ sung hồ sơ.
5. **APPROVED**: Hồ sơ được chấp nhận (Gửi event RabbitMQ).
6. **REJECTED**: Hồ sơ bị từ chối (Gửi event RabbitMQ).

## RabbitMQ Events
- Exchange: `application_events` (Topic)
- Routing Keys: `application.submitted`, `application.approved`, `application.rejected`
- Message Schema:
  ```json
  {
    "event_type": "APPLICATION_SUBMITTED",
    "application_id": 123,
    "customer_id": 456,
    "status": "SUBMITTED",
    "timestamp": "2024-03-24T..."
  }
  ```

## Local Setup
1. `pip install -r requirements.txt`
2. `alembic upgrade head`
3. `uvicorn app.main:app --reload`
