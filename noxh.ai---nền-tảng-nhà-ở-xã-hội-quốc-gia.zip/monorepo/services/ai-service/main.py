from fastapi import FastAPI
from noxh_common.logging import setup_logging
import os

logger = setup_logging()

app = FastAPI(title="AI Service")

@app.get("/healthz")
async def health():
    return {"status": "ok"}

@app.post("/analyze")
async def analyze_document():
    logger.info("Analyzing document with Gemini API")
    return {"analysis": "Document is valid", "score": 95}
