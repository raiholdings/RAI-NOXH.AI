from fastapi import FastAPI, Request
from noxh_common.logging import setup_logging
from noxh_common.middleware import RequestIDMiddleware
import os

logger = setup_logging()

app = FastAPI(
    title="Auth Service",
    version="1.0.0",
    openapi_tags=[{"name": "auth", "description": "Authentication operations"}]
)

app.add_middleware(RequestIDMiddleware)

@app.get("/healthz", tags=["health"])
async def health_check():
    return {"status": "healthy", "timestamp": os.popen("date").read().strip()}

@app.get("/readyz", tags=["health"])
async def readiness_check():
    # Check DB connection here
    return {"status": "ready"}

@app.post("/login", tags=["auth"])
async def login():
    logger.info("Login attempt")
    return {"message": "Login successful"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
