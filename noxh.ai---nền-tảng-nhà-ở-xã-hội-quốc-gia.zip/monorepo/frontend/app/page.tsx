import React from 'react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col items-center justify-center p-24">
      <div className="w-20 h-20 bg-emerald-600 rounded-2xl flex items-center justify-center text-white font-bold text-4xl mb-8">
        N
      </div>
      <h1 className="text-4xl font-bold text-zinc-900 mb-4">noxh.ai Monorepo</h1>
      <p className="text-zinc-500 text-center max-w-md">
        Chào mừng bạn đến với cấu trúc mono-repo của dự án Nhà ở Xã hội. 
        Hệ thống đang chạy với 5 microservices và hạ tầng Docker.
      </p>
      <div className="mt-12 grid grid-cols-2 gap-4">
        <div className="p-4 bg-white rounded-xl border border-zinc-200 shadow-sm">
          <p className="font-bold text-zinc-900">Auth Service</p>
          <p className="text-xs text-emerald-600">Online: Port 8001</p>
        </div>
        <div className="p-4 bg-white rounded-xl border border-zinc-200 shadow-sm">
          <p className="font-bold text-zinc-900">AI Service</p>
          <p className="text-xs text-emerald-600">Online: Port 8005</p>
        </div>
      </div>
    </div>
  );
}
