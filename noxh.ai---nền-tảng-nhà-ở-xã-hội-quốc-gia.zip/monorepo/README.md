# noxh.ai Monorepo

## Cấu trúc dự án
- `frontend/`: Next.js Web Application
- `services/`: Các microservices FastAPI
- `shared/`: Thư viện dùng chung cho các service Python
- `docker-compose.yml`: Cấu hình chạy toàn bộ hệ thống local

## Yêu cầu hệ thống
- Docker & Docker Compose
- Python 3.10+
- Node.js 18+

## Hướng dẫn chạy nhanh
1. Sao chép file môi trường: `cp .env.example .env`
2. Khởi động hạ tầng: `make up`
3. Truy cập:
   - Frontend: http://localhost:3000
   - Auth Service Docs: http://localhost:8001/docs
   - Projects Service Docs: http://localhost:8002/docs

## Các lệnh Makefile hữu ích
- `make up`: Khởi động tất cả service
- `make down`: Dừng và xóa container
- `make logs`: Xem log thời gian thực
- `make test`: Chạy unit test cho các service
