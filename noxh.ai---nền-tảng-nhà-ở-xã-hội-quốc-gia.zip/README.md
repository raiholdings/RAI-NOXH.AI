# noxh.ai - Nền tảng Tiếp thị NOXH ứng dụng AI

Nền tảng truyền thông marketing hiện đại về Nhà ở Xã hội (NOXH) tại Việt Nam, tích hợp công cụ thẩm định hồ sơ và đề xuất dự án tự động bằng Trí tuệ nhân tạo (Gemini AI).

## Tính năng chính
- **AI Scoring Tool:** Tự động chấm điểm ưu tiên mua NOXH theo luật định.
- **AI Document Generator:** Tự động soạn thảo bộ hồ sơ chuẩn dựa trên thông tin người dùng.
- **Project Carousel:** Hiển thị danh sách dự án trực quan, sinh động.
- **AI Assistant:** Trợ lý pháp lý giải đáp thắc mắc 24/7.

## Hướng dẫn triển khai (Deployment)

### 1. Yêu cầu hệ thống
- Node.js 18+
- npm hoặc yarn

### 2. Cài đặt
```bash
npm install
```

### 3. Biến môi trường (Environment Variables)
Bạn cần tạo file `.env` ở thư mục gốc và thêm khóa API của Gemini:
```env
VITE_GEMINI_API_KEY=your_api_key_here
```
*Lưu ý: Trong code hiện tại đang sử dụng `process.env.GEMINI_API_KEY`, khi đưa lên các nền tảng như Vercel hoặc Netlify, bạn hãy cấu hình biến này trong phần Environment Variables của họ.*

### 4. Chạy môi trường phát triển
```bash
npm run dev
```

### 5. Xây dựng bản sản xuất (Build)
```bash
npm run build
```

## Đưa lên GitHub và thêm Tên miền
1. Tạo một Repository mới trên GitHub.
2. Đẩy mã nguồn lên:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <your-github-repo-url>
   git push -u origin main
   ```
3. **Khuyến nghị:** Sử dụng **Vercel** hoặc **Netlify** để kết nối với Repo GitHub này. Các dịch vụ này hỗ trợ React/Vite cực tốt và cho phép thêm tên miền tùy chỉnh (Custom Domain) chỉ với vài cú click.

---
Phát triển bởi noxh.ai Team.
