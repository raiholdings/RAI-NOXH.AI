from fastapi import FastAPI
from prometheus_fastapi_instrumentator import Instrumentator
from .api import auth
from .core.config import settings

app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION)

# Metrics
Instrumentator().instrument(app).expose(app)

# Routes
app.include_router(auth.router, prefix=f"{settings.API_V1_STR}/auth", tags=["auth"])

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

@app.get("/readyz")
def readyz():
    return {"status": "ready"}
