from typing import Optional, List
from pydantic import BaseModel, EmailStr

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str

class TokenPayload(BaseModel):
    sub: Optional[int] = None
    roles: List[str] = []

class UserBase(BaseModel):
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = True

class UserCreate(UserBase):
    email: EmailStr
    password: str
    tenant_id: int

class UserResponse(UserBase):
    id: int
    tenant_id: Optional[int]
    roles: List[str] = []

    class Config:
        from_attributes = True
