from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from jose import jwt, JWTError
from typing import List

from ..core.config import settings
from ..core import security
from ..models import models
from ..schemas import schemas
from ..db.session import get_db

router = APIRouter()
reusable_oauth2 = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")

def get_current_user(db: Session = Depends(get_db), token: str = Depends(reusable_oauth2)) -> models.User:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        token_data = schemas.TokenPayload(**payload)
    except (JWTError, Exception):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Could not validate credentials")
    
    user = db.query(models.User).filter(models.User.id == token_data.sub).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

class RoleChecker:
    def __init__(self, allowed_roles: List[str]):
        self.allowed_roles = allowed_roles

    def __call__(self, user: models.User = Depends(get_current_user)):
        user_roles = [role.name for role in user.roles]
        if not any(role in self.allowed_roles for role in user_roles):
            raise HTTPException(status_code=403, detail="Operation not permitted")
        return user

@router.post("/register", response_model=schemas.UserResponse)
def register(user_in: schemas.UserCreate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == user_in.email).first()
    if user:
        raise HTTPException(status_code=400, detail="User already exists")
    
    new_user = models.User(
        email=user_in.email,
        hashed_password=security.get_password_hash(user_in.password),
        tenant_id=user_in.tenant_id
    )
    # Default role: customer
    customer_role = db.query(models.Role).filter(models.Role.name == "customer").first()
    if customer_role:
        new_user.roles.append(customer_role)
        
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.post("/login", response_model=schemas.Token)
def login(db: Session = Depends(get_db), form_data: OAuth2PasswordRequestForm = Depends()):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    
    roles = [role.name for role in user.roles]
    return {
        "access_token": security.create_access_token(user.id, roles),
        "refresh_token": security.create_refresh_token(user.id),
        "token_type": "bearer",
    }

@router.get("/me", response_model=schemas.UserResponse)
def read_user_me(current_user: models.User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "email": current_user.email,
        "is_active": current_user.is_active,
        "tenant_id": current_user.tenant_id,
        "roles": [role.name for role in current_user.roles]
    }

@router.get("/admin/ping", dependencies=[Depends(RoleChecker(["admin"]))])
def admin_ping():
    return {"message": "Pong! You are an admin."}
