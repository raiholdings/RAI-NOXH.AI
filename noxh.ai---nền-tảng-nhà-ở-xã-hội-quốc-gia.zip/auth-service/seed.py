import logging
from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.models import Role, Tenant

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed_data():
    db = SessionLocal()
    try:
        # Seed Roles
        roles = ["admin", "developer", "customer", "provider"]
        for role_name in roles:
            role = db.query(Role).filter(Role.name == role_name).first()
            if not role:
                db.add(Role(name=role_name))
                logger.info(f"Seeded role: {role_name}")
        
        # Seed Default Tenant
        tenant = db.query(Tenant).filter(Tenant.name == "Default").first()
        if not tenant:
            db.add(Tenant(name="Default"))
            logger.info("Seeded default tenant")
            
        db.commit()
    except Exception as e:
        logger.error(f"Error seeding data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_data()
