# noxh.ai Auth Service

## Setup Local
1. Install dependencies: `pip install -r requirements.txt`
2. Run migrations: `alembic upgrade head`
3. Seed data: `python seed.py`
4. Start app: `uvicorn app.main:app --reload`

## API Endpoints
- `POST /api/v1/auth/register`: Register a new user.
- `POST /api/v1/auth/login`: Login and get JWT.
- `GET /api/v1/auth/me`: Get current user info.
- `GET /api/v1/auth/admin/ping`: Admin only endpoint.

## Security
- Uses **HS256** for JWT signing.
- Password hashing with **Bcrypt**.
- RBAC implemented via `RoleChecker` dependency.
