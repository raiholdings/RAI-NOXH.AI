import requests
from .config import settings
import logging

logger = logging.getLogger(__name__)

def index_to_rag(document_id: int, text: str, title: str):
    url = f"{settings.AI_SERVICE_URL}/rag/index"
    payload = {
        "source": f"doc-{document_id}",
        "title": title,
        "text": text
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        logger.info(f"Indexed document {document_id} to RAG")
    except Exception as e:
        logger.error(f"Failed to index to RAG: {e}")
