import pika
import json
import time
import logging
import sys
from pythonjsonlogger import jsonlogger
from prometheus_client import start_http_server, Counter, Histogram

from .config import settings
from .s3_client import download_file
from .ocr import perform_ocr
from .db import save_extraction
from .opensearch_client import index_document
from .ai_client import index_to_rag

# Logging Setup
logger = logging.getLogger()
logHandler = logging.StreamHandler(sys.stdout)
formatter = jsonlogger.JsonFormatter('%(timestamp)s %(level)s %(name)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)
logger.setLevel(logging.INFO)

# Metrics
DOCS_PROCESSED = Counter('docs_processed_total', 'Total documents processed', ['status'])
PROCESSING_TIME = Histogram('doc_processing_seconds', 'Time spent processing document')

def process_message(ch, method, properties, body):
    start_time = time.time()
    try:
        data = json.loads(body)
        document_id = data['document_id']
        application_id = data['application_id']
        object_key = data['object_key']
        
        logger.info(f"Processing document {document_id}", extra={"document_id": document_id})
        
        # 1. Download
        file_content = download_file(object_key)
        
        # 2. OCR
        text = perform_ocr(file_content, object_key)
        
        # 3. Save to DB
        save_extraction(document_id, text)
        
        # 4. Index to OpenSearch
        index_document(document_id, application_id, text)
        
        # 5. Optional RAG Indexing (e.g. if filename contains 'policy' or 'regulation')
        if "policy" in object_key.lower() or "regulation" in object_key.lower():
            index_to_rag(document_id, text, object_key.split('/')[-1])
            
        ch.basic_ack(delivery_tag=method.delivery_tag)
        DOCS_PROCESSED.labels(status='success').inc()
        logger.info(f"Successfully processed document {document_id}")
        
    except Exception as e:
        logger.error(f"Error processing document: {e}", exc_info=True)
        # Nack and requeue if it's a transient error, or let it go to DLQ
        # For this MVP, we'll nack without requeue to trigger DLQ logic if configured
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
        DOCS_PROCESSED.labels(status='error').inc()
    finally:
        PROCESSING_TIME.observe(time.time() - start_time)

def main():
    # Start metrics server
    start_http_server(settings.METRICS_PORT)
    logger.info(f"Metrics server started on port {settings.METRICS_PORT}")

    while True:
        try:
            connection = pika.BlockingConnection(pika.URLParameters(settings.RABBITMQ_URL))
            channel = connection.channel()

            # Declare DLX and DLQ
            channel.exchange_declare(exchange=settings.DLX_NAME, exchange_type='direct')
            channel.queue_declare(queue=settings.DLQ_NAME)
            channel.queue_bind(exchange=settings.DLX_NAME, queue=settings.DLQ_NAME)

            # Declare Main Queue with DLX
            args = {
                'x-dead-letter-exchange': settings.DLX_NAME,
                'x-dead-letter-routing-key': settings.DLQ_NAME
            }
            channel.queue_declare(queue=settings.QUEUE_NAME, arguments=args)
            channel.queue_bind(exchange='document_events', queue=settings.QUEUE_NAME, routing_key='document.uploaded')

            channel.basic_qos(prefetch_count=1)
            channel.basic_consume(queue=settings.QUEUE_NAME, on_message_callback=process_message)

            logger.info("Worker started. Waiting for messages...")
            channel.start_consuming()
        except pika.exceptions.AMQPConnectionError:
            logger.warning("RabbitMQ connection lost. Retrying in 5s...")
            time.sleep(5)
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
