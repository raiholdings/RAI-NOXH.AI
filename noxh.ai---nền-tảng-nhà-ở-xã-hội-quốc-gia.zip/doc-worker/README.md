# noxh.ai Document Worker

## Overview
Worker chạy background để xử lý tài liệu sau khi được upload. Worker lắng nghe event từ RabbitMQ, thực hiện OCR và phân phối dữ liệu đến các hệ thống khác.

## Workflow
1. **Consume**: Nhận event `DOCUMENT_UPLOADED` từ RabbitMQ.
2. **Download**: Tải file từ MinIO/S3.
3. **OCR**: Sử dụng Tesseract OCR để trích xuất văn bản (hỗ trợ Tiếng Việt & Tiếng Anh).
4. **Persist**: Lưu văn bản trích xuất vào PostgreSQL (`document_extractions`).
5. **Search**: Index văn bản vào OpenSearch để hỗ trợ tìm kiếm toàn văn.
6. **AI Index**: Nếu là văn bản quy định, tự động gọi `ai-service` để đưa vào Vector DB phục vụ RAG.

## Reliability
- **Retry**: Tự động kết nối lại RabbitMQ.
- **DLQ**: Các message lỗi được chuyển vào Dead Letter Queue (`document_uploaded_dlq`) để kiểm tra sau.
- **Logging**: Log định dạng JSON scannable bởi ELK/Loki.
- **Metrics**: Export Prometheus metrics tại port 8000.

## Deployment
- **Docker**: Image bao gồm sẵn Tesseract binary.
- **Scaling**: Khuyến khích sử dụng **KEDA** để scale dựa trên độ dài hàng đợi RabbitMQ.
