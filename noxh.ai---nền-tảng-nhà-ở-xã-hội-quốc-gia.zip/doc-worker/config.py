import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # RabbitMQ
    RABBITMQ_URL: str = "amqp://guest:guest@localhost:5672/"
    QUEUE_NAME: str = "document_uploaded_queue"
    DLX_NAME: str = "document_uploaded_dlx"
    DLQ_NAME: str = "document_uploaded_dlq"
    
    # S3 / MinIO
    S3_ENDPOINT: str = "http://localhost:9000"
    S3_ACCESS_KEY: str = "minioadmin"
    S3_SECRET_KEY: str = "minioadmin"
    S3_BUCKET: str = "noxh-documents"
    S3_REGION: str = "us-east-1"
    
    # Postgres
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost/noxh_documents"
    
    # OpenSearch
    OPENSEARCH_URL: str = "http://localhost:9200"
    OPENSEARCH_INDEX: str = "documents"
    
    # AI Service
    AI_SERVICE_URL: str = "http://localhost:8001/api/v1"
    
    # Metrics
    METRICS_PORT: int = 8000

    class Config:
        env_file = ".env"

settings = Settings()
