import boto3
from botocore.config import Config
from .config import settings

def get_s3_client():
    return boto3.client(
        's3',
        endpoint_url=settings.S3_ENDPOINT,
        aws_access_key_id=settings.S3_ACCESS_KEY,
        aws_secret_access_key=settings.S3_SECRET_KEY,
        config=Config(signature_version='s3v4'),
        region_name=settings.S3_REGION
    )

def download_file(object_key: str) -> bytes:
    s3 = get_s3_client()
    response = s3.get_object(Bucket=settings.S3_BUCKET, Key=object_key)
    return response['Body'].read()
