from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from .config import settings

Base = declarative_base()

class DocumentExtraction(Base):
    __tablename__ = "document_extractions"
    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, unique=True, index=True)
    extracted_text = Column(Text)
    processed_at = Column(DateTime, default=datetime.utcnow)

engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

def save_extraction(document_id: int, text: str):
    db = SessionLocal()
    try:
        extraction = DocumentExtraction(document_id=document_id, extracted_text=text)
        db.add(extraction)
        db.commit()
    finally:
        db.close()

# Create tables if they don't exist
Base.metadata.create_all(bind=engine)
