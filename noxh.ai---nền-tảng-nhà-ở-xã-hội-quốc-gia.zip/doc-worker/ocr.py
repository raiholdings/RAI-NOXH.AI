import pytesseract
from PIL import Image
import io
import logging

logger = logging.getLogger(__name__)

def perform_ocr(file_content: bytes, filename: str) -> str:
    try:
        # For simple MVP, assume it's an image or PDF converted to image
        # If it's a PDF, we'd need pdf2image here.
        image = Image.open(io.BytesIO(file_content))
        text = pytesseract.image_to_string(image, lang='vie+eng')
        return text.strip()
    except Exception as e:
        logger.error(f"OCR failed for {filename}: {e}")
        raise
