from opensearchpy import OpenSearch
from .config import settings
import logging

logger = logging.getLogger(__name__)

def get_opensearch_client():
    return OpenSearch(
        hosts=[settings.OPENSEARCH_URL],
        http_compress=True,
        use_ssl=False,
        verify_certs=False,
        ssl_assert_hostname=False,
        ssl_show_warn=False,
    )

def index_document(document_id: int, application_id: int, text: str):
    client = get_opensearch_client()
    doc = {
        "document_id": document_id,
        "application_id": application_id,
        "text": text,
        "indexed_at": logging.datetime.datetime.utcnow().isoformat()
    }
    try:
        client.index(
            index=settings.OPENSEARCH_INDEX,
            body=doc,
            id=str(document_id),
            refresh=True
        )
    except Exception as e:
        logger.error(f"OpenSearch indexing failed: {e}")
