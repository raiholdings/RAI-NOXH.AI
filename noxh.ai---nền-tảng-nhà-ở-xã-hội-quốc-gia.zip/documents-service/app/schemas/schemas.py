from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime

class PresignUploadRequest(BaseModel):
    filename: str
    content_type: str
    application_id: int

class PresignUploadResponse(BaseModel):
    url: str
    object_key: str
    fields: dict

class ConfirmUploadRequest(BaseModel):
    object_key: str
    application_id: int
    filename: str
    content_type: str

class DocumentResponse(BaseModel):
    id: int
    application_id: int
    object_key: str
    filename: str
    content_type: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

class TokenPayload(BaseModel):
    sub: Optional[int] = None
    roles: List[str] = []
