import boto3
from botocore.config import Config
from .core.config import settings

def get_s3_client():
    return boto3.client(
        's3',
        endpoint_url=settings.S3_ENDPOINT,
        aws_access_key_id=settings.S3_ACCESS_KEY,
        aws_secret_access_key=settings.S3_SECRET_KEY,
        config=Config(signature_version='s3v4'),
        region_name=settings.S3_REGION
    )

def generate_presigned_post(object_key: str, content_type: str):
    s3_client = get_s3_client()
    try:
        response = s3_client.generate_presigned_post(
            Bucket=settings.S3_BUCKET,
            Key=object_key,
            Fields={"Content-Type": content_type},
            Conditions=[{"Content-Type": content_type}],
            ExpiresIn=3600
        )
        return response
    except Exception as e:
        print(f"Error generating presigned post: {e}")
        return None
