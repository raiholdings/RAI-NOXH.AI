from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import uuid

from ..db.session import get_db
from ..models import models
from ..schemas import schemas
from .deps import get_current_user_payload
from ..s3_utils import generate_presigned_post
from ..rabbitmq import publish_document_event

router = APIRouter()

@router.post("/presign-upload", response_model=schemas.PresignUploadResponse)
def presign_upload(
    req: schemas.PresignUploadRequest,
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    # Security: In a real app, verify user owns application_id via applications-service
    # For this template, we assume the check is done or sub is valid.
    
    object_key = f"apps/{req.application_id}/{uuid.uuid4()}-{req.filename}"
    presigned = generate_presigned_post(object_key, req.content_type)
    
    if not presigned:
        raise HTTPException(status_code=500, detail="Could not generate presigned URL")
        
    return {
        "url": presigned["url"],
        "object_key": object_key,
        "fields": presigned["fields"]
    }

@router.post("/confirm-upload", response_model=schemas.DocumentResponse)
def confirm_upload(
    req: schemas.ConfirmUploadRequest,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    # Check if document already exists
    existing = db.query(models.Document).filter(models.Document.object_key == req.object_key).first()
    if existing:
        raise HTTPException(status_code=400, detail="Document already confirmed")

    document = models.Document(
        application_id=req.application_id,
        customer_id=user.sub,
        object_key=req.object_key,
        filename=req.filename,
        content_type=req.content_type
    )
    db.add(document)
    db.commit()
    db.refresh(document)
    
    # Emit event for OCR worker
    publish_document_event("DOCUMENT_UPLOADED", document.id, document.application_id, document.object_key)
    
    return document

@router.get("/", response_model=List[schemas.DocumentResponse])
def list_documents(
    application_id: int,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    # Security: Only owner or admin/developer can see
    query = db.query(models.Document).filter(models.Document.application_id == application_id)
    
    if "admin" not in user.roles and "developer" not in user.roles:
        query = query.filter(models.Document.customer_id == user.sub)
        
    return query.all()
