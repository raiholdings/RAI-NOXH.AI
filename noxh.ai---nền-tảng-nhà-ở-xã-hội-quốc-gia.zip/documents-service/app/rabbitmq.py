import pika
import json
import logging
from .core.config import settings

logger = logging.getLogger(__name__)

def publish_document_event(event_type: str, document_id: int, application_id: int, object_key: str):
    try:
        connection = pika.BlockingConnection(pika.URLParameters(settings.RABBITMQ_URL))
        channel = connection.channel()
        
        channel.exchange_declare(exchange='document_events', exchange_type='topic')
        
        message = {
            "event_type": event_type,
            "document_id": document_id,
            "application_id": application_id,
            "object_key": object_key,
            "timestamp": str(logging.datetime.datetime.utcnow())
        }
        
        routing_key = "document.uploaded"
        channel.basic_publish(
            exchange='document_events',
            routing_key=routing_key,
            body=json.dumps(message)
        )
        logger.info(f"Published event {event_type} for document {document_id}")
        connection.close()
    except Exception as e:
        logger.error(f"Failed to publish RabbitMQ event: {e}")
