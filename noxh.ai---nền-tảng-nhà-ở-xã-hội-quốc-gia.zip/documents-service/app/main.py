from fastapi import FastAPI
from prometheus_fastapi_instrumentator import Instrumentator
from .api import documents
from .core.config import settings
import logging
import sys
import json
from datetime import datetime

# Logging
class JsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "service": settings.PROJECT_NAME
        })

logger = logging.getLogger()
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
logger.addHandler(handler)
logger.setLevel(logging.INFO)

app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION)

# Metrics
Instrumentator().instrument(app).expose(app)

# Routes
app.include_router(documents.router, prefix=f"{settings.API_V1_STR}/documents", tags=["documents"])

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

@app.get("/readyz")
def readyz():
    return {"status": "ready"}
