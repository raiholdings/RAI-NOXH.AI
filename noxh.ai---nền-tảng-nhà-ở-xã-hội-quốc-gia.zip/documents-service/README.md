# noxh.ai Documents Service

## Overview
Dịch vụ quản lý tài liệu hồ sơ. Hỗ trợ upload trực tiếp lên S3/MinIO thông qua **Presigned URL** để tối ưu hiệu năng server.

## Upload Flow
1. Client gọi `POST /documents/presign-upload` để lấy URL và các fields cần thiết.
2. Client upload file trực tiếp lên S3 bằng URL đó.
3. Client gọi `POST /documents/confirm-upload` để báo cho server biết file đã upload thành công.
4. Server lưu metadata vào DB và gửi event `DOCUMENT_UPLOADED` vào RabbitMQ.

## RabbitMQ Events
- Exchange: `document_events` (Topic)
- Routing Key: `document.uploaded`
- Message:
  ```json
  {
    "event_type": "DOCUMENT_UPLOADED",
    "document_id": 1,
    "application_id": 10,
    "object_key": "apps/10/uuid-filename.pdf",
    "timestamp": "..."
  }
  ```

## Local Setup
1. `pip install -r requirements.txt`
2. `alembic upgrade head`
3. `uvicorn app.main:app --reload`
