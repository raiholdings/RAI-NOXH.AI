from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, JSON, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    location = Column(String, nullable=False)
    description = Column(Text)
    developer_id = Column(Integer, nullable=False) # ID from Auth Service
    created_at = Column(DateTime, default=datetime.utcnow)
    
    sale_batches = relationship("SaleBatch", back_populates="project")

class SaleBatch(Base):
    __tablename__ = "sale_batches"
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"))
    name = Column(String, nullable=False)
    units_total = Column(Integer, nullable=False)
    price_per_sqm = Column(Float, nullable=False)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    status = Column(String, default="UPCOMING") # UPCOMING, OPEN, CLOSED
    
    project = relationship("Project", back_populates="sale_batches")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    action = Column(String, nullable=False) # CREATE, UPDATE, DELETE
    resource_type = Column(String, nullable=False) # PROJECT, SALE_BATCH
    resource_id = Column(Integer, nullable=False)
    payload = Column(JSON)
    timestamp = Column(DateTime, default=datetime.utcnow)
