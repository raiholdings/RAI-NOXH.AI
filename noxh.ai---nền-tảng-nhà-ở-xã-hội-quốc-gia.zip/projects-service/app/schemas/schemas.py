from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime

class SaleBatchBase(BaseModel):
    name: str
    units_total: int
    price_per_sqm: float
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    status: str = "UPCOMING"

class SaleBatchCreate(SaleBatchBase):
    pass

class SaleBatchResponse(SaleBatchBase):
    id: int
    project_id: int

    class Config:
        from_attributes = True

class ProjectBase(BaseModel):
    name: str
    location: str
    description: Optional[str] = None

class ProjectCreate(ProjectBase):
    pass

class ProjectResponse(ProjectBase):
    id: int
    developer_id: int
    created_at: datetime
    sale_batches: List[SaleBatchResponse] = []

    class Config:
        from_attributes = True

class TokenPayload(BaseModel):
    sub: Optional[int] = None
    roles: List[str] = []
