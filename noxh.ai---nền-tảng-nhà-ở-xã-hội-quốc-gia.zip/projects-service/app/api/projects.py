from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List

from ..db.session import get_db
from ..models import models
from ..schemas import schemas
from .deps import RoleChecker, get_current_user_payload

router = APIRouter()

def log_audit(db: Session, user_id: int, action: str, resource_type: str, resource_id: int, payload: dict):
    audit = models.AuditLog(
        user_id=user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        payload=payload
    )
    db.add(audit)
    db.commit()

@router.post("/", response_model=schemas.ProjectResponse, dependencies=[Depends(RoleChecker(["developer", "admin"]))])
def create_project(
    project_in: schemas.ProjectCreate, 
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    project = models.Project(**project_in.dict(), developer_id=user.sub)
    db.add(project)
    db.commit()
    db.refresh(project)
    
    log_audit(db, user.sub, "CREATE", "PROJECT", project.id, project_in.dict())
    return project

@router.get("/", response_model=List[schemas.ProjectResponse])
def list_projects(db: Session = Depends(get_db), skip: int = 0, limit: int = 100):
    return db.query(models.Project).offset(skip).limit(limit).all()

@router.get("/{id}", response_model=schemas.ProjectResponse)
def get_project(id: int, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

@router.post("/{id}/sale-batches", response_model=schemas.SaleBatchResponse, dependencies=[Depends(RoleChecker(["developer", "admin"]))])
def create_sale_batch(
    id: int,
    batch_in: schemas.SaleBatchCreate,
    db: Session = Depends(get_db),
    user: schemas.TokenPayload = Depends(get_current_user_payload)
):
    project = db.query(models.Project).filter(models.Project.id == id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    if project.developer_id != user.sub and "admin" not in user.roles:
        raise HTTPException(status_code=403, detail="Not the owner of this project")

    batch = models.SaleBatch(**batch_in.dict(), project_id=id)
    db.add(batch)
    db.commit()
    db.refresh(batch)
    
    log_audit(db, user.sub, "CREATE", "SALE_BATCH", batch.id, batch_in.dict())
    return batch

@router.get("/sale-batches/", response_model=List[schemas.SaleBatchResponse])
def list_sale_batches(project_id: int = Query(...), db: Session = Depends(get_db)):
    return db.query(models.SaleBatch).filter(models.SaleBatch.project_id == project_id).all()
