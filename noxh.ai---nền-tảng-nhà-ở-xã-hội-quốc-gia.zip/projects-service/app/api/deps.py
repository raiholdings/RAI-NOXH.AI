from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from sqlalchemy.orm import Session
from typing import List

from .core.config import settings
from .schemas import schemas
from .db.session import get_db

reusable_oauth2 = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login") # URL of Auth Service

def get_current_user_payload(token: str = Depends(reusable_oauth2)) -> schemas.TokenPayload:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        token_data = schemas.TokenPayload(**payload)
        if token_data.sub is None:
            raise HTTPException(status_code=403, detail="Invalid token")
        return token_data
    except (JWTError, Exception):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Could not validate credentials")

class RoleChecker:
    def __init__(self, allowed_roles: List[str]):
        self.allowed_roles = allowed_roles

    def __call__(self, payload: schemas.TokenPayload = Depends(get_current_user_payload)):
        if not any(role in self.allowed_roles for role in payload.roles):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return payload
