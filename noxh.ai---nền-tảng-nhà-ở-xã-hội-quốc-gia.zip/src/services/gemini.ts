import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

export const getGeminiClient = () => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured. Please add it to your environment variables.");
  }
  return new GoogleGenAI({ apiKey });
};

export const geminiModel = "gemini-3-flash-preview";
