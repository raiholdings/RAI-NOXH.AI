/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, NavLink, useLocation, Navigate } from 'react-router-dom';
import { 
  User, 
  Bell,
  Menu,
  X,
  Settings,
  ShieldCheck,
  MessageSquare,
  LogOut,
  Home,
  Building2,
  Briefcase,
  FileText,
  Search,
  BarChart3,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from './firebase';

// --- Imports ---
import { Role } from './types';
import { Sidebar } from './components/Sidebar';
import { AICopilot } from './components/AICopilot';
import { 
  CustomerDashboard, 
  DocumentVault, 
  CustomerMessages, 
  CustomerSettings 
} from './views/CustomerView';
import { ApplicationsView } from './views/ApplicationsView';
import { SettingsView } from './views/SettingsView';
import { DeveloperView } from './views/DeveloperView';
import { ConsultantView } from './views/ConsultantView';
import { ProviderView } from './views/ProviderView';
import { ProjectDetailView } from './views/ProjectDetailView';
import { ApplicationFlow } from './views/ApplicationFlow';
import { MarketplaceView } from './views/MarketplaceView';
import { ProviderDetailView } from './views/ProviderDetailView';
import { ContractSigningFlow } from './views/ContractSigningFlow';
import { LandingView } from './views/LandingView';
import { AuthView } from './views/AuthView';
import { AboutView } from './views/AboutView';
import { ProjectsView } from './views/ProjectsView';

// --- Components ---

const Navbar = ({ role, setRole, isAuthenticated, onLogout }: { 
  role: Role, 
  setRole: (r: Role) => void, 
  isAuthenticated: boolean,
  onLogout: () => void
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  // Close mobile menu on route change
  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  return (
    <>
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-black/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
                N
              </div>
              <span className="text-xl font-bold tracking-tight text-zinc-900">noxh.ai</span>
            </Link>

            {/* Navigation Links - Desktop */}
            <div className="hidden md:flex items-center gap-6">
              <Link to="/" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Trang chủ</Link>
              <Link to="/about" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Giới thiệu</Link>
              <Link to="/projects" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Dự án</Link>
              <Link to="/marketplace" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Dịch vụ</Link>
              {isAuthenticated && (
                <Link to="/messages" className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Tin nhắn</Link>
              )}
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              {isAuthenticated ? (
                <>
                  <div className="flex items-center gap-2 bg-zinc-100 p-1 rounded-xl">
                    {(['CUSTOMER', 'DEVELOPER', 'PROVIDER', 'ADMIN'] as Role[]).map((r) => (
                      <button
                        key={r}
                        onClick={() => setRole(r)}
                        className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all ${
                          role === r ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
                        }`}
                      >
                        {r === 'CUSTOMER' ? 'Khách' : r === 'DEVELOPER' ? 'CĐT' : r === 'PROVIDER' ? 'Dịch vụ' : 'Chuyên viên'}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-4">
                    <button className="p-2 text-zinc-500 hover:text-zinc-900 transition-colors">
                      <Bell size={20} />
                    </button>
                    <button 
                      onClick={onLogout}
                      className="p-2 text-zinc-500 hover:text-red-600 transition-colors"
                      title="Đăng xuất"
                    >
                      <LogOut size={20} />
                    </button>
                    <div className="w-8 h-8 rounded-full bg-zinc-200 flex items-center justify-center overflow-hidden border border-zinc-300">
                      <User size={18} className="text-zinc-500" />
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-4">
                  <Link to="/login" className="text-sm font-bold text-zinc-500 hover:text-zinc-900">Đăng nhập</Link>
                  <Link to="/register" className="px-5 py-2.5 bg-zinc-900 text-white rounded-xl text-sm font-bold hover:bg-zinc-800 transition-all">
                    Đăng ký
                  </Link>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center gap-4">
              {isAuthenticated && (
                <button className="p-2 text-zinc-500">
                  <Bell size={20} />
                </button>
              )}
              <button 
                onClick={() => setIsOpen(!isOpen)} 
                className="p-2 text-zinc-900 active:scale-95 transition-transform"
                aria-label="Toggle menu"
              >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 md:hidden"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-[80%] max-w-sm bg-white z-50 md:hidden shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center">
                <span className="font-bold text-zinc-900">Menu</span>
                <button onClick={() => setIsOpen(false)} className="p-2 text-zinc-500">
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-8">
                {/* Role Switcher for Mobile */}
                {isAuthenticated && (
                  <div className="space-y-4">
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Chế độ xem</p>
                    <div className="grid grid-cols-2 gap-2">
                      {(['CUSTOMER', 'DEVELOPER', 'PROVIDER', 'ADMIN'] as Role[]).map((r) => (
                        <button
                          key={r}
                          onClick={() => {
                            setRole(r);
                            setIsOpen(false);
                          }}
                          className={`px-3 py-3 text-xs font-bold rounded-xl border transition-all flex flex-col items-center gap-1 ${
                            role === r 
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-600' 
                              : 'bg-zinc-50 border-zinc-100 text-zinc-500'
                          }`}
                        >
                          <span className="text-[10px] opacity-60">
                            {r === 'CUSTOMER' ? 'Khách' : r === 'DEVELOPER' ? 'CĐT' : r === 'PROVIDER' ? 'Dịch vụ' : 'Chuyên viên'}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Khám phá</p>
                    <div className="grid gap-2">
                      <Link to="/" className="flex items-center gap-3 p-3 rounded-xl hover:bg-zinc-50 text-zinc-900 font-medium">
                        <Home size={20} className="text-zinc-400" /> Trang chủ
                      </Link>
                      <Link to="/about" className="flex items-center gap-3 p-3 rounded-xl hover:bg-zinc-50 text-zinc-900 font-medium">
                        <ShieldCheck size={20} className="text-zinc-400" /> Giới thiệu
                      </Link>
                      <Link to="/projects" className="flex items-center gap-3 p-3 rounded-xl hover:bg-zinc-50 text-zinc-900 font-medium">
                        <Building2 size={20} className="text-zinc-400" /> Dự án
                      </Link>
                      <Link to="/marketplace" className="flex items-center gap-3 p-3 rounded-xl hover:bg-zinc-50 text-zinc-900 font-medium">
                        <Briefcase size={20} className="text-zinc-400" /> Dịch vụ
                      </Link>
                      {isAuthenticated && (
                        <Link to="/messages" className="flex items-center gap-3 p-3 rounded-xl hover:bg-zinc-50 text-zinc-900 font-medium">
                          <MessageSquare size={20} className="text-zinc-400" /> Tin nhắn
                        </Link>
                      )}
                    </div>
                </div>

                {!isAuthenticated && (
                  <div className="space-y-3 pt-4">
                    <Link to="/login" className="block w-full py-4 text-center font-bold text-zinc-900 border border-zinc-200 rounded-2xl">
                      Đăng nhập
                    </Link>
                    <Link to="/register" className="block w-full py-4 text-center font-bold text-white bg-zinc-900 rounded-2xl">
                      Đăng ký tài khoản
                    </Link>
                  </div>
                )}
              </div>

              {isAuthenticated && (
                <div className="p-6 border-t border-zinc-100">
                  <button 
                    onClick={() => {
                      onLogout();
                      setIsOpen(false);
                    }}
                    className="w-full flex items-center justify-center gap-3 py-4 text-red-600 font-bold bg-red-50 rounded-2xl"
                  >
                    <LogOut size={20} /> Đăng xuất
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

const MobileNav = ({ role, isAuthenticated }: { role: Role, isAuthenticated: boolean }) => {
  if (!isAuthenticated) return null;

  const menuItems = {
    CUSTOMER: [
      { label: 'Home', icon: Home, path: '/dashboard' },
      { label: 'Dự án', icon: Building2, path: '/projects' },
      { label: 'Hồ sơ', icon: FileText, path: '/applications' },
      { label: 'Dịch vụ', icon: Briefcase, path: '/marketplace' },
    ],
    DEVELOPER: [
      { label: 'Home', icon: Home, path: '/dashboard' },
      { label: 'Dự án', icon: Building2, path: '/my-projects' },
      { label: 'Duyệt', icon: FileText, path: '/review' },
      { label: 'Phân tích', icon: BarChart3, path: '/analytics' },
    ],
    PROVIDER: [
      { label: 'Home', icon: Home, path: '/dashboard' },
      { label: 'Dịch vụ', icon: Briefcase, path: '/my-services' },
      { label: 'Yêu cầu', icon: Users, path: '/leads' },
      { label: 'Cài đặt', icon: Settings, path: '/settings' },
    ],
    ADMIN: [
      { label: 'Home', icon: Home, path: '/dashboard' },
      { label: 'Duyệt', icon: FileText, path: '/review-applications' },
      { label: 'Tư vấn', icon: MessageSquare, path: '/consultation' },
      { label: 'Báo cáo', icon: BarChart3, path: '/reports' },
    ]
  };

  const currentMenu = menuItems[role] || menuItems.CUSTOMER;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-zinc-200 px-4 py-2 z-40 md:hidden flex justify-around items-center safe-area-bottom">
      {currentMenu.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          className={({ isActive }) => `
            flex flex-col items-center gap-1 p-2 transition-all
            ${isActive ? 'text-emerald-600' : 'text-zinc-400'}
          `}
        >
          {({ isActive }) => (
            <>
              <item.icon size={20} className={isActive ? 'scale-110 transition-transform' : ''} />
              <span className="text-[10px] font-bold uppercase tracking-wider">{item.label}</span>
            </>
          )}
        </NavLink>
      ))}
    </div>
  );
};

const MainContent = ({ role, isAuthenticated, onAuth }: { 
  role: Role, 
  isAuthenticated: boolean,
  onAuth: (role: Role) => void
}) => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';
  const isLandingPage = location.pathname === '/' && !isAuthenticated;
  const isAppFlow = location.pathname.startsWith('/apply/');

  return (
    <div className={`${(isLandingPage || isAuthPage) ? '' : 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 flex flex-col lg:flex-row gap-8'}`}>
      {/* Sidebar - Hidden on mobile, landing, auth, and application flow */}
      {isAuthenticated && !isAuthPage && !isLandingPage && !isAppFlow && (
        <div className="hidden lg:block">
          <Sidebar role={role} />
        </div>
      )}

      {/* Main Content Area */}
      <main className={`flex-1 min-w-0 ${isAuthenticated ? 'pb-20 md:pb-0' : ''}`}>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={isAuthenticated ? <Navigate to="/dashboard" /> : <LandingView />} />
          <Route path="/login" element={<AuthView type="login" onAuth={onAuth} />} />
          <Route path="/register" element={<AuthView type="register" onAuth={onAuth} />} />
          <Route path="/projects/:id" element={<ProjectDetailView />} />
          <Route path="/about" element={<AboutView />} />

          {/* Protected Dashboard Route */}
          <Route path="/dashboard" element={
            isAuthenticated ? (
              role === 'CUSTOMER' ? <CustomerDashboard /> :
              role === 'DEVELOPER' ? <DeveloperView /> :
              role === 'PROVIDER' ? <ProviderView /> :
              <ConsultantView />
            ) : <Navigate to="/login" />
          } />

          {/* Customer Routes */}
          <Route path="/projects" element={<ProjectsView />} />
          <Route path="/apply/:id" element={isAuthenticated ? <ApplicationFlow /> : <Navigate to="/login" />} />
          <Route path="/marketplace" element={<MarketplaceView />} />
          <Route path="/marketplace/:id" element={<ProviderDetailView />} />
          <Route path="/marketplace/sign/:providerId/:packageId" element={isAuthenticated ? <ContractSigningFlow /> : <Navigate to="/login" />} />
          <Route path="/vault" element={isAuthenticated ? <DocumentVault /> : <Navigate to="/login" />} />
          <Route path="/applications" element={isAuthenticated ? <ApplicationsView /> : <Navigate to="/login" />} />
          <Route path="/messages" element={isAuthenticated ? <CustomerMessages /> : <Navigate to="/login" />} />
          <Route path="/settings" element={isAuthenticated ? (role === 'CUSTOMER' ? <CustomerSettings /> : <SettingsView />) : <Navigate to="/login" />} />

          {/* Developer Routes */}
          <Route path="/my-projects" element={isAuthenticated && role === 'DEVELOPER' ? <DeveloperView /> : <Navigate to="/login" />} />
          <Route path="/review" element={isAuthenticated && role === 'DEVELOPER' ? <DeveloperView /> : <Navigate to="/login" />} />
          <Route path="/analytics" element={isAuthenticated && role === 'DEVELOPER' ? <DeveloperView /> : <Navigate to="/login" />} />

          {/* Provider Routes */}
          <Route path="/my-services" element={isAuthenticated && role === 'PROVIDER' ? <ProviderView /> : <Navigate to="/login" />} />
          <Route path="/leads" element={isAuthenticated && role === 'PROVIDER' ? <ProviderView /> : <Navigate to="/login" />} />

          {/* Consultant Routes */}
          <Route path="/review-applications" element={isAuthenticated && role === 'ADMIN' ? <ConsultantView /> : <Navigate to="/login" />} />
          <Route path="/consultation" element={isAuthenticated && role === 'ADMIN' ? <ConsultantView /> : <Navigate to="/login" />} />
          <Route path="/reports" element={isAuthenticated && role === 'ADMIN' ? <ConsultantView /> : <Navigate to="/login" />} />

          {/* Shared Routes */}
          <Route path="/settings" element={
            <div className="flex flex-col items-center justify-center h-[60vh] text-center">
              <div className="w-20 h-20 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-400 mb-4">
                <Settings size={40} />
              </div>
              <h2 className="text-xl font-bold text-zinc-900">Cài đặt tài khoản</h2>
              <p className="text-zinc-500 mt-2">Tính năng đang được cập nhật.</p>
            </div>
          } />
        </Routes>
      </main>
    </div>
  );
};

export default function App() {
  const [role, setRole] = useState<Role>('CUSTOMER');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        setIsAuthenticated(true);
        // Sync user profile with Firestore
        const userRef = doc(db, 'users', firebaseUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
          setRole(userSnap.data().role as Role);
        } else {
          // Create default profile if not exists
          const defaultRole: Role = 'CUSTOMER';
          await setDoc(userRef, {
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName,
            role: defaultRole
          });
          setRole(defaultRole);
        }
      } else {
        setIsAuthenticated(false);
        setRole('CUSTOMER');
      }
      setIsAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  const handleAuth = (newRole: Role) => {
    // This is now handled by onAuthStateChanged
    // But we keep it for immediate UI feedback if needed
    setIsAuthenticated(true);
    setRole(newRole);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-zinc-50 font-sans selection:bg-emerald-100 selection:text-emerald-900">
        <Navbar 
          role={role} 
          setRole={setRole} 
          isAuthenticated={isAuthenticated} 
          onLogout={handleLogout}
        />
        
        <MainContent role={role} isAuthenticated={isAuthenticated} onAuth={handleAuth} />

        <MobileNav role={role} isAuthenticated={isAuthenticated} />

        <AICopilot />

        {/* Footer */}
        <footer className="bg-white border-t border-zinc-200 py-12 mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="col-span-1 md:col-span-2">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">N</div>
                  <span className="text-lg font-bold text-zinc-900">noxh.ai</span>
                </div>
                <p className="text-sm text-zinc-500 max-w-sm">
                  Nền tảng số hoá giao dịch Nhà ở Xã hội quốc gia. Minh bạch, công bằng và hiệu quả nhờ sức mạnh của AI.
                </p>
              </div>
              <div>
                <h4 className="font-bold text-zinc-900 mb-4">Liên kết</h4>
                <ul className="space-y-2 text-sm text-zinc-500">
                  <li><a href="#" className="hover:text-emerald-600">Về chúng tôi</a></li>
                  <li><a href="#" className="hover:text-emerald-600">Quy định pháp luật</a></li>
                  <li><a href="#" className="hover:text-emerald-600">Hướng dẫn hồ sơ</a></li>
                  <li><a href="#" className="hover:text-emerald-600">Tin tức thị trường</a></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-zinc-900 mb-4">Hỗ trợ</h4>
                <ul className="space-y-2 text-sm text-zinc-500">
                  <li><a href="#" className="hover:text-emerald-600">Trung tâm trợ giúp</a></li>
                  <li><a href="#" className="hover:text-emerald-600">Liên hệ Chuyên viên</a></li>
                  <li><a href="#" className="hover:text-emerald-600">Báo cáo vi phạm</a></li>
                  <li><a href="#" className="hover:text-emerald-600">Điều khoản sử dụng</a></li>
                </ul>
              </div>
            </div>
            <div className="mt-12 pt-8 border-t border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-xs text-zinc-400">© 2024 noxh.ai. Một sản phẩm thuộc Sáng kiến Chuyển đổi số Quốc gia.</p>
              <div className="flex gap-6">
                <a href="#" className="text-zinc-400 hover:text-zinc-900"><ShieldCheck size={20} /></a>
                <a href="#" className="text-zinc-400 hover:text-zinc-900"><MessageSquare size={20} /></a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}
