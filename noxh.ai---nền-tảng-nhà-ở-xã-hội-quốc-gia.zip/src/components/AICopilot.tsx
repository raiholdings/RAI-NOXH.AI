import React, { useState, useEffect, useRef } from 'react';
import { Send, X, MessageSquare, ShieldCheck, FileSearch, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getGeminiClient, geminiModel } from '../services/gemini';

export const AICopilot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'Chào bạn! Tôi là Trợ lý AI của noxh.ai. Tôi có thể giúp bạn kiểm tra điều kiện mua nhà, hướng dẫn chuẩn bị hồ sơ hoặc phân tích giấy tờ của bạn.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: geminiModel,
        contents: userMsg,
        config: {
          systemInstruction: `Bạn là chuyên gia tư vấn Nhà ở Xã hội (NOXH) tại Việt Nam trên nền tảng noxh.ai. 
          Nhiệm vụ:
          1. Giải đáp thắc mắc về Luật Nhà ở 2023 và các Nghị định liên quan (Nghị định 100, 49).
          2. Hướng dẫn chi tiết checklist hồ sơ cho từng đối tượng (công nhân, viên chức, người thu nhập thấp).
          3. Tư vấn về quy trình bốc thăm, chấm điểm và ký hợp đồng.
          4. Luôn nhắc người dùng sử dụng tính năng "Gói hồ sơ chuẩn" để được AI kiểm tra tự động.
          5. Trả lời bằng tiếng Việt, chuyên nghiệp, tin cậy và có trích dẫn điều luật nếu cần.`,
        }
      });
      
      setMessages(prev => [...prev, { role: 'ai', text: response.text || 'Xin lỗi, tôi gặp sự cố khi xử lý yêu cầu.' }]);
    } catch (error: any) {
      console.error('Gemini Error:', error);
      setMessages(prev => [...prev, { role: 'ai', text: error.message || 'Có lỗi xảy ra. Vui lòng thử lại sau.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-emerald-600 text-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-transform z-40"
      >
        <MessageSquare size={24} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-[400px] h-[600px] bg-white rounded-2xl shadow-2xl border border-zinc-200 flex flex-col z-50 overflow-hidden"
          >
            <div className="p-4 bg-emerald-600 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                  <ShieldCheck size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-sm">AI Copilot</h3>
                  <p className="text-[10px] opacity-80">Tư vấn pháp lý & hồ sơ</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-white/10 rounded">
                <X size={20} />
              </button>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-zinc-50">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                    msg.role === 'user' 
                      ? 'bg-emerald-600 text-white rounded-tr-none' 
                      : 'bg-white border border-zinc-200 text-zinc-800 rounded-tl-none shadow-sm'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-zinc-200 p-3 rounded-2xl rounded-tl-none shadow-sm">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-zinc-300 rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-zinc-300 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-zinc-300 rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-zinc-100 bg-white">
              <div className="flex gap-2 mb-3">
                <button className="text-[10px] font-bold bg-zinc-100 text-zinc-600 px-2 py-1 rounded-md hover:bg-zinc-200 flex items-center gap-1">
                  <FileSearch size={12} /> Kiểm tra hồ sơ
                </button>
                <button className="text-[10px] font-bold bg-zinc-100 text-zinc-600 px-2 py-1 rounded-md hover:bg-zinc-200 flex items-center gap-1">
                  <HelpCircle size={12} /> Điều kiện mua
                </button>
              </div>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Nhập câu hỏi của bạn..."
                  className="flex-1 bg-zinc-100 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <button 
                  onClick={handleSend}
                  disabled={isLoading}
                  className="p-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors disabled:opacity-50"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
