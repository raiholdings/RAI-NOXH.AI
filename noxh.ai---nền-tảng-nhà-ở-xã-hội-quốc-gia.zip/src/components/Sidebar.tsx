import React from 'react';
import { 
  LayoutDashboard, 
  Building2, 
  Briefcase, 
  FileText, 
  Settings, 
  Users, 
  ShieldCheck, 
  BarChart3,
  Search,
  MessageSquare
} from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { Role } from '../types';

export const Sidebar = ({ role }: { role: Role }) => {
  const menuItems = {
    CUSTOMER: [
      { label: 'Dashboard', icon: LayoutDashboard, path: '/' },
      { label: 'Dự án NOXH', icon: Building2, path: '/projects' },
      { label: 'Marketplace', icon: Briefcase, path: '/marketplace' },
      { label: 'Hồ sơ của tôi', icon: FileText, path: '/applications' },
      { label: 'Kho tài liệu', icon: ShieldCheck, path: '/vault' },
    ],
    DEVELOPER: [
      { label: 'Tổng quan', icon: LayoutDashboard, path: '/' },
      { label: 'Dự án của tôi', icon: Building2, path: '/my-projects' },
      { label: 'Duyệt hồ sơ', icon: FileText, path: '/review' },
      { label: 'Phân tích', icon: BarChart3, path: '/analytics' },
    ],
    PROVIDER: [
      { label: 'Dashboard', icon: LayoutDashboard, path: '/' },
      { label: 'Dịch vụ của tôi', icon: Briefcase, path: '/my-services' },
      { label: 'Yêu cầu mới', icon: Users, path: '/leads' },
    ],
    ADMIN: [
      { label: 'Dashboard Tư vấn', icon: LayoutDashboard, path: '/' },
      { label: 'Duyệt hồ sơ', icon: FileText, path: '/review-applications' },
      { label: 'Giải đáp AI', icon: MessageSquare, path: '/consultation' },
      { label: 'Báo cáo', icon: BarChart3, path: '/reports' },
    ]
  };

  const currentMenu = menuItems[role] || menuItems.CUSTOMER;

  return (
    <aside className="hidden lg:block w-64 shrink-0">
      <div className="sticky top-24 space-y-1">
        {currentMenu.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => `
              w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors
              ${isActive ? 'bg-emerald-50 text-emerald-600' : 'text-zinc-500 hover:bg-zinc-100'}
            `}
          >
            <item.icon size={20} /> {item.label}
          </NavLink>
        ))}
        <div className="pt-4 mt-4 border-t border-zinc-200">
          <NavLink
            to="/settings"
            className={({ isActive }) => `
              w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors
              ${isActive ? 'bg-emerald-50 text-emerald-600' : 'text-zinc-500 hover:bg-zinc-100'}
            `}
          >
            <Settings size={20} /> Cài đặt
          </NavLink>
        </div>
      </div>
    </aside>
  );
};
