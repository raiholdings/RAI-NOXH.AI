import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  AlertCircle,
  BarChart3,
  Building2,
  ArrowRight,
  Calculator,
  FileDown,
  Download
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { MOCK_PROJECTS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

interface ScoringData {
  income: number;
  residency: 'HANOI' | 'HCM' | 'PROVINCE';
  priorityGroup: string;
  familySize: number;
  currentHousing: 'NONE' | 'RENT' | 'SHARED' | 'OWNED';
  areaPerPerson: number;
}

export const AIScoringTool = () => {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<ScoringData>({
    income: 11000000,
    residency: 'HANOI',
    priorityGroup: 'NONE',
    familySize: 1,
    currentHousing: 'RENT',
    areaPerPerson: 5
  });
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<any>(null);

  const steps = [
    { title: 'Thu nhập & Cư trú', desc: 'Thông tin cơ bản để xác định đối tượng' },
    { title: 'Gia đình & Ưu tiên', desc: 'Các yếu tố cộng điểm theo luật định' },
    { title: 'Thực trạng nhà ở', desc: 'Cơ sở để đánh giá mức độ cấp thiết' }
  ];

  const handleCalculate = async () => {
    setIsCalculating(true);
    try {
      const prompt = `
        Dựa trên thông tin khách hàng sau đây, hãy tính điểm ưu tiên mua Nhà ở Xã hội (thang điểm 100) theo quy định pháp luật Việt Nam hiện hành và đề xuất dự án phù hợp từ danh sách dự án.
        
        Thông tin khách hàng:
        - Thu nhập: ${data.income.toLocaleString()} VNĐ/tháng
        - Nơi cư trú: ${data.residency}
        - Đối tượng ưu tiên: ${data.priorityGroup}
        - Số thành viên gia đình: ${data.familySize}
        - Thực trạng nhà ở: ${data.currentHousing}
        - Diện tích bình quân: ${data.areaPerPerson} m2/người
        
        Danh sách dự án hiện có:
        ${JSON.stringify(MOCK_PROJECTS.map(p => ({ id: p.id, name: p.name, location: p.location, criteria: p.criteria })))}
        
        Yêu cầu phản hồi bằng JSON với cấu trúc:
        {
          "score": number,
          "analysis": "phân tích ngắn gọn về điểm số",
          "eligibility": "CÓ" | "KHÔNG" | "CẦN BỔ SUNG",
          "recommendations": [
            { "projectId": "id", "reason": "lý do đề xuất" }
          ],
          "advice": "lời khuyên để tăng khả năng trúng tuyển",
          "generatedDocuments": [
            { "title": "Tên biểu mẫu", "description": "Mô tả biểu mẫu", "content": "Nội dung biểu mẫu đã điền thông tin" }
          ]
        }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      const resultData = JSON.parse(response.text || '{}');
      setResult(resultData);
      setStep(3);
    } catch (error) {
      console.error('Scoring error:', error);
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div className="bg-white rounded-[32px] border border-zinc-200 shadow-2xl overflow-hidden max-w-4xl mx-auto">
      <div className="bg-zinc-900 p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl -mr-32 -mt-32" />
        <div className="relative z-10 flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Calculator size={24} />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Công cụ Chấm điểm AI</h3>
            <p className="text-zinc-400 text-sm">Tự động hoá thẩm định hồ sơ & Đề xuất dự án phù hợp</p>
          </div>
        </div>
      </div>

      <div className="p-8">
        {step < 3 && (
          <div className="flex justify-between mb-12 relative">
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-zinc-100 -translate-y-1/2 z-0" />
            {steps.map((s, i) => (
              <div key={i} className="relative z-10 flex flex-col items-center gap-2">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all ${
                  step === i ? 'bg-emerald-600 text-white scale-110 shadow-lg shadow-emerald-100' : 
                  step > i ? 'bg-emerald-100 text-emerald-600' : 'bg-white border-2 border-zinc-100 text-zinc-300'
                }`}>
                  {step > i ? <CheckCircle2 size={18} /> : i + 1}
                </div>
                <div className="text-center">
                  <p className={`text-[10px] font-bold uppercase tracking-widest ${step === i ? 'text-zinc-900' : 'text-zinc-400'}`}>{s.title}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div 
              key="step0"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Thu nhập hàng tháng (VNĐ)</label>
                  <input 
                    type="number" 
                    value={data.income}
                    onChange={(e) => setData({...data, income: Number(e.target.value)})}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  />
                  <p className="text-[10px] text-zinc-400 italic">* Thu nhập dưới 11 triệu/tháng thường được ưu tiên</p>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Nơi cư trú hiện tại</label>
                  <select 
                    value={data.residency}
                    onChange={(e) => setData({...data, residency: e.target.value as any})}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  >
                    <option value="HANOI">Hà Nội</option>
                    <option value="HCM">TP. Hồ Chí Minh</option>
                    <option value="PROVINCE">Tỉnh thành khác</option>
                  </select>
                </div>
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div 
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Đối tượng ưu tiên</label>
                  <select 
                    value={data.priorityGroup}
                    onChange={(e) => setData({...data, priorityGroup: e.target.value})}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  >
                    <option value="NONE">Không thuộc diện ưu tiên</option>
                    <option value="REVOLUTIONARY">Người có công với cách mạng</option>
                    <option value="POOR_HOUSEHOLD">Hộ nghèo, cận nghèo</option>
                    <option value="WORKER">Công nhân KCN</option>
                    <option value="OFFICER">Cán bộ, công chức, viên chức</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Số thành viên gia đình</label>
                  <input 
                    type="number" 
                    value={data.familySize}
                    onChange={(e) => setData({...data, familySize: Number(e.target.value)})}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div 
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Thực trạng nhà ở</label>
                  <select 
                    value={data.currentHousing}
                    onChange={(e) => setData({...data, currentHousing: e.target.value as any})}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  >
                    <option value="NONE">Chưa có nhà ở</option>
                    <option value="RENT">Đang thuê nhà</option>
                    <option value="SHARED">Ở nhờ người thân</option>
                    <option value="OWNED">Đã có nhà (nhưng hư hỏng/chật hẹp)</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Diện tích bình quân (m2/người)</label>
                  <input 
                    type="number" 
                    value={data.areaPerPerson}
                    onChange={(e) => setData({...data, areaPerPerson: Number(e.target.value)})}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && result && (
            <motion.div 
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8"
            >
              <div className="flex flex-col md:flex-row gap-8 items-center bg-emerald-50 p-8 rounded-[32px] border border-emerald-100">
                <div className="relative">
                  <svg className="w-32 h-32 transform -rotate-90">
                    <circle
                      cx="64"
                      cy="64"
                      r="58"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      className="text-emerald-100"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="58"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray={364.4}
                      strokeDashoffset={364.4 - (364.4 * result.score) / 100}
                      className="text-emerald-600 transition-all duration-1000"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-bold text-emerald-900">{result.score}</span>
                    <span className="text-[10px] font-bold text-emerald-600 uppercase">Điểm AI</span>
                  </div>
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h4 className="text-xl font-bold text-emerald-900 mb-2">Kết quả Thẩm định AI</h4>
                  <p className="text-emerald-700 text-sm leading-relaxed">{result.analysis}</p>
                  <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 bg-white rounded-full border border-emerald-200 text-emerald-600 text-[10px] font-bold uppercase tracking-widest">
                    <CheckCircle2 size={14} /> Khả năng: {result.eligibility}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="font-bold text-zinc-900 flex items-center gap-2">
                  <Building2 size={20} className="text-emerald-600" /> Dự án đề xuất cho bạn
                </h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {result.recommendations.map((rec: any, i: number) => {
                    const project = MOCK_PROJECTS.find(p => p.id === rec.projectId);
                    if (!project) return null;
                    return (
                      <div key={i} className="p-4 bg-white border border-zinc-100 rounded-2xl shadow-sm hover:shadow-md transition-all group">
                        <div className="flex gap-4">
                          <img src={project.image} className="w-20 h-20 rounded-xl object-cover" referrerPolicy="no-referrer" />
                          <div className="flex-1">
                            <h6 className="font-bold text-zinc-900 text-sm group-hover:text-emerald-600 transition-colors">{project.name}</h6>
                            <p className="text-[10px] text-zinc-500 mt-1 line-clamp-2">{rec.reason}</p>
                            <Link to={`/projects/${project.id}`} className="mt-2 text-[10px] font-bold text-emerald-600 flex items-center gap-1">
                              Xem chi tiết <ArrowRight size={12} />
                            </Link>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-zinc-50 p-6 rounded-2xl border border-zinc-100">
                <h5 className="font-bold text-zinc-900 text-sm mb-2 flex items-center gap-2">
                  <Sparkles size={16} className="text-emerald-600" /> Lời khuyên từ AI
                </h5>
                <p className="text-zinc-600 text-xs leading-relaxed">{result.advice}</p>
              </div>

              {result.generatedDocuments && result.generatedDocuments.length > 0 && (
                <div className="space-y-4">
                  <h5 className="font-bold text-zinc-900 flex items-center gap-2">
                    <FileDown size={20} className="text-emerald-600" /> Bộ hồ sơ chuẩn AI đã tạo cho bạn
                  </h5>
                  <div className="grid grid-cols-1 gap-4">
                    {result.generatedDocuments.map((doc: any, i: number) => (
                      <div key={i} className="bg-white border border-zinc-100 rounded-2xl p-6 shadow-sm">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h6 className="font-bold text-zinc-900">{doc.title}</h6>
                            <p className="text-xs text-zinc-500">{doc.description}</p>
                          </div>
                          <button 
                            onClick={() => {
                              const blob = new Blob([doc.content], { type: 'text/plain' });
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `${doc.title.replace(/\s+/g, '_')}.txt`;
                              a.click();
                            }}
                            className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100 transition-colors"
                          >
                            <Download size={18} />
                          </button>
                        </div>
                        <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-100 font-mono text-[10px] text-zinc-600 whitespace-pre-wrap max-h-40 overflow-y-auto">
                          {doc.content}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button 
                onClick={() => setStep(0)}
                className="w-full py-4 text-zinc-500 font-bold text-sm hover:text-zinc-900 transition-colors"
              >
                Thực hiện lại
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {step < 3 && (
          <div className="mt-12 flex justify-between items-center">
            <button 
              onClick={() => setStep(Math.max(0, step - 1))}
              disabled={step === 0}
              className="flex items-center gap-2 text-zinc-400 font-bold text-sm hover:text-zinc-900 disabled:opacity-0 transition-all"
            >
              <ChevronLeft size={20} /> Quay lại
            </button>
            
            {step < 2 ? (
              <button 
                onClick={() => setStep(step + 1)}
                className="px-8 py-4 bg-zinc-900 text-white rounded-2xl font-bold text-sm hover:bg-zinc-800 transition-all flex items-center gap-2"
              >
                Tiếp theo <ChevronRight size={20} />
              </button>
            ) : (
              <button 
                onClick={handleCalculate}
                disabled={isCalculating}
                className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold text-sm hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100 disabled:opacity-50"
              >
                {isCalculating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Đang thẩm định...
                  </>
                ) : (
                  <>
                    Chấm điểm ngay <Sparkles size={18} />
                  </>
                )}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
