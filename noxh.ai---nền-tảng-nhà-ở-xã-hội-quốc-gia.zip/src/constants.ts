import { Project, Application, ServiceProvider } from './types';

export const MOCK_PROJECTS: Project[] = [
  {
    id: '1',
    name: 'NOXH Evergreen Bắc Giang',
    location: 'TP. Bắc Giang',
    developer: 'Evergreen Group',
    developerLogo: 'https://picsum.photos/seed/logo1/100/100',
    priceRange: '12 - 15 triệu/m2',
    status: 'OPEN',
    image: 'https://picsum.photos/seed/noxh1/800/600',
    images: [
      'https://picsum.photos/seed/noxh1/800/600',
      'https://picsum.photos/seed/noxh1b/800/600',
      'https://picsum.photos/seed/noxh1c/800/600'
    ],
    units: 450,
    description: 'Dự án nhà ở xã hội hiện đại với đầy đủ tiện ích, công viên, trường học.',
    criteria: ['Hộ khẩu Bắc Giang', 'Chưa có nhà ở', 'Thu nhập thấp'],
    timeline: [
      { label: 'Công bố dự án', date: '01/01/2024', status: 'completed' },
      { label: 'Tiếp nhận hồ sơ', date: '15/02/2024', status: 'current' },
      { label: 'Xét duyệt', date: '01/04/2024', status: 'upcoming' },
      { label: 'Bốc thăm/Ký hợp đồng', date: '15/05/2024', status: 'upcoming' },
    ]
  },
  {
    id: '2',
    name: 'Nhà ở Xã hội Rice City Tố Hữu',
    location: 'Nam Từ Liêm, Hà Nội',
    developer: 'BIC Việt Nam',
    developerLogo: 'https://picsum.photos/seed/logo2/100/100',
    priceRange: '18 - 20 triệu/m2',
    status: 'UPCOMING',
    image: 'https://picsum.photos/seed/noxh2/800/600',
    images: [
      'https://picsum.photos/seed/noxh2/800/600',
      'https://picsum.photos/seed/noxh2b/800/600',
      'https://picsum.photos/seed/noxh2c/800/600'
    ],
    units: 280,
    description: 'Vị trí đắc địa tại quận Nam Từ Liêm, kết nối giao thông thuận tiện.',
    criteria: ['Hộ khẩu Hà Nội', 'Chưa có nhà ở tại Hà Nội', 'Thu nhập dưới 11tr/tháng'],
    timeline: [
      { label: 'Công bố dự án', date: '10/03/2024', status: 'upcoming' },
      { label: 'Tiếp nhận hồ sơ', date: 'TBA', status: 'upcoming' },
    ]
  },
  {
    id: '3',
    name: 'Dự án NOXH 384 Lê Thánh Tông',
    location: 'Ngô Quyền, Hải Phòng',
    developer: 'Moonlight Dev',
    developerLogo: 'https://picsum.photos/seed/logo3/100/100',
    priceRange: '14 - 16 triệu/m2',
    status: 'OPEN',
    image: 'https://picsum.photos/seed/noxh3/800/600',
    images: [
      'https://picsum.photos/seed/noxh3/800/600',
      'https://picsum.photos/seed/noxh3b/800/600',
      'https://picsum.photos/seed/noxh3c/800/600'
    ],
    units: 1200,
    description: 'Khu đô thị quy mô lớn nhất Hải Phòng dành cho người lao động.',
    criteria: ['Hộ khẩu Hải Phòng', 'Đối tượng ưu tiên', 'Thu nhập thấp'],
    timeline: [
      { label: 'Tiếp nhận hồ sơ', date: 'Đang diễn ra', status: 'current' },
    ]
  }
];

export const MOCK_APPLICATIONS: Application[] = [
  {
    id: 'APP-001',
    projectId: '1',
    projectName: 'NOXH Evergreen Bắc Giang',
    userId: 'user-1',
    status: 'REVIEWING',
    submittedAt: '2024-02-15',
    score: 85,
    documents: [
      { id: 'doc-1', type: 'ID_CARD', name: 'CCCD Mặt trước', status: 'VERIFIED', updatedAt: '2024-02-14' },
      { id: 'doc-2', type: 'RESIDENCY', name: 'Xác nhận cư trú', status: 'PENDING', updatedAt: '2024-02-14' },
    ]
  }
];

export const MOCK_PROVIDERS: ServiceProvider[] = [
  {
    id: 'p1',
    name: 'Vietcombank - CN Hà Nội',
    category: 'BANK',
    rating: 4.9,
    description: 'Gói vay ưu đãi NOXH lãi suất 4.8%/năm cố định 5 năm. Hỗ trợ giải ngân nhanh chóng cho các dự án liên kết.',
    image: 'https://picsum.photos/seed/bank1/400/300',
    priceInfo: 'Lãi suất 4.8%/năm',
    verified: true,
    packages: [
      {
        id: 'pkg1',
        name: 'Gói Vay Ưu Đãi NOXH',
        price: '4.8%/năm',
        description: 'Dành cho khách hàng mua NOXH lần đầu.',
        features: ['Vay tối đa 80% giá trị', 'Thời hạn lên đến 25 năm', 'Ân hạn nợ gốc 12 tháng']
      },
      {
        id: 'pkg2',
        name: 'Gói Vay Thương Mại',
        price: '7.5%/năm',
        description: 'Dành cho các đối tượng không thuộc diện ưu đãi.',
        features: ['Thủ tục đơn giản', 'Giải ngân trong 3 ngày', 'Không phí trả nợ trước hạn sau 3 năm']
      }
    ]
  },
  {
    id: 'p2',
    name: 'VP Công chứng Số 1',
    category: 'NOTARY',
    rating: 4.8,
    description: 'Dịch vụ công chứng hồ sơ tại nhà, nhanh chóng, đúng pháp luật. Chuyên xử lý hồ sơ mua bán NOXH.',
    image: 'https://picsum.photos/seed/notary1/400/300',
    priceInfo: 'Từ 200k/bộ',
    verified: true,
    packages: [
      {
        id: 'pkg3',
        name: 'Công chứng Hợp đồng Mua bán',
        price: '1.200.000đ',
        description: 'Trọn gói công chứng hợp đồng mua bán nhà ở.',
        features: ['Kiểm tra tình trạng pháp lý', 'Soạn thảo văn bản chuẩn', 'Hỗ trợ ký tại nhà']
      },
      {
        id: 'pkg4',
        name: 'Xác thực Hồ sơ Pháp lý',
        price: '200.000đ/bộ',
        description: 'Sao y bản chính và chứng thực chữ ký.',
        features: ['Lấy ngay trong ngày', 'Đảm bảo tính pháp lý', 'Hỗ trợ giao tận nơi']
      }
    ]
  },
  {
    id: 'p3',
    name: 'Luật Việt & Cộng sự',
    category: 'LEGAL',
    rating: 4.7,
    description: 'Tư vấn chuyên sâu về điều kiện và thủ tục mua Nhà ở Xã hội. Hỗ trợ rà soát hồ sơ tránh bị loại.',
    image: 'https://picsum.photos/seed/legal1/400/300',
    priceInfo: 'Từ 500k/lần',
    verified: true,
    packages: [
      {
        id: 'pkg5',
        name: 'Rà soát Hồ sơ NOXH',
        price: '500.000đ',
        description: 'Kiểm tra tính hợp lệ của toàn bộ giấy tờ trước khi nộp.',
        features: ['Đối chiếu quy định pháp luật', 'Phát hiện sai sót thông tin', 'Hướng dẫn bổ sung giấy tờ']
      },
      {
        id: 'pkg6',
        name: 'Đại diện Ủy quyền',
        price: '2.500.000đ',
        description: 'Thay mặt khách hàng thực hiện các thủ tục hành chính.',
        features: ['Nộp hồ sơ trực tiếp', 'Theo dõi tiến độ xét duyệt', 'Giải trình với cơ quan chức năng']
      }
    ]
  },
  {
    id: 'p4',
    name: 'Bảo hiểm Bảo Việt',
    category: 'INSURANCE',
    rating: 4.6,
    description: 'Cung cấp các gói bảo hiểm cháy nổ và bảo hiểm khoản vay bắt buộc khi mua nhà trả góp.',
    image: 'https://picsum.photos/seed/ins1/400/300',
    priceInfo: '0.1% GTCH/năm',
    verified: true,
    packages: [
      {
        id: 'pkg7',
        name: 'Bảo hiểm Cháy nổ Bắt buộc',
        price: '0.05% GTCH',
        description: 'Tuân thủ quy định phòng cháy chữa cháy cho căn hộ chung cư.',
        features: ['Bồi thường thiệt hại tài sản', 'Hỗ trợ chi phí tạm trú', 'Thủ tục bồi thường nhanh']
      },
      {
        id: 'pkg8',
        name: 'Bảo hiểm Người vay vốn',
        price: '0.5% khoản vay',
        description: 'Đảm bảo khả năng trả nợ trong trường hợp rủi ro.',
        features: ['Tất toán khoản vay ngân hàng', 'Bảo vệ quyền lợi gia đình', 'Phí đóng một lần']
      }
    ]
  }
];
