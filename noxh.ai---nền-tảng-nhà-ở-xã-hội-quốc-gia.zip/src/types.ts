export type Role = 'CUSTOMER' | 'DEVELOPER' | 'PROVIDER' | 'ADMIN';

export interface UserProfile {
  id: string;
  name: string;
  role: Role;
  email: string;
  avatar?: string;
  kycStatus: 'VERIFIED' | 'PENDING' | 'UNVERIFIED';
}

export interface Project {
  id: string;
  name: string;
  location: string;
  developer: string;
  developerLogo?: string;
  priceRange: string;
  status: 'OPEN' | 'UPCOMING' | 'CLOSED';
  image: string;
  images?: string[];
  units: number;
  description: string;
  criteria: string[];
  timeline: {
    label: string;
    date: string;
    status: 'completed' | 'current' | 'upcoming';
  }[];
}

export interface Application {
  id: string;
  projectId: string;
  projectName: string;
  userId: string;
  status: 'DRAFT' | 'SUBMITTED' | 'REVIEWING' | 'APPROVED' | 'REJECTED' | 'CONTRACTING';
  submittedAt?: string;
  score: number;
  documents: AppDocument[];
  feedback?: string;
}

export interface AppDocument {
  id: string;
  type: string;
  name: string;
  status: 'VERIFIED' | 'PENDING' | 'REJECTED' | 'MISSING';
  url?: string;
  updatedAt: string;
}

export interface ServiceProvider {
  id: string;
  name: string;
  category: 'BANK' | 'LEGAL' | 'NOTARY' | 'INSURANCE';
  rating: number;
  description: string;
  image: string;
  priceInfo: string;
  packages: ServicePackage[];
  verified: boolean;
}

export interface ServicePackage {
  id: string;
  name: string;
  price: string;
  features: string[];
  description: string;
}

export interface ServiceContract {
  id: string;
  providerId: string;
  providerName: string;
  packageId: string;
  packageName: string;
  status: 'PENDING' | 'SIGNED' | 'EXPIRED';
  signedAt?: string;
  documentUrl?: string;
}
