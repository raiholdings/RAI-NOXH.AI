import React, { useState } from 'react';
import { 
  Building2, 
  ChevronRight, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  ArrowLeft,
  X,
  ShieldCheck,
  Info
} from 'lucide-react';
import { MOCK_APPLICATIONS } from '../constants';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

const ApplicationDetailModal = ({ app, onClose }: { app: any, onClose: () => void }) => {
  if (!app) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
        >
          <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center">
                <Building2 size={20} />
              </div>
              <div>
                <h3 className="font-bold text-zinc-900">Chi tiết hồ sơ</h3>
                <p className="text-xs text-zinc-500">Mã hồ sơ: {app.id}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
              <X size={20} className="text-zinc-400" />
            </button>
          </div>

          <div className="p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block mb-2">Dự án đăng ký</label>
                  <p className="text-lg font-bold text-zinc-900">{app.projectName}</p>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block mb-2">Ngày nộp</label>
                  <p className="text-sm font-medium text-zinc-700">{app.submittedAt}</p>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block mb-2">Trạng thái hiện tại</label>
                  <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                    app.status === 'REVIEWING' ? 'bg-blue-50 text-blue-600' :
                    app.status === 'APPROVED' ? 'bg-emerald-50 text-emerald-600' :
                    'bg-zinc-100 text-zinc-500'
                  }`}>
                    {app.status === 'REVIEWING' ? 'Đang xét duyệt' : app.status === 'APPROVED' ? 'Đã phê duyệt' : 'Bản nháp'}
                  </div>
                </div>
              </div>

              <div className="bg-zinc-900 rounded-3xl p-6 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
                <div className="relative z-10">
                  <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-4">Đánh giá từ AI</p>
                  <div className="flex items-end gap-2 mb-4">
                    <span className="text-5xl font-black text-white">{app.score}</span>
                    <span className="text-xl text-zinc-500 font-bold mb-1">/100</span>
                  </div>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Hồ sơ của bạn có độ tin cậy cao. AI dự báo khả năng được phê duyệt là 92% dựa trên các tiêu chí hiện tại.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                <ShieldCheck size={18} className="text-emerald-600" /> Danh sách tài liệu đính kèm
              </h4>
              <div className="grid grid-cols-1 gap-3">
                {app.documents.map((doc: any) => (
                  <div key={doc.id} className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white rounded-xl border border-zinc-200 flex items-center justify-center text-zinc-400">
                        <FileText size={18} />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-zinc-900">{doc.name}</p>
                        <p className="text-[10px] text-zinc-500 uppercase tracking-wider">{doc.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-1 rounded ${
                        doc.status === 'VERIFIED' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'
                      }`}>
                        {doc.status === 'VERIFIED' ? 'Đã xác minh' : 'Chờ duyệt'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl flex items-start gap-3">
              <Info size={18} className="text-blue-600 shrink-0 mt-0.5" />
              <p className="text-xs text-blue-700 leading-relaxed">
                Hồ sơ đang ở giai đoạn <strong>Thẩm định thực tế</strong>. Cán bộ xét duyệt có thể sẽ liên hệ với bạn qua số điện thoại đã đăng ký trong vòng 3-5 ngày tới.
              </p>
            </div>
          </div>

          <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-end gap-3">
            <button onClick={onClose} className="px-6 py-2.5 bg-white border border-zinc-200 text-zinc-600 rounded-xl text-sm font-bold hover:bg-zinc-100 transition-all">
              Đóng
            </button>
            <button className="px-6 py-2.5 bg-zinc-900 text-white rounded-xl text-sm font-bold hover:bg-zinc-800 transition-all">
              Tải xuống bản sao
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export const ApplicationsView = () => {
  const [selectedApp, setSelectedApp] = useState<any>(null);

  return (
    <div className="space-y-8">
      <ApplicationDetailModal app={selectedApp} onClose={() => setSelectedApp(null)} />
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900">Hồ sơ của tôi</h1>
          <p className="text-zinc-500 mt-1">Quản lý và theo dõi trạng thái các hồ sơ đăng ký mua NOXH.</p>
        </div>
      </header>

      <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-zinc-100 bg-zinc-50/50">
          <h3 className="font-bold text-zinc-900">Danh sách hồ sơ</h3>
        </div>
        <div className="divide-y divide-zinc-100">
          {MOCK_APPLICATIONS.map((app) => (
            <div 
              key={app.id} 
              onClick={() => setSelectedApp(app)}
              className="p-6 hover:bg-zinc-50 transition-colors cursor-pointer group"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                    <Building2 size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-zinc-900 text-lg">{app.projectName}</h4>
                    <p className="text-xs text-zinc-500 mt-1 flex items-center gap-2">
                      Mã hồ sơ: <span className="font-mono font-bold text-zinc-700">{app.id}</span>
                      <span className="w-1 h-1 bg-zinc-300 rounded-full" />
                      Ngày nộp: {app.submittedAt}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 md:gap-8">
                  <div className="text-left md:text-right">
                    <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Điểm AI</p>
                    <div className="flex items-center gap-1.5">
                      <span className="text-lg font-black text-emerald-600">{app.score}</span>
                      <span className="text-xs text-zinc-400">/100</span>
                    </div>
                  </div>

                  <div className="text-left md:text-right min-w-[120px]">
                    <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Trạng thái</p>
                    <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                      app.status === 'REVIEWING' ? 'bg-blue-50 text-blue-600' :
                      app.status === 'APPROVED' ? 'bg-emerald-50 text-emerald-600' :
                      'bg-zinc-100 text-zinc-500'
                    }`}>
                      {app.status === 'REVIEWING' ? (
                        <>
                          <Clock size={14} className="animate-pulse" /> Đang xét duyệt
                        </>
                      ) : app.status === 'APPROVED' ? (
                        <>
                          <CheckCircle2 size={14} /> Đã phê duyệt
                        </>
                      ) : (
                        <>
                          <AlertCircle size={14} /> Bản nháp
                        </>
                      )}
                    </div>
                  </div>

                  <button className="p-2 text-zinc-400 hover:text-zinc-900 transition-colors">
                    <ChevronRight size={24} />
                  </button>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {app.documents.map((doc) => (
                  <div key={doc.id} className="flex items-center justify-between p-3 bg-zinc-50 rounded-xl border border-zinc-100">
                    <div className="flex items-center gap-2">
                      <FileText size={14} className="text-zinc-400" />
                      <span className="text-xs font-medium text-zinc-600 truncate max-w-[120px]">{doc.name}</span>
                    </div>
                    <span className={`text-[10px] font-bold ${
                      doc.status === 'VERIFIED' ? 'text-emerald-600' : 'text-amber-600'
                    }`}>
                      {doc.status === 'VERIFIED' ? 'Đã duyệt' : 'Chờ'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-100 p-6 rounded-3xl flex items-start gap-4">
        <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm shrink-0">
          <AlertCircle size={24} />
        </div>
        <div>
          <h3 className="font-bold text-blue-900">Lưu ý về tiến độ</h3>
          <p className="text-sm text-blue-700 mt-1 leading-relaxed">
            Thời gian xét duyệt trung bình cho các dự án NOXH là từ 15-30 ngày làm việc. 
            Hệ thống AI của chúng tôi sẽ thông báo ngay khi có thay đổi về trạng thái hồ sơ của bạn.
          </p>
        </div>
      </div>
    </div>
  );
};
