import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, 
  ShieldCheck, 
  Search, 
  FileText, 
  Users, 
  Building2, 
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  MessageSquare,
  MapPin,
  Sparkles,
  Zap,
  Lock,
  Globe,
  BarChart3,
  Scale,
  Bell,
  Calculator
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AIScoringTool } from '../components/AIScoringTool';
import { MOCK_PROJECTS } from '../constants';

const FloatingBadge = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <motion.div 
    animate={{ y: [0, -10, 0] }}
    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
    className={`absolute bg-white/90 backdrop-blur-md px-4 py-2 rounded-2xl shadow-xl border border-white/20 flex items-center gap-3 z-20 ${className}`}
  >
    {children}
  </motion.div>
);

const ProjectCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (containerRef.current) {
      setWidth(containerRef.current.scrollWidth - containerRef.current.offsetWidth);
    }
  }, []);

  const next = () => {
    if (currentIndex < MOCK_PROJECTS.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const prev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    } else {
      setCurrentIndex(MOCK_PROJECTS.length - 1);
    }
  };

  return (
    <div className="relative group">
      <div className="overflow-hidden rounded-[40px]" ref={containerRef}>
        <motion.div 
          drag="x"
          dragConstraints={{ right: 0, left: -width }}
          className="flex gap-6 cursor-grab active:cursor-grabbing py-4"
        >
          {MOCK_PROJECTS.map((project) => (
            <motion.div 
              key={project.id} 
              className="min-w-[300px] md:min-w-[400px] bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden hover:shadow-xl hover:shadow-emerald-50/50 transition-all duration-500"
            >
              <Link to={`/projects/${project.id}`}>
                <div className="h-64 overflow-hidden relative">
                  <img 
                    src={project.image} 
                    alt={project.name} 
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-700" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      project.status === 'OPEN' ? 'bg-emerald-500 text-white' : 'bg-zinc-500 text-white'
                    }`}>
                      {project.status === 'OPEN' ? 'Đang mở bán' : 'Sắp mở bán'}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="bg-white/90 backdrop-blur-md p-3 rounded-2xl shadow-lg border border-white/20">
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Giá từ</p>
                      <p className="text-lg font-bold text-emerald-600">{project.priceRange}</p>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="font-bold text-zinc-900 text-xl leading-tight line-clamp-2">{project.name}</h4>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-zinc-500 flex items-center gap-2">
                      <Building2 size={16} className="text-emerald-500" /> {project.developer}
                    </p>
                    <p className="text-sm text-zinc-500 flex items-center gap-2">
                      <MapPin size={16} className="text-emerald-500" /> {project.location}
                    </p>
                  </div>
                  <div className="mt-6 pt-6 border-t border-zinc-100 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                        <Users size={14} />
                      </div>
                      <span className="text-xs font-bold text-zinc-600">{project.units} căn hộ</span>
                    </div>
                    <div className="flex items-center gap-1 text-emerald-600 font-bold text-sm">
                      Chi tiết <ArrowRight size={16} />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Navigation Buttons */}
      <button 
        onClick={prev}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 backdrop-blur-md rounded-full shadow-xl border border-white/20 flex items-center justify-center text-zinc-900 hover:bg-emerald-600 hover:text-white transition-all opacity-0 group-hover:opacity-100 -translate-x-4 group-hover:translate-x-0 z-20"
      >
        <ChevronLeft size={24} />
      </button>
      <button 
        onClick={next}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 backdrop-blur-md rounded-full shadow-xl border border-white/20 flex items-center justify-center text-zinc-900 hover:bg-emerald-600 hover:text-white transition-all opacity-0 group-hover:opacity-100 translate-x-4 group-hover:translate-x-0 z-20"
      >
        <ChevronRight size={24} />
      </button>

      {/* Progress Dots */}
      <div className="flex justify-center gap-2 mt-8">
        {MOCK_PROJECTS.map((_, i) => (
          <div 
            key={i} 
            className={`h-1.5 rounded-full transition-all duration-300 ${
              currentIndex === i ? 'w-8 bg-emerald-600' : 'w-2 bg-zinc-200'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export const LandingView = () => {
  return (
    <div className="bg-white">
      {/* Hero Section - Recipe 11 Split Layout */}
      <section className="relative min-h-[80vh] lg:min-h-[90vh] flex items-center overflow-hidden pt-12 lg:pt-20">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-50/50 hidden lg:block" />
          <div className="absolute top-1/4 left-1/4 w-64 h-64 lg:w-96 lg:h-96 bg-emerald-200/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 lg:w-96 lg:h-96 bg-blue-200/20 rounded-full blur-3xl animate-pulse delay-700" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="lg:grid lg:grid-cols-12 lg:gap-16 items-center">
            <div className="lg:col-span-7 text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-100/50 text-emerald-700 text-[10px] lg:text-xs font-bold tracking-widest uppercase mb-6 lg:mb-8 border border-emerald-200/50">
                  <Sparkles size={14} /> Sáng kiến chuyển đổi số quốc gia
                </div>
                <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold tracking-tight text-zinc-900 leading-[1.1] mb-6 lg:mb-8">
                  Nền tảng Tiếp thị <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">
                    NOXH ứng dụng AI
                  </span>
                </h1>
                <p className="text-lg lg:text-xl text-zinc-500 leading-relaxed max-w-xl mb-8 lg:mb-10 mx-auto lg:mx-0">
                  noxh.ai không chỉ là nơi tìm nhà. Chúng tôi là hệ sinh thái truyền thông thông minh, giúp bạn thẩm định hồ sơ, chấm điểm ưu tiên và kết nối dự án phù hợp nhất bằng sức mạnh Trí tuệ nhân tạo.
                </p>
                <div className="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
                  <button
                    onClick={() => document.getElementById('ai-tool-section')?.scrollIntoView({ behavior: 'smooth' })}
                    className="px-8 lg:px-10 py-4 lg:py-5 bg-zinc-900 text-white rounded-2xl font-bold text-base lg:text-lg hover:bg-zinc-800 transition-all shadow-2xl shadow-zinc-200 flex items-center justify-center gap-2 group"
                  >
                    Bắt đầu ngay <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                  </button>
                  <Link
                    to="/projects"
                    className="px-8 lg:px-10 py-4 lg:py-5 bg-white text-zinc-900 border border-zinc-200 rounded-2xl font-bold text-base lg:text-lg hover:bg-zinc-50 transition-all text-center"
                  >
                    Tìm dự án
                  </Link>
                </div>
                
                <div className="mt-10 lg:mt-12 flex flex-wrap justify-center lg:justify-start items-center gap-6 lg:gap-8 border-t border-zinc-100 pt-8">
                  <div>
                    <p className="text-xl lg:text-2xl font-bold text-zinc-900">1.2M+</p>
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Hồ sơ đã nộp</p>
                  </div>
                  <div className="hidden sm:block w-px h-10 bg-zinc-100" />
                  <div>
                    <p className="text-xl lg:text-2xl font-bold text-zinc-900">150+</p>
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Dự án niêm yết</p>
                  </div>
                  <div className="hidden sm:block w-px h-10 bg-zinc-100" />
                  <div className="flex -space-x-3">
                    {[1,2,3,4].map(i => (
                      <div key={i} className="w-8 h-8 lg:w-10 lg:h-10 rounded-full border-2 border-white bg-zinc-200 overflow-hidden">
                        <img src={`https://i.pravatar.cc/150?u=${i}`} alt="user" />
                      </div>
                    ))}
                    <div className="w-8 h-8 lg:w-10 lg:h-10 rounded-full border-2 border-white bg-emerald-100 flex items-center justify-center text-emerald-600 text-[10px] font-bold">
                      +99
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            <div className="lg:col-span-5 mt-16 lg:mt-0 relative px-4 lg:px-0">
              <motion.div
                initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
                animate={{ opacity: 1, scale: 1, rotate: 0 }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="relative z-10"
              >
                <div className="relative rounded-[32px] lg:rounded-[40px] overflow-hidden shadow-[0_40px_80px_-15px_rgba(0,0,0,0.15)] border-4 lg:border-[12px] border-white">
                  <img 
                    src="https://picsum.photos/seed/noxh-main/800/1000" 
                    alt="App Preview" 
                    className="w-full aspect-[4/5] object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                </div>

                {/* Floating Badges - Hidden on very small screens, smaller on mobile */}
                <FloatingBadge className="top-6 -left-4 lg:top-10 lg:-left-10 scale-75 lg:scale-100">
                  <div className="w-8 h-8 lg:w-10 lg:h-10 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
                    <ShieldCheck size={18} />
                  </div>
                  <div>
                    <p className="text-[8px] lg:text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Xác thực</p>
                    <p className="text-xs lg:text-sm font-bold text-zinc-900">Định danh VNeID</p>
                  </div>
                </FloatingBadge>

                <FloatingBadge className="bottom-16 -right-4 lg:bottom-20 lg:-right-10 scale-75 lg:scale-100 delay-1000">
                  <div className="w-8 h-8 lg:w-10 lg:h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
                    <Zap size={18} />
                  </div>
                  <div>
                    <p className="text-[8px] lg:text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tốc độ</p>
                    <p className="text-xs lg:text-sm font-bold text-zinc-900">Duyệt hồ sơ 24h</p>
                  </div>
                </FloatingBadge>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Scoring Tool Section */}
      <section id="ai-tool-section" className="py-20 lg:py-32 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, black 1px, transparent 0)', backgroundSize: '32px 32px' }} />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16 lg:mb-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold tracking-widest uppercase mb-6 border border-emerald-200">
                <Calculator size={14} /> Công cụ độc quyền
              </div>
              <h2 className="text-3xl lg:text-5xl font-bold text-zinc-900 mb-6 tracking-tight">
                Tự động hoá <span className="text-emerald-600">Thẩm định hồ sơ</span>
              </h2>
              <p className="text-zinc-500 text-base lg:text-lg max-w-2xl mx-auto">
                Sử dụng thuật toán AI để tính toán điểm ưu tiên của bạn theo khung pháp lý mới nhất. Nhận ngay danh sách dự án có tỷ lệ trúng tuyển cao nhất.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <AIScoringTool />
          </motion.div>
        </div>
      </section>

      {/* Role-based Section - Who is it for? */}
      <section className="py-20 lg:py-32 bg-zinc-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-3xl lg:text-4xl font-bold text-zinc-900 mb-4 tracking-tight">Giải pháp cho mọi đối tượng</h2>
            <p className="text-zinc-500 text-base lg:text-lg max-w-2xl mx-auto">
              Chúng tôi xây dựng hệ sinh thái minh bạch kết nối người dân, chủ đầu tư và các đơn vị cung cấp dịch vụ.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {[
              {
                role: 'Người tìm nhà',
                title: 'Hiện thực hóa giấc mơ an cư',
                desc: 'Tìm kiếm dự án phù hợp, kiểm tra điều kiện hưởng chính sách và nộp hồ sơ trực tuyến chỉ trong vài phút.',
                features: ['Tư vấn AI 24/7', 'Theo dõi trạng thái Real-time', 'Kho tài liệu số bảo mật'],
                icon: Users,
                color: 'emerald',
                cta: 'Đăng ký ngay'
              },
              {
                role: 'Chủ đầu tư',
                title: 'Quản lý bán hàng thông minh',
                desc: 'Số hoá quy trình tiếp nhận hồ sơ, tự động phân loại và chấm điểm khách hàng theo đúng quy định.',
                features: ['Dashboard quản lý tập trung', 'Báo cáo tự động', 'Hệ thống thẩm định AI'],
                icon: Building2,
                color: 'zinc',
                cta: 'Hợp tác ngay'
              },
              {
                role: 'Đối tác dịch vụ',
                title: 'Mở rộng mạng lưới khách hàng',
                desc: 'Cung cấp các dịch vụ tài chính, bảo hiểm, nội thất trực tiếp cho cộng đồng cư dân NOXH.',
                features: ['Tiếp cận khách hàng mục tiêu', 'Quy trình ký kết số', 'Quản lý leads hiệu quả'],
                icon: Globe,
                color: 'blue',
                cta: 'Trở thành đối tác'
              }
            ].map((card, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-8 lg:p-10 rounded-[32px] lg:rounded-[40px] border border-zinc-200 shadow-sm flex flex-col h-full"
              >
                <div className={`w-12 h-12 lg:w-16 lg:h-16 rounded-2xl flex items-center justify-center mb-6 lg:mb-8 ${
                  card.color === 'emerald' ? 'bg-emerald-100 text-emerald-600' :
                  card.color === 'blue' ? 'bg-blue-100 text-blue-600' : 'bg-zinc-100 text-zinc-900'
                }`}>
                  <card.icon size={28} />
                </div>
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-2">{card.role}</p>
                <h3 className="text-xl lg:text-2xl font-bold text-zinc-900 mb-4 leading-tight">{card.title}</h3>
                <p className="text-sm lg:text-base text-zinc-500 mb-6 lg:mb-8 flex-grow">{card.desc}</p>
                <ul className="space-y-3 mb-8 lg:mb-10">
                  {card.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-3 text-xs lg:text-sm font-medium text-zinc-700">
                      <CheckCircle2 size={16} className="text-emerald-500" /> {f}
                    </li>
                  ))}
                </ul>
                <button className={`w-full py-4 rounded-2xl font-bold transition-all ${
                  card.color === 'emerald' ? 'bg-emerald-600 text-white hover:bg-emerald-700' :
                  card.color === 'blue' ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-zinc-900 text-white hover:bg-zinc-800'
                }`}>
                  {card.cta}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Showcase Section - Recipe 3 Hardware/Tool feel */}
      <section className="py-20 lg:py-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-zinc-900 rounded-[40px] lg:rounded-[60px] p-8 lg:p-24 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-full h-full opacity-20 pointer-events-none">
              <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-emerald-500/20 to-transparent" />
              <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.05) 1px, transparent 0)', backgroundSize: '40px 40px' }} />
            </div>

            <div className="lg:grid lg:grid-cols-2 lg:gap-20 items-center relative z-10">
              <div>
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold tracking-widest uppercase mb-6 lg:mb-8 border border-emerald-500/20">
                  <Sparkles size={14} /> Trí tuệ nhân tạo (RAG)
                </div>
                <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6 lg:mb-8 leading-tight">
                  Trợ lý pháp lý <br /> 
                  <span className="text-emerald-400">Luôn sẵn sàng 24/7</span>
                </h2>
                <p className="text-zinc-400 text-base lg:text-lg mb-8 lg:mb-10 leading-relaxed">
                  Hệ thống AI của chúng tôi được huấn luyện trên hàng ngàn văn bản quy phạm pháp luật về Nhà ở Xã hội. Hỏi bất cứ điều gì, nhận câu trả lời chính xác kèm trích dẫn nguồn luật.
                </p>
                
                <div className="space-y-6">
                  {[
                    { icon: Search, title: 'Tra cứu điều kiện', desc: 'Kiểm tra bạn có thuộc đối tượng được mua NOXH hay không.' },
                    { icon: FileText, title: 'Hướng dẫn hồ sơ', desc: 'Danh mục giấy tờ cần thiết cho từng trường hợp cụ thể.' },
                    { icon: Scale, title: 'Giải đáp chính sách', desc: 'Cập nhật các quy định mới nhất từ Bộ Xây dựng.' }
                  ].map((item, i) => (
                    <div key={i} className="flex gap-4 lg:gap-5">
                      <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-emerald-400 shrink-0">
                        <item.icon size={20} />
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-sm lg:text-base mb-1">{item.title}</h4>
                        <p className="text-xs lg:text-sm text-zinc-500">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-12 lg:mt-0">
                <div className="bg-zinc-800/50 backdrop-blur-xl rounded-2xl lg:rounded-3xl border border-white/10 p-5 lg:p-6 shadow-2xl">
                  <div className="flex items-center justify-between mb-6 lg:mb-8 border-b border-white/5 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 lg:w-10 lg:h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white font-bold text-xs">N</div>
                      <div>
                        <p className="text-xs lg:text-sm font-bold text-white">noxh.ai Assistant</p>
                        <p className="text-[8px] lg:text-[10px] text-emerald-400 font-bold uppercase tracking-widest">Online</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
                      <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
                      <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
                    </div>
                  </div>

                  <div className="space-y-4 lg:space-y-6 mb-6 lg:mb-8">
                    <div className="flex gap-3">
                      <div className="w-6 h-6 lg:w-8 lg:h-8 rounded-full bg-zinc-700 shrink-0" />
                      <div className="bg-zinc-700/50 p-3 lg:p-4 rounded-xl lg:rounded-2xl rounded-tl-none text-xs lg:text-sm text-zinc-300 max-w-[85%]">
                        Tôi là công nhân tại KCN Bắc Thăng Long, tôi có được mua NOXH không?
                      </div>
                    </div>
                    <div className="flex gap-3 justify-end">
                      <div className="bg-emerald-600/20 border border-emerald-500/20 p-3 lg:p-4 rounded-xl lg:rounded-2xl rounded-tr-none text-xs lg:text-sm text-emerald-50 text-left max-w-[85%]">
                        <p className="mb-2">Chào bạn, theo <strong>Điều 49 Luật Nhà ở 2014</strong>, công nhân đang làm việc tại các khu công nghiệp là đối tượng được hưởng chính sách hỗ trợ về nhà ở xã hội.</p>
                        <p className="text-[8px] lg:text-[10px] font-bold text-emerald-400 uppercase tracking-widest mt-3 lg:mt-4">Nguồn: Luật Nhà ở 2014, Khoản 5 Điều 49</p>
                      </div>
                      <div className="w-6 h-6 lg:w-8 lg:h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white font-bold text-[8px] lg:text-[10px] shrink-0">N</div>
                    </div>
                  </div>

                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Hỏi về quy định NOXH..." 
                      className="w-full bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl py-3 lg:py-4 px-4 lg:px-6 text-xs lg:text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-all"
                    />
                    <button className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 lg:w-10 lg:h-10 bg-emerald-600 text-white rounded-lg lg:rounded-xl flex items-center justify-center hover:bg-emerald-500 transition-all">
                      <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Transparency / Journey Section - Recipe 1 Technical Grid */}
      <section className="py-32 bg-zinc-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-bold text-zinc-900 mb-4 tracking-tight">Quy trình minh bạch</h2>
            <p className="text-zinc-500 text-lg max-w-2xl mx-auto">
              Mọi bước trong hành trình của bạn đều được ghi nhận và có thể theo dõi trực tuyến.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { step: '01', title: 'Đăng ký & Xác thực', desc: 'Xác thực định danh qua VNeID để đảm bảo tính chính xác của thông tin.', icon: ShieldCheck },
              { step: '02', title: 'Tìm kiếm & Tư vấn', desc: 'Chọn dự án và sử dụng AI để kiểm tra điều kiện nộp hồ sơ.', icon: Search },
              { step: '03', title: 'Nộp hồ sơ số', desc: 'Tải lên các giấy tờ cần thiết, AI sẽ kiểm tra tính hợp lệ tức thì.', icon: FileText },
              { step: '04', title: 'Theo dõi & Nhận kết quả', desc: 'Theo dõi tiến độ duyệt hồ sơ và nhận thông báo kết quả qua App.', icon: Bell }
            ].map((item, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-zinc-200 relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                  <item.icon size={120} />
                </div>
                <p className="text-4xl font-extrabold text-emerald-600/20 mb-6 font-mono">{item.step}</p>
                <h4 className="text-xl font-bold text-zinc-900 mb-3">{item.title}</h4>
                <p className="text-sm text-zinc-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Preview */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-16">
            <div>
              <h2 className="text-4xl font-bold text-zinc-900 tracking-tight">Dự án đang mở bán</h2>
              <p className="text-zinc-500 mt-4 text-lg">Khám phá các cơ hội an cư mới nhất trên toàn quốc.</p>
            </div>
            <Link to="/projects" className="flex items-center gap-2 text-emerald-600 font-bold hover:underline text-lg">
              Xem tất cả <ChevronRight size={24} />
            </Link>
          </div>

          <ProjectCarousel />
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 bg-zinc-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/carbon-fibre.png")' }} />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl md:text-6xl font-extrabold text-white mb-8 tracking-tight">
              Bắt đầu hành trình <br /> <span className="text-emerald-500">An cư ngay hôm nay</span>
            </h2>
            <p className="text-zinc-400 text-xl max-w-2xl mx-auto mb-12 leading-relaxed">
              Tham gia cùng 1.2 triệu người dùng khác và trải nghiệm quy trình mua nhà hiện đại nhất Việt Nam.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <Link to="/register" className="px-12 py-6 bg-emerald-600 text-white rounded-2xl font-bold text-xl hover:bg-emerald-500 transition-all shadow-2xl shadow-emerald-900/20">
                Đăng ký tài khoản
              </Link>
              <Link to="/about" className="px-12 py-6 bg-white/5 text-white border border-white/10 rounded-2xl font-bold text-xl hover:bg-white/10 transition-all">
                Tìm hiểu thêm
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

