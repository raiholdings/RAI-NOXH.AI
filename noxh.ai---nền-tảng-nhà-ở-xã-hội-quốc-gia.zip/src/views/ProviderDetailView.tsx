import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Star, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowLeft, 
  Info, 
  FileSignature,
  CreditCard,
  MessageSquare
} from 'lucide-react';
import { MOCK_PROVIDERS } from '../constants';
import { ServicePackage } from '../types';

export const ProviderDetailView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const provider = MOCK_PROVIDERS.find(p => p.id === id);
  const [selectedPackage, setSelectedPackage] = useState<ServicePackage | null>(null);

  if (!provider) return <div>Provider not found</div>;

  const handleSignContract = (pkg: ServicePackage) => {
    // Navigate to contract signing flow
    navigate(`/marketplace/sign/${provider.id}/${pkg.id}`);
  };

  return (
    <div className="space-y-8">
      <Link to="/marketplace" className="flex items-center gap-2 text-zinc-500 hover:text-zinc-900 transition-colors">
        <ArrowLeft size={20} /> Quay lại Marketplace
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
            <div className="h-64 overflow-hidden relative">
              <img src={provider.image} alt={provider.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              <div className="absolute top-6 right-6 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-amber-500 shadow-xl border border-white/20">
                <Star size={18} fill="currentColor" />
                <span className="text-sm font-bold">{provider.rating} / 5.0</span>
              </div>
            </div>
            <div className="p-8">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-bold uppercase tracking-wider">
                      {provider.category}
                    </span>
                    {provider.verified && (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-blue-600 uppercase tracking-wider">
                        <ShieldCheck size={12} /> Đã xác thực
                      </span>
                    )}
                  </div>
                  <h1 className="text-3xl font-bold text-zinc-900">{provider.name}</h1>
                </div>
                <button className="p-3 bg-zinc-100 text-zinc-900 rounded-2xl hover:bg-emerald-600 hover:text-white transition-all">
                  <MessageSquare size={24} />
                </button>
              </div>

              <div className="mt-8">
                <h3 className="text-xl font-bold text-zinc-900">Giới thiệu</h3>
                <p className="text-zinc-600 mt-4 leading-relaxed">
                  {provider.description}
                </p>
              </div>

              <div className="mt-12">
                <h3 className="text-xl font-bold text-zinc-900 mb-6">Bảng giá & Gói dịch vụ</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {provider.packages.map((pkg) => (
                    <div 
                      key={pkg.id} 
                      className={`p-6 rounded-3xl border-2 transition-all cursor-pointer ${
                        selectedPackage?.id === pkg.id 
                          ? 'border-emerald-600 bg-emerald-50/30' 
                          : 'border-zinc-100 hover:border-zinc-200 bg-zinc-50/30'
                      }`}
                      onClick={() => setSelectedPackage(pkg)}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <h4 className="font-bold text-zinc-900 text-lg">{pkg.name}</h4>
                        <p className="text-emerald-600 font-black text-xl">{pkg.price}</p>
                      </div>
                      <p className="text-sm text-zinc-500 mb-6">{pkg.description}</p>
                      <ul className="space-y-3">
                        {pkg.features.map((feature, i) => (
                          <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                            <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSignContract(pkg);
                        }}
                        className="mt-8 w-full py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-emerald-600 transition-all flex items-center justify-center gap-2"
                      >
                        <FileSignature size={18} /> Ký hợp đồng online
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm sticky top-24">
            <h3 className="text-xl font-bold text-zinc-900 mb-6">Quy trình ký kết</h3>
            <div className="space-y-6 relative">
              <div className="absolute left-4 top-2 bottom-2 w-0.5 bg-zinc-100" />
              {[
                { label: 'Chọn gói dịch vụ', desc: 'Lựa chọn gói phù hợp với nhu cầu của bạn.', icon: CheckCircle2 },
                { label: 'Xác nhận thông tin', desc: 'Hệ thống tự động lấy thông tin từ hồ sơ NOXH.', icon: CheckCircle2 },
                { label: 'Ký số online', desc: 'Sử dụng chữ ký số hoặc xác thực qua VNeID.', icon: FileSignature },
                { label: 'Thanh toán & Kích hoạt', desc: 'Thanh toán phí dịch vụ để bắt đầu.', icon: CreditCard },
              ].map((step, i) => (
                <div key={i} className="flex gap-4 relative z-10">
                  <div className="w-8 h-8 rounded-full bg-white border-2 border-emerald-500 text-emerald-500 flex items-center justify-center shrink-0">
                    <step.icon size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-zinc-900">{step.label}</p>
                    <p className="text-xs text-zinc-500 mt-1">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-8 border-t border-zinc-100">
              <div className="flex items-start gap-3 p-4 bg-blue-50 text-blue-700 rounded-2xl mb-6">
                <Info size={20} className="shrink-0" />
                <p className="text-xs leading-relaxed">
                  Hợp đồng điện tử có giá trị pháp lý tương đương hợp đồng giấy theo Luật Giao dịch điện tử.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
