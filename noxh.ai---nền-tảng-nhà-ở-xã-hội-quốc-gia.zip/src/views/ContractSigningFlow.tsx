import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  FileSignature, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight,
  Loader2,
  Lock,
  Download
} from 'lucide-react';
import { MOCK_PROVIDERS } from '../constants';
import { motion, AnimatePresence } from 'motion/react';

export const ContractSigningFlow = () => {
  const { providerId, packageId } = useParams();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: 'Nguyễn Văn A',
    idNumber: '038090001234',
    address: '123 Đường Láng, Đống Đa, Hà Nội',
    phone: '0987654321',
    email: 'nguyenvana@example.com'
  });
  const [isSigning, setIsSigning] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  const provider = MOCK_PROVIDERS.find(p => p.id === providerId);
  const pkg = provider?.packages.find(p => p.id === packageId);

  if (!provider || !pkg) return <div>Invalid request</div>;

  const handleSign = () => {
    setIsSigning(true);
    // Simulate signing process
    setTimeout(() => {
      setIsSigning(false);
      setIsCompleted(true);
      setStep(4);
    }, 3000);
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="mb-12 flex items-center justify-between">
        <Link to={`/marketplace/${provider.id}`} className="flex items-center gap-2 text-zinc-500 hover:text-zinc-900 transition-colors">
          <ArrowLeft size={20} /> Quay lại
        </Link>
        <div className="flex items-center gap-4">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                step === s ? 'bg-emerald-600 text-white' : 
                step > s ? 'bg-emerald-100 text-emerald-600' : 'bg-zinc-100 text-zinc-400'
              }`}>
                {step > s ? <CheckCircle2 size={16} /> : s}
              </div>
              {s < 4 && <div className={`w-12 h-0.5 mx-2 ${step > s ? 'bg-emerald-600' : 'bg-zinc-200'}`} />}
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div 
            key="step1"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h2 className="text-2xl font-bold text-zinc-900 mb-6">Xác nhận gói dịch vụ</h2>
              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100 flex justify-between items-center">
                <div>
                  <p className="text-xs text-emerald-600 font-bold uppercase tracking-widest mb-1">Gói đã chọn</p>
                  <h3 className="text-xl font-bold text-emerald-900">{pkg.name}</h3>
                  <p className="text-sm text-emerald-700 mt-1">{provider.name}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-emerald-600">{pkg.price}</p>
                  <p className="text-xs text-emerald-500">Thanh toán sau khi ký</p>
                </div>
              </div>
              
              <div className="mt-8 space-y-4">
                <h4 className="font-bold text-zinc-900">Quyền lợi gói dịch vụ:</h4>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {pkg.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                      <CheckCircle2 size={16} className="text-emerald-500" /> {f}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="flex justify-end">
              <button 
                onClick={() => setStep(2)}
                className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2"
              >
                Tiếp tục <ArrowRight size={20} />
              </button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div 
            key="step2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h2 className="text-2xl font-bold text-zinc-900 mb-6">Thông tin hợp đồng</h2>
              <p className="text-sm text-zinc-500 mb-8">Vui lòng kiểm tra và bổ sung thông tin cá nhân để đưa vào hợp đồng.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Họ và tên</label>
                  <input 
                    type="text" 
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Số CCCD</label>
                  <input 
                    type="text" 
                    value={formData.idNumber}
                    onChange={(e) => setFormData({...formData, idNumber: e.target.value})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Địa chỉ thường trú</label>
                  <input 
                    type="text" 
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Số điện thoại</label>
                  <input 
                    type="text" 
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Email</label>
                  <input 
                    type="email" 
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-between">
              <button 
                onClick={() => setStep(1)}
                className="px-8 py-4 border border-zinc-200 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-50 transition-all"
              >
                Quay lại
              </button>
              <button 
                onClick={() => setStep(3)}
                className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2"
              >
                Xem hợp đồng <ArrowRight size={20} />
              </button>
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div 
            key="step3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h2 className="text-2xl font-bold text-zinc-900 mb-6">Ký kết hợp đồng điện tử</h2>
              <div className="space-y-6">
                <div className="h-96 overflow-y-auto p-8 bg-zinc-50 rounded-2xl border border-zinc-100 text-sm text-zinc-600 leading-relaxed font-serif">
                  <div className="text-center mb-8">
                    <h3 className="text-lg font-bold text-zinc-900 uppercase">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</h3>
                    <p className="font-bold">Độc lập - Tự do - Hạnh phúc</p>
                    <div className="w-32 h-px bg-zinc-300 mx-auto mt-2" />
                  </div>
                  
                  <h4 className="text-center text-lg font-bold text-zinc-900 mb-8 uppercase">HỢP ĐỒNG CUNG CẤP DỊCH VỤ {pkg.name.toUpperCase()}</h4>
                  
                  <p className="mb-4 italic">Hôm nay, ngày {new Date().toLocaleDateString('vi-VN')}, tại nền tảng noxh.ai, chúng tôi gồm:</p>
                  
                  <div className="mb-6">
                    <p className="font-bold text-zinc-900">BÊN A (KHÁCH HÀNG):</p>
                    <p>Ông/Bà: <strong>{formData.fullName}</strong></p>
                    <p>CCCD số: {formData.idNumber}</p>
                    <p>Địa chỉ: {formData.address}</p>
                    <p>Điện thoại: {formData.phone}</p>
                  </div>

                  <div className="mb-6">
                    <p className="font-bold text-zinc-900">BÊN B (ĐƠN VỊ CUNG CẤP):</p>
                    <p>Tên đơn vị: <strong>{provider.name}</strong></p>
                    <p>Đại diện: Ban Giám đốc</p>
                    <p>Địa chỉ: Trụ sở chính đơn vị cung cấp</p>
                  </div>

                  <p className="mb-4">Hai bên thống nhất ký kết hợp đồng với các điều khoản sau:</p>
                  <p className="mb-4"><strong>Điều 1: Nội dung dịch vụ</strong><br />Bên B cung cấp gói {pkg.name} bao gồm: {pkg.features.join(', ')}.</p>
                  <p className="mb-4"><strong>Điều 2: Giá trị hợp đồng</strong><br />Phí dịch vụ là {pkg.price}. Hình thức thanh toán: Chuyển khoản qua cổng thanh toán noxh.ai.</p>
                  <p className="mb-4"><strong>Điều 3: Cam kết</strong><br />Bên B cam kết thực hiện đúng tiến độ và chất lượng. Bên A cam kết cung cấp thông tin trung thực.</p>
                  
                  <div className="mt-12 grid grid-cols-2 gap-8 text-center">
                    <div>
                      <p className="font-bold uppercase mb-12">ĐẠI DIỆN BÊN B</p>
                      <div className="relative inline-block">
                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-20 rotate-12">
                          <ShieldCheck size={60} className="text-blue-600" />
                        </div>
                        <p className="text-blue-600 font-bold italic">Đã ký số bởi {provider.name}</p>
                      </div>
                    </div>
                    <div>
                      <p className="font-bold uppercase mb-12">ĐẠI DIỆN BÊN A</p>
                      <p className="text-zinc-300 italic">Chờ ký số...</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-100 rounded-2xl">
                  <Lock className="text-amber-600 shrink-0" size={20} />
                  <p className="text-xs text-amber-800">
                    Bằng cách nhấn "Xác nhận ký số", bạn đồng ý sử dụng chữ ký điện tử để ký kết hợp đồng này.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <button 
                onClick={() => setStep(2)}
                className="px-8 py-4 border border-zinc-200 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-50 transition-all"
              >
                Quay lại
              </button>
              <div className="flex gap-4">
                <button 
                  onClick={handleSign}
                  disabled={isSigning}
                  className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100"
                >
                  {isSigning ? <Loader2 className="animate-spin" size={20} /> : <FileSignature size={20} />}
                  Xác nhận ký số
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {step === 4 && (
          <motion.div 
            key="step3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-8"
          >
            <div className="bg-white p-12 rounded-[40px] border border-zinc-200 shadow-xl max-w-2xl mx-auto">
              <div className="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-emerald-200">
                <CheckCircle2 size={48} />
              </div>
              <h2 className="text-3xl font-bold text-zinc-900 mb-4">Ký kết thành công!</h2>
              <p className="text-zinc-500 mb-10 leading-relaxed">
                Hợp đồng dịch vụ <strong>{pkg.name}</strong> giữa bạn và <strong>{provider.name}</strong> đã được ký kết thành công và có hiệu lực ngay lập tức.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="px-8 py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all flex items-center justify-center gap-2">
                  <Download size={20} /> Tải hợp đồng (PDF)
                </button>
                <Link to="/customer" className="px-8 py-4 border border-zinc-200 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-50 transition-all">
                  Về Dashboard
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
