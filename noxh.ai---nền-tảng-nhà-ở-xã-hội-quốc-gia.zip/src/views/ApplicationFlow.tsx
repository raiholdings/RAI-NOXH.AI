import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  Upload, 
  ShieldCheck, 
  FileText, 
  AlertCircle,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_PROJECTS } from '../constants';

export const ApplicationFlow = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const project = MOCK_PROJECTS.find(p => p.id === id);
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!project) return <div>Project not found</div>;

  const steps = [
    { id: 1, label: 'Điều kiện' },
    { id: 2, label: 'Thông tin' },
    { id: 3, label: 'Hồ sơ' },
    { id: 4, label: 'Hoàn tất' }
  ];

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
    else {
      setIsSubmitting(true);
      setTimeout(() => {
        navigate('/');
      }, 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-8">
          {steps.map((s, i) => (
            <React.Fragment key={s.id}>
              <div className="flex flex-col items-center gap-2 relative z-10">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all ${
                  step >= s.id ? 'bg-emerald-600 text-white' : 'bg-zinc-200 text-zinc-500'
                }`}>
                  {step > s.id ? <CheckCircle2 size={20} /> : s.id}
                </div>
                <span className={`text-[10px] font-bold uppercase tracking-wider ${
                  step >= s.id ? 'text-emerald-600' : 'text-zinc-400'
                }`}>
                  {s.label}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div className="flex-1 h-0.5 bg-zinc-200 mx-4 -mt-6" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden min-h-[500px] flex flex-col">
        <div className="p-8 flex-1">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div 
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold text-zinc-900">Kiểm tra điều kiện tiên quyết</h2>
                <p className="text-zinc-500">Dựa trên quy định của dự án {project.name}, bạn cần xác nhận các điều kiện sau:</p>
                <div className="space-y-4">
                  {[
                    'Tôi chưa sở hữu nhà ở tại địa phương nơi có dự án.',
                    'Thu nhập của tôi và các thành viên trong hộ gia đình không thuộc diện nộp thuế thu nhập cá nhân thường xuyên.',
                    'Tôi có hộ khẩu thường trú hoặc tạm trú trên 1 năm tại địa phương này.'
                  ].map((text, i) => (
                    <label key={i} className="flex items-start gap-4 p-4 rounded-2xl border border-zinc-100 hover:border-emerald-200 transition-colors cursor-pointer group">
                      <input type="checkbox" className="mt-1 w-5 h-5 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500" />
                      <span className="text-sm text-zinc-700 font-medium">{text}</span>
                    </label>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div 
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold text-zinc-900">Thông tin người đăng ký</h2>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Họ và tên</label>
                    <input type="text" defaultValue="Nguyễn Văn A" className="w-full p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Số CCCD</label>
                    <input type="text" defaultValue="001092000123" className="w-full p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Đối tượng ưu tiên</label>
                    <select className="w-full p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500">
                      <option>Người thu nhập thấp</option>
                      <option>Công nhân khu công nghiệp</option>
                      <option>Viên chức nhà nước</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Số thành viên hộ gia đình</label>
                    <input type="number" defaultValue="4" className="w-full p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div 
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold text-zinc-900">Tải lên hồ sơ minh chứng</h2>
                <div className="bg-emerald-50 p-4 rounded-2xl flex items-start gap-3 border border-emerald-100">
                  <ShieldCheck className="text-emerald-600 shrink-0" size={20} />
                  <p className="text-xs text-emerald-700">
                    Hệ thống đã tự động lấy 2 tài liệu từ <b>Kho tài liệu</b> của bạn. Hãy tải lên các tài liệu còn thiếu.
                  </p>
                </div>
                <div className="space-y-3">
                  {[
                    { label: 'CCCD (Mặt trước/sau)', status: 'ready' },
                    { label: 'Xác nhận cư trú (Mẫu CT07)', status: 'ready' },
                    { label: 'Xác nhận thu nhập (Mẫu 03)', status: 'missing' },
                    { label: 'Đơn đăng ký mua NOXH (Mẫu 01)', status: 'missing' }
                  ].map((doc, i) => (
                    <div key={i} className="flex items-center justify-between p-4 rounded-2xl border border-zinc-100 bg-zinc-50">
                      <div className="flex items-center gap-3">
                        <FileText size={18} className="text-zinc-400" />
                        <span className="text-sm font-medium text-zinc-700">{doc.label}</span>
                      </div>
                      {doc.status === 'ready' ? (
                        <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                          <CheckCircle2 size={14} /> Sẵn sàng
                        </span>
                      ) : (
                        <button className="flex items-center gap-2 px-3 py-1.5 bg-white border border-zinc-200 rounded-lg text-xs font-bold hover:bg-zinc-50">
                          <Upload size={14} /> Tải lên
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 4 && (
              <motion.div 
                key="step4"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center h-full text-center space-y-6"
              >
                <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
                  <ShieldCheck size={40} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-zinc-900">Kiểm tra hồ sơ lần cuối</h2>
                  <p className="text-zinc-500 mt-2 max-w-md">
                    AI đã chấm điểm hồ sơ của bạn đạt <b>92/100</b> điểm. Tỷ lệ được duyệt rất cao. Bạn có muốn nộp ngay không?
                  </p>
                </div>
                <div className="w-full max-w-sm p-4 bg-zinc-50 rounded-2xl border border-zinc-100 text-left">
                  <div className="flex justify-between text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2">
                    <span>Dự án</span>
                    <span>Phí nộp</span>
                  </div>
                  <div className="flex justify-between font-bold text-zinc-900">
                    <span>{project.name}</span>
                    <span>Miễn phí</span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-8 border-t border-zinc-100 flex justify-between items-center bg-zinc-50/50">
          <button 
            onClick={() => step > 1 && setStep(step - 1)}
            disabled={step === 1}
            className="flex items-center gap-2 px-6 py-3 text-zinc-500 font-bold hover:text-zinc-900 disabled:opacity-30"
          >
            <ChevronLeft size={20} /> Quay lại
          </button>
          <button 
            onClick={handleNext}
            disabled={isSubmitting}
            className="flex items-center gap-2 px-8 py-3 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
          >
            {isSubmitting ? 'Đang nộp...' : step === 4 ? 'Nộp hồ sơ' : 'Tiếp tục'} <ArrowRight size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};
