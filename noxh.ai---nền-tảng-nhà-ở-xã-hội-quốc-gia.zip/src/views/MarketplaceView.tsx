import React, { useMemo, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { 
  Search, 
  Briefcase, 
  Star, 
  ExternalLink, 
  Filter, 
  Info, 
  ShieldCheck, 
  Sparkles, 
  Send,
  Zap,
  Scale,
  CreditCard,
  FileCheck,
  ChevronRight,
  ArrowRight,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_PROVIDERS } from '../constants';

import { getGeminiClient, geminiModel } from '../services/gemini';

const AIServiceAdvisor = () => {
  const [query, setQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isTyping) return;
    
    setIsTyping(true);
    setResponse(null);
    
    try {
      const ai = getGeminiClient();
      const result = await ai.models.generateContent({
        model: geminiModel,
        contents: query,
        config: {
          systemInstruction: `Bạn là AI Service Advisor trên nền tảng noxh.ai. 
          Nhiệm vụ:
          1. Phân tích nhu cầu của người dùng về dịch vụ hỗ trợ Nhà ở Xã hội (pháp lý, ngân hàng, công chứng, bảo hiểm).
          2. Gợi ý các loại hình dịch vụ phù hợp.
          3. Trả lời ngắn gọn, súc tích, chuyên nghiệp bằng tiếng Việt.
          4. Nếu người dùng hỏi về dự án cụ thể, hãy tư vấn dựa trên bối cảnh đó.`,
        }
      });
      setResponse(result.text || 'Xin lỗi, tôi không tìm thấy thông tin phù hợp.');
    } catch (error: any) {
      console.error('Gemini Error:', error);
      setResponse('Có lỗi xảy ra khi kết nối với AI. Vui lòng thử lại sau.');
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="bg-zinc-900 rounded-[32px] lg:rounded-[40px] p-6 lg:p-12 relative overflow-hidden text-white mb-12 lg:mb-16">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-blue-500/10 to-transparent pointer-events-none" />
      
      <div className="relative z-10 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 text-[10px] font-bold tracking-widest uppercase mb-4 lg:mb-6 border border-blue-500/20">
          <Sparkles size={12} /> AI Service Advisor
        </div>
        <h2 className="text-2xl lg:text-4xl font-bold mb-4 lg:mb-6 tracking-tight">Tư vấn dịch vụ <br /><span className="text-blue-400">Tối ưu cho hồ sơ của bạn</span></h2>
        <p className="text-zinc-400 mb-8 lg:mb-10 text-sm lg:text-lg">Bạn đang gặp khó khăn ở bước nào? AI sẽ gợi ý các đối tác dịch vụ uy tín nhất để giúp bạn hoàn thiện hồ sơ nhanh chóng.</p>
        
        <form onSubmit={handleSearch} className="relative mb-6 lg:mb-8">
          <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ví dụ: Tư vấn vay vốn ngân hàng..." 
            className="w-full bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl py-4 lg:py-5 px-5 lg:px-6 pr-14 lg:pr-16 text-white placeholder:text-zinc-600 focus:outline-none focus:border-blue-500/50 transition-all text-sm lg:text-lg"
          />
          <button 
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 lg:w-12 lg:h-12 bg-blue-600 text-white rounded-lg lg:rounded-xl flex items-center justify-center hover:bg-blue-500 transition-all shadow-xl shadow-blue-900/20"
          >
            <Send size={18} />
          </button>
        </form>

        <AnimatePresence>
          {(isTyping || response) && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl p-4 lg:p-6 backdrop-blur-md"
            >
              {isTyping ? (
                <div className="flex items-center gap-3 text-zinc-400">
                  <div className="flex gap-1">
                    <div className="w-1 h-1 lg:w-1.5 lg:h-1.5 bg-blue-500 rounded-full animate-bounce" />
                    <div className="w-1 h-1 lg:w-1.5 lg:h-1.5 bg-blue-500 rounded-full animate-bounce delay-100" />
                    <div className="w-1 h-1 lg:w-1.5 lg:h-1.5 bg-blue-500 rounded-full animate-bounce delay-200" />
                  </div>
                  <span className="text-xs lg:text-sm font-medium">AI đang tìm kiếm đối tác phù hợp...</span>
                </div>
              ) : (
                <div className="flex gap-3 lg:gap-4">
                  <div className="w-6 h-6 lg:w-8 lg:h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-[8px] lg:text-[10px] shrink-0">N</div>
                  <div>
                    <p className="text-zinc-200 leading-relaxed text-xs lg:text-sm">
                      {response}
                    </p>
                    <div className="mt-4 flex gap-3">
                      <button className="text-[8px] lg:text-[10px] font-bold uppercase tracking-widest text-blue-400 hover:text-blue-300 transition-colors">Xem báo giá ngay</button>
                      <button className="text-[8px] lg:text-[10px] font-bold uppercase tracking-widest text-zinc-500 hover:text-zinc-400 transition-colors">Hỏi thêm</button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export const MarketplaceView = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const projectName = queryParams.get('project');
  const projectLocation = queryParams.get('location');
  
  const [activeCategory, setActiveCategory] = useState('Tất cả');
  const [searchQuery, setSearchQuery] = useState(projectLocation || '');

  const categories = [
    { label: 'Tất cả', value: 'ALL', icon: Globe },
    { label: 'Pháp lý', value: 'LEGAL', icon: Scale },
    { label: 'Ngân hàng', value: 'BANK', icon: CreditCard },
    { label: 'Công chứng', value: 'NOTARY', icon: FileCheck },
    { label: 'Bảo hiểm', value: 'INSURANCE', icon: ShieldCheck }
  ];

  const filteredProviders = useMemo(() => {
    return MOCK_PROVIDERS.filter(provider => {
      const matchesCategory = activeCategory === 'Tất cả' || provider.category === categories.find(c => c.label === activeCategory)?.value;
      const matchesSearch = provider.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           provider.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
      <header className="mb-8 lg:mb-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="text-3xl lg:text-4xl font-extrabold text-zinc-900 tracking-tight">Marketplace Dịch vụ</h1>
            <p className="text-zinc-500 mt-2 text-base lg:text-lg">Hệ sinh thái đối tác hỗ trợ hồ sơ, tài chính và pháp lý chuyên nghiệp.</p>
          </div>
          <div className="flex gap-3">
            <div className="relative flex-grow md:flex-grow-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
              <input 
                type="text" 
                placeholder="Tìm dịch vụ..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-3 bg-white border border-zinc-200 rounded-xl lg:rounded-2xl text-sm focus:ring-2 focus:ring-blue-500 outline-none w-full md:w-72 shadow-sm"
              />
            </div>
            <button className="p-3 bg-white border border-zinc-200 rounded-xl lg:rounded-2xl text-zinc-500 hover:text-zinc-900 shadow-sm transition-all">
              <Filter size={20} />
            </button>
          </div>
        </div>
      </header>

      <AIServiceAdvisor />

      {projectName && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 lg:mb-10 p-4 lg:p-5 bg-blue-50 border border-blue-100 rounded-2xl lg:rounded-[32px] flex items-center gap-4 text-blue-900 shadow-sm"
        >
          <div className="w-10 h-10 lg:w-12 lg:h-12 bg-blue-600 text-white rounded-xl lg:rounded-2xl flex items-center justify-center shrink-0">
            <Info size={20} />
          </div>
          <div>
            <p className="text-xs lg:text-sm font-medium">
              Đang hiển thị các dịch vụ hỗ trợ cho dự án <span className="font-bold">{projectName}</span> tại <span className="font-bold">{projectLocation}</span>.
            </p>
            <button className="text-[10px] lg:text-xs font-bold text-blue-600 hover:underline mt-1">Xóa bộ lọc dự án</button>
          </div>
        </motion.div>
      )}

      <div className="flex gap-3 mb-8 lg:mb-12 overflow-x-auto pb-4 no-scrollbar -mx-4 px-4 lg:mx-0 lg:px-0 scroll-smooth">
        {categories.map((cat) => (
          <button 
            key={cat.value} 
            onClick={() => setActiveCategory(cat.label)}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl lg:rounded-2xl text-sm font-bold transition-all shrink-0 ${
              activeCategory === cat.label 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' 
                : 'bg-white text-zinc-500 border border-zinc-200 hover:border-blue-200 hover:text-blue-600'
            }`}
          >
            <cat.icon size={18} />
            {cat.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
        {filteredProviders.map((provider) => (
          <motion.div
            key={provider.id}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="group"
          >
            <Link 
              to={`/marketplace/${provider.id}`} 
              className="block bg-white rounded-[24px] lg:rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden hover:shadow-2xl hover:shadow-blue-50/50 transition-all duration-500 h-full flex flex-col"
            >
              <div className="h-48 lg:h-56 overflow-hidden relative">
                <img 
                  src={provider.image} 
                  alt={provider.name} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                  referrerPolicy="no-referrer" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-amber-500 shadow-lg border border-white/20">
                  <Star size={14} fill="currentColor" />
                  <span className="text-xs font-bold">{provider.rating}</span>
                </div>
                {provider.verified && (
                  <div className="absolute top-4 left-4 bg-blue-600 text-white p-2 rounded-xl shadow-lg">
                    <ShieldCheck size={18} />
                  </div>
                )}
                <div className="absolute bottom-4 left-4">
                  <span className="px-3 py-1 bg-white/20 backdrop-blur-md border border-white/30 rounded-lg text-[10px] font-bold text-white uppercase tracking-widest">
                    {provider.category}
                  </span>
                </div>
              </div>
              <div className="p-6 lg:p-8 flex-grow flex flex-col">
                <h4 className="text-lg lg:text-xl font-bold text-zinc-900 group-hover:text-blue-600 transition-colors mb-2 lg:mb-3">{provider.name}</h4>
                <p className="text-xs lg:text-sm text-zinc-500 line-clamp-3 leading-relaxed mb-6 lg:mb-8 flex-grow">{provider.description}</p>
                
                <div className="grid grid-cols-2 gap-3 lg:gap-4 mb-6 lg:mb-8">
                  <div className="bg-zinc-50 p-3 rounded-xl lg:rounded-2xl border border-zinc-100">
                    <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Kinh nghiệm</p>
                    <p className="text-xs lg:text-sm font-bold text-zinc-900">10+ năm</p>
                  </div>
                  <div className="bg-zinc-50 p-3 rounded-xl lg:rounded-2xl border border-zinc-100">
                    <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Phản hồi</p>
                    <p className="text-xs lg:text-sm font-bold text-zinc-900">~15 phút</p>
                  </div>
                </div>

                <div className="pt-6 border-t border-zinc-100 flex justify-between items-center">
                  <div>
                    <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Phí dịch vụ từ</p>
                    <p className="text-base lg:text-lg font-bold text-zinc-900">{provider.priceInfo}</p>
                  </div>
                  <div className="w-10 h-10 lg:w-12 lg:h-12 bg-zinc-100 text-zinc-900 rounded-xl lg:rounded-2xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                    <ArrowRight size={18} />
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="mt-16 lg:mt-24 bg-zinc-50 rounded-[32px] lg:rounded-[40px] p-8 lg:p-12 text-center border border-zinc-100">
        <h3 className="text-xl lg:text-2xl font-bold text-zinc-900 mb-4">Bạn là đơn vị cung cấp dịch vụ?</h3>
        <p className="text-sm lg:text-zinc-500 mb-8 lg:mb-10 max-w-xl mx-auto">Gia nhập hệ sinh thái noxh.ai để tiếp cận hàng triệu khách hàng tiềm năng đang có nhu cầu về nhà ở xã hội.</p>
        <button className="w-full md:w-auto px-10 py-4 lg:py-5 bg-zinc-900 text-white rounded-xl lg:rounded-2xl font-bold hover:bg-zinc-800 transition-all flex items-center justify-center gap-2 mx-auto">
          Đăng ký đối tác <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
};
