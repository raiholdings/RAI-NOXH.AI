import React from 'react';
import { 
  ShieldCheck, 
  Users, 
  Building2, 
  Briefcase, 
  AlertCircle, 
  CheckCircle2, 
  BarChart3,
  MessageSquare,
  Search,
  ArrowRight,
  FileText,
  Clock,
  Sparkles,
  TrendingUp,
  Filter
} from 'lucide-react';
import { motion } from 'motion/react';

export const ConsultantView = () => {
  const stats = [
    { label: 'Hồ sơ chờ duyệt', value: '42', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Yêu cầu tư vấn', value: '18', icon: MessageSquare, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Cảnh báo AI', value: '05', icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'Tỷ lệ hoàn thành', value: '94%', icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-50' },
  ];

  const recentApplications = [
    { id: 'APP-8821', name: 'Nguyễn Văn B', project: 'Evergreen Bắc Giang', status: 'PENDING', score: 82, time: '10 phút trước' },
    { id: 'APP-8820', name: 'Trần Thị C', project: 'Nhà ở xã hội Rice City', status: 'REVIEWING', score: 75, time: '25 phút trước' },
    { id: 'APP-8819', name: 'Lê Văn D', project: 'Him Lam Thượng Thanh', status: 'PENDING', score: 91, time: '1 giờ trước' },
  ];

  return (
    <div className="space-y-6 lg:space-y-8 pb-20 lg:pb-0">
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-zinc-900">Dashboard Chuyên viên</h1>
          <p className="text-xs lg:text-base text-zinc-500 mt-1">Chào buổi sáng! Bạn có 42 hồ sơ cần rà soát.</p>
        </div>
        <div className="flex items-center gap-2 lg:gap-3">
          <div className="relative flex-grow lg:flex-grow-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
            <input 
              type="text" 
              placeholder="Tìm hồ sơ..." 
              className="pl-10 pr-4 py-2 bg-white border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none w-full lg:w-64 shadow-sm"
            />
          </div>
          <button className="p-2 bg-white border border-zinc-200 rounded-xl text-zinc-500 hover:text-zinc-900 shadow-sm transition-all">
            <Filter size={20} />
          </button>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {stats.map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-4 lg:p-6 rounded-2xl lg:rounded-3xl border border-zinc-200 shadow-sm"
          >
            <div className="flex justify-between items-start mb-3 lg:mb-4">
              <div className={`p-2 lg:p-3 ${stat.bg} ${stat.color} rounded-xl lg:rounded-2xl`}>
                <stat.icon size={20} />
              </div>
              <span className="text-[8px] lg:text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Hôm nay</span>
            </div>
            <p className="text-xl lg:text-3xl font-black text-zinc-900">{stat.value}</p>
            <p className="text-[10px] lg:text-sm text-zinc-500 mt-1">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        {/* Main Review Section */}
        <div className="lg:col-span-2 space-y-6 lg:space-y-8">
          <section className="bg-white rounded-[24px] lg:rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden">
            <div className="p-5 lg:p-6 border-b border-zinc-100 flex justify-between items-center">
              <h2 className="text-lg lg:text-xl font-bold text-zinc-900">Hồ sơ mới nộp</h2>
              <button className="text-xs lg:text-sm font-bold text-emerald-600 hover:underline">Xem tất cả</button>
            </div>
            <div className="p-4 lg:p-6">
              <div className="space-y-3 lg:space-y-4">
                {recentApplications.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-3 lg:p-4 rounded-xl lg:rounded-2xl border border-zinc-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all group">
                    <div className="flex items-center gap-3 lg:gap-4">
                      <div className="w-10 h-10 lg:w-12 lg:h-12 bg-zinc-100 rounded-lg lg:rounded-xl flex items-center justify-center text-zinc-400 group-hover:bg-white group-hover:text-emerald-600 transition-colors">
                        <User size={20} />
                      </div>
                      <div>
                        <h4 className="font-bold text-zinc-900 text-sm lg:text-base">{app.name}</h4>
                        <p className="text-[10px] lg:text-xs text-zinc-500 line-clamp-1">{app.project} • {app.id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 lg:gap-8">
                      <div className="text-right hidden sm:block">
                        <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Điểm AI</p>
                        <p className={`text-sm lg:text-base font-bold ${app.score >= 80 ? 'text-emerald-600' : 'text-amber-600'}`}>{app.score}/100</p>
                      </div>
                      <div className={`px-2 py-0.5 lg:px-3 lg:py-1 rounded-full text-[8px] lg:text-[10px] font-bold uppercase tracking-wider shrink-0 ${
                        app.status === 'PENDING' ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'
                      }`}>
                        {app.status === 'PENDING' ? 'Chờ duyệt' : 'Đang rà soát'}
                      </div>
                      <button className="p-2 bg-zinc-900 text-white rounded-lg lg:rounded-xl opacity-0 group-hover:opacity-100 transition-opacity hidden lg:block">
                        <ArrowRight size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-zinc-900 rounded-[24px] lg:rounded-[32px] p-6 lg:p-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 lg:w-64 lg:h-64 bg-emerald-500/10 rounded-full blur-3xl" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 lg:mb-6">
                <div className="w-8 h-8 lg:w-10 lg:h-10 bg-emerald-500 rounded-lg lg:rounded-xl flex items-center justify-center">
                  <Sparkles size={16} />
                </div>
                <h3 className="text-lg lg:text-xl font-bold">AI Copilot</h3>
              </div>
              <p className="text-zinc-400 mb-6 lg:mb-8 text-xs lg:text-base max-w-lg">Sử dụng AI để tự động rà soát hồ sơ, phát hiện sai sót pháp lý nhanh hơn 5 lần.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 lg:gap-4">
                <button className="p-3 lg:p-4 bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl text-left hover:bg-white/10 transition-all">
                  <h4 className="font-bold text-xs lg:text-sm mb-1">Rà soát hàng loạt</h4>
                  <p className="text-[10px] lg:text-xs text-zinc-500">Phân tích 50 hồ sơ cùng lúc</p>
                </button>
                <button className="p-3 lg:p-4 bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl text-left hover:bg-white/10 transition-all">
                  <h4 className="font-bold text-xs lg:text-sm mb-1">Phát hiện gian lận</h4>
                  <p className="text-[10px] lg:text-xs text-zinc-500">Kiểm tra trùng lặp CCCD</p>
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* Sidebar Section */}
        <div className="space-y-6 lg:space-y-8">
          <section className="bg-white rounded-[24px] lg:rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden">
            <div className="p-5 lg:p-6 border-b border-zinc-100">
              <h2 className="text-base lg:text-lg font-bold text-zinc-900">Yêu cầu tư vấn mới</h2>
            </div>
            <div className="p-5 lg:p-6 space-y-5 lg:space-y-6">
              {[
                { user: 'Lê Minh H.', msg: 'Tôi cần hướng dẫn điền mẫu 01...', time: '5p trước' },
                { user: 'Phạm Văn T.', msg: 'Hồ sơ của tôi bị thiếu giấy...', time: '12p trước' },
                { user: 'Hoàng Thị K.', msg: 'Ngân hàng yêu cầu bổ sung...', time: '20p trước' },
              ].map((chat, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-8 h-8 lg:w-10 lg:h-10 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-400 shrink-0">
                    <Users size={16} />
                  </div>
                  <div className="flex-grow">
                    <div className="flex justify-between items-center mb-1">
                      <h4 className="font-bold text-xs lg:text-sm text-zinc-900">{chat.user}</h4>
                      <span className="text-[8px] lg:text-[10px] text-zinc-400">{chat.time}</span>
                    </div>
                    <p className="text-[10px] lg:text-xs text-zinc-500 line-clamp-1">{chat.msg}</p>
                    <button className="mt-2 text-[8px] lg:text-[10px] font-bold text-emerald-600 uppercase tracking-widest hover:underline">Trả lời ngay</button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-amber-50 border border-amber-100 rounded-[24px] lg:rounded-[32px] p-5 lg:p-6">
            <div className="flex items-center gap-3 mb-3 lg:mb-4 text-amber-600">
              <AlertCircle size={20} />
              <h3 className="font-bold text-sm lg:text-base">Cảnh báo quan trọng</h3>
            </div>
            <p className="text-xs lg:text-sm text-amber-800 leading-relaxed mb-4">
              Phát hiện 12 hồ sơ có dấu hiệu chỉnh sửa file PDF tại dự án <strong>Evergreen Bắc Giang</strong>.
            </p>
            <button className="w-full py-3 bg-amber-600 text-white rounded-xl lg:rounded-2xl text-xs lg:text-sm font-bold hover:bg-amber-700 transition-colors shadow-lg shadow-amber-200">
              Kiểm tra ngay
            </button>
          </section>

          <section className="bg-white rounded-[24px] lg:rounded-[32px] border border-zinc-200 shadow-sm p-5 lg:p-6">
            <h3 className="font-bold text-zinc-900 mb-4 text-sm lg:text-base">Hiệu suất làm việc</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-[10px] lg:text-xs mb-2">
                  <span className="text-zinc-500">Hồ sơ đã duyệt</span>
                  <span className="font-bold text-zinc-900">38/42</span>
                </div>
                <div className="h-1.5 lg:h-2 bg-zinc-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 w-[90%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[10px] lg:text-xs mb-2">
                  <span className="text-zinc-500">Thời gian phản hồi</span>
                  <span className="font-bold text-zinc-900">12 phút</span>
                </div>
                <div className="h-1.5 lg:h-2 bg-zinc-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 w-[75%]" />
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

const User = ({ size, className }: { size: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);
