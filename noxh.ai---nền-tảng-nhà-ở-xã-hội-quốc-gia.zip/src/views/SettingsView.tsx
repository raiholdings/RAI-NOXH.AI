import React, { useState } from 'react';
import { 
  User, 
  Bell, 
  Lock, 
  ShieldCheck, 
  Eye, 
  EyeOff,
  ChevronRight,
  LogOut,
  Smartphone,
  Globe,
  Mail
} from 'lucide-react';
import { motion } from 'motion/react';

export const SettingsView = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    ai: true
  });

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 lg:pb-0">
      <header>
        <h1 className="text-3xl font-bold text-zinc-900">Cài đặt</h1>
        <p className="text-zinc-500 mt-1">Quản lý thông tin cá nhân và thiết lập ứng dụng.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1 space-y-2">
          {[
            { id: 'profile', label: 'Thông tin cá nhân', icon: User },
            { id: 'notifications', label: 'Thông báo', icon: Bell },
            { id: 'security', label: 'Bảo mật', icon: Lock },
            { id: 'privacy', label: 'Quyền riêng tư', icon: ShieldCheck },
          ].map((item) => (
            <button
              key={item.id}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                item.id === 'profile' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'text-zinc-500 hover:bg-zinc-100'
              }`}
            >
              <item.icon size={18} /> {item.label}
            </button>
          ))}
        </div>

        {/* Main Settings Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* Profile Section */}
          <section className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-zinc-100 bg-zinc-50/50">
              <h3 className="font-bold text-zinc-900">Thông tin cá nhân</h3>
            </div>
            <div className="p-6 space-y-6">
              <div className="flex items-center gap-6">
                <div className="relative group">
                  <div className="w-20 h-20 rounded-full bg-zinc-100 border-2 border-zinc-200 flex items-center justify-center overflow-hidden">
                    <User size={40} className="text-zinc-400" />
                  </div>
                  <button className="absolute bottom-0 right-0 p-1.5 bg-emerald-600 text-white rounded-full border-2 border-white shadow-lg">
                    <Smartphone size={12} />
                  </button>
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900">Nguyễn Văn A</h4>
                  <p className="text-xs text-zinc-500">ID: NOXH-88291</p>
                  <button className="text-xs font-bold text-emerald-600 mt-1 hover:underline">Thay đổi ảnh đại diện</button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Họ và tên</label>
                  <input type="text" defaultValue="Nguyễn Văn A" className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={14} />
                    <input type="email" defaultValue="customer@noxh.ai" className="w-full pl-9 pr-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Số điện thoại</label>
                  <input type="text" defaultValue="098****123" className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Khu vực quan tâm</label>
                  <select className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500">
                    <option>Hà Nội</option>
                    <option>TP. Hồ Chí Minh</option>
                    <option>Bắc Giang</option>
                    <option>Hải Phòng</option>
                  </select>
                </div>
              </div>
              <button className="px-6 py-2.5 bg-zinc-900 text-white rounded-xl text-sm font-bold hover:bg-zinc-800 transition-all">Lưu thay đổi</button>
            </div>
          </section>

          {/* Notifications Section */}
          <section className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-zinc-100 bg-zinc-50/50">
              <h3 className="font-bold text-zinc-900">Thông báo</h3>
            </div>
            <div className="p-6 space-y-4">
              {[
                { id: 'email', label: 'Thông báo qua Email', desc: 'Nhận cập nhật về trạng thái hồ sơ qua email.', icon: Mail },
                { id: 'push', label: 'Thông báo đẩy', desc: 'Nhận thông báo tức thì trên trình duyệt/điện thoại.', icon: Bell },
                { id: 'ai', label: 'Gợi ý từ AI', desc: 'AI sẽ thông báo khi có dự án mới phù hợp với bạn.', icon: Sparkles },
              ].map((item) => (
                <div key={item.id} className="flex items-center justify-between py-2">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-xl bg-zinc-50 flex items-center justify-center text-zinc-400">
                      <item.icon size={20} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-zinc-900">{item.label}</p>
                      <p className="text-xs text-zinc-500">{item.desc}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setNotifications({...notifications, [item.id]: !notifications[item.id as keyof typeof notifications]})}
                    className={`w-12 h-6 rounded-full transition-all relative ${notifications[item.id as keyof typeof notifications] ? 'bg-emerald-600' : 'bg-zinc-200'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${notifications[item.id as keyof typeof notifications] ? 'right-1' : 'left-1'}`} />
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* Security Section */}
          <section className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-zinc-100 bg-zinc-50/50">
              <h3 className="font-bold text-zinc-900">Bảo mật</h3>
            </div>
            <div className="p-6 space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                  <div className="flex gap-3">
                    <Smartphone className="text-zinc-400" size={20} />
                    <div>
                      <p className="text-sm font-bold text-zinc-900">Xác thực 2 lớp (2FA)</p>
                      <p className="text-xs text-zinc-500">Bảo vệ tài khoản bằng mã OTP qua điện thoại.</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">Đã bật</span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Đổi mật khẩu</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="Mật khẩu hiện tại" 
                      className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" 
                    />
                    <button 
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
              </div>
              <button className="text-sm font-bold text-emerald-600 hover:underline">Quản lý các thiết bị đang đăng nhập</button>
            </div>
          </section>

          <div className="pt-4">
            <button className="w-full flex items-center justify-center gap-2 py-4 bg-red-50 text-red-600 rounded-2xl font-bold hover:bg-red-100 transition-all">
              <LogOut size={20} /> Đăng xuất khỏi tất cả thiết bị
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Sparkles = ({ size, className }: { size: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
    <path d="M5 3v4" />
    <path d="M19 17v4" />
    <path d="M3 5h4" />
    <path d="M17 19h4" />
  </svg>
);
