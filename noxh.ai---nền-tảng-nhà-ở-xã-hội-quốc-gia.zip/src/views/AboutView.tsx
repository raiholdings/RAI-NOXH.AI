import React from 'react';
import { motion } from 'motion/react';
import { 
  Target, 
  Eye, 
  ShieldCheck, 
  Zap, 
  Heart, 
  Users, 
  Award,
  ArrowRight,
  CheckCircle2,
  Globe,
  Scale,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const AboutView = () => {
  return (
    <div className="bg-white">
      {/* Hero Section - Editorial Style */}
      <section className="relative pt-12 lg:pt-20 pb-20 lg:pb-32 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-zinc-50 -z-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-flex items-center px-4 py-1.5 rounded-full text-[10px] lg:text-xs font-bold tracking-widest uppercase bg-emerald-100 text-emerald-700 mb-6 lg:mb-8">
                Câu chuyện của chúng tôi
              </span>
              <h1 className="text-3xl lg:text-6xl font-extrabold text-zinc-900 tracking-tight leading-tight mb-6 lg:mb-8">
                Số hoá niềm tin, <br />
                <span className="text-emerald-600">Xây dựng tổ ấm</span>
              </h1>
              <p className="text-base lg:text-xl text-zinc-500 leading-relaxed">
                noxh.ai ra đời với sứ mệnh xóa bỏ rào cản thông tin, mang lại sự công bằng và minh bạch tuyệt đối trong hành trình sở hữu Nhà ở Xã hội của người dân Việt Nam.
              </p>
            </motion.div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-1/2 left-0 -translate-y-1/2 w-32 h-32 lg:w-64 lg:h-64 bg-emerald-200/20 rounded-full blur-3xl" />
        <div className="absolute top-1/2 right-0 -translate-y-1/2 w-32 h-32 lg:w-64 lg:h-64 bg-blue-200/20 rounded-full blur-3xl" />
      </section>

      {/* Mission & Vision - Split Layout */}
      <section className="py-16 lg:py-24 border-y border-zinc-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="relative">
              <div className="aspect-video lg:aspect-square rounded-[24px] lg:rounded-[40px] overflow-hidden shadow-2xl">
                <img 
                  src="https://picsum.photos/seed/noxh-mission/800/800" 
                  alt="Mission" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-white p-6 lg:p-8 rounded-2xl lg:rounded-3xl shadow-xl border border-zinc-100 max-w-[200px] lg:max-w-xs hidden sm:block">
                <div className="flex items-center gap-3 lg:gap-4 mb-3 lg:mb-4">
                  <div className="w-10 h-10 lg:w-12 lg:h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
                    <Target size={20} />
                  </div>
                  <h4 className="font-bold text-zinc-900 text-sm lg:text-base">Mục tiêu 2030</h4>
                </div>
                <p className="text-xs lg:text-sm text-zinc-500 leading-relaxed">
                  Hỗ trợ 1 triệu hộ gia đình sở hữu nhà ở xã hội thông qua nền tảng số hoá.
                </p>
              </div>
            </div>
            
            <div className="space-y-10 lg:space-y-12">
              <div>
                <div className="flex items-center gap-3 text-emerald-600 font-bold uppercase tracking-widest text-[10px] lg:text-xs mb-4">
                  <Target size={14} /> Sứ mệnh
                </div>
                <h2 className="text-2xl lg:text-3xl font-bold text-zinc-900 mb-4 lg:mb-6 tracking-tight">Công bằng cho mọi người</h2>
                <p className="text-sm lg:text-lg text-zinc-500 leading-relaxed">
                  Chúng tôi tin rằng mọi người dân đều xứng đáng có một mái ấm ổn định. Sứ mệnh của noxh.ai là sử dụng công nghệ để loại bỏ tiêu cực, đảm bảo đúng người, đúng đối tượng được tiếp cận chính sách nhà ở của Nhà nước.
                </p>
              </div>
              
              <div className="h-px bg-zinc-100" />
              
              <div>
                <div className="flex items-center gap-3 text-blue-600 font-bold uppercase tracking-widest text-[10px] lg:text-xs mb-4">
                  <Eye size={14} /> Tầm nhìn
                </div>
                <h2 className="text-2xl lg:text-3xl font-bold text-zinc-900 mb-4 lg:mb-6 tracking-tight">Hệ sinh thái BĐS số</h2>
                <p className="text-sm lg:text-lg text-zinc-500 leading-relaxed">
                  Trở thành nền tảng hạ tầng số quốc gia hàng đầu, kết nối thông suốt giữa Chính phủ, Chủ đầu tư và Người dân trong lĩnh vực nhà ở xã hội và bất động sản đại chúng.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values - Grid Layout */}
      <section className="py-20 lg:py-32 bg-zinc-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-3xl lg:text-4xl font-bold text-zinc-900 mb-4 tracking-tight">Giá trị cốt lõi</h2>
            <p className="text-zinc-500 text-base lg:text-lg max-w-2xl mx-auto">
              Những nguyên tắc định hướng cho mọi hoạt động và phát triển của chúng tôi.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {[
              {
                title: 'Minh bạch tuyệt đối',
                desc: 'Mọi quy trình, từ nộp hồ sơ đến xét duyệt, đều được công khai và có thể truy xuất nguồn gốc.',
                icon: ShieldCheck,
                color: 'bg-emerald-100 text-emerald-600'
              },
              {
                title: 'Công nghệ dẫn dắt',
                desc: 'Ứng dụng AI và Big Data để tối ưu hóa quy trình, giảm thiểu sai sót và tiết kiệm thời gian.',
                icon: Zap,
                color: 'bg-blue-100 text-blue-600'
              },
              {
                title: 'Tận tâm vì cộng đồng',
                desc: 'Đặt lợi ích của người dân lên hàng đầu trong mọi quyết định và tính năng của sản phẩm.',
                icon: Heart,
                color: 'bg-rose-100 text-rose-600'
              }
            ].map((value, i) => (
              <div key={i} className="bg-white p-8 lg:p-10 rounded-[32px] lg:rounded-[40px] border border-zinc-200 shadow-sm hover:shadow-xl transition-all">
                <div className={`w-12 h-12 lg:w-16 lg:h-16 ${value.color} rounded-xl lg:rounded-2xl flex items-center justify-center mb-6 lg:mb-8`}>
                  <value.icon size={28} />
                </div>
                <h3 className="text-xl lg:text-2xl font-bold text-zinc-900 mb-4">{value.title}</h3>
                <p className="text-sm lg:text-base text-zinc-500 leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Technology? - AI Showcase */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-zinc-900 rounded-[40px] lg:rounded-[60px] p-8 lg:p-24 relative overflow-hidden text-white">
            <div className="lg:grid lg:grid-cols-2 lg:gap-20 items-center">
              <div>
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] lg:text-xs font-bold tracking-widest uppercase mb-6 lg:mb-8 border border-emerald-500/20">
                  <Sparkles size={14} /> Sức mạnh của AI
                </span>
                <h2 className="text-3xl lg:text-4xl font-bold mb-8 leading-tight">Tại sao chúng tôi tin vào công nghệ?</h2>
                <div className="space-y-6 lg:space-y-8">
                  <div className="flex gap-4 lg:gap-6">
                    <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-emerald-400 shrink-0">
                      <Scale size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm lg:text-base mb-1 lg:mb-2">Đảm bảo tính công bằng</h4>
                      <p className="text-zinc-400 text-xs lg:text-sm leading-relaxed">Thuật toán AI giúp chấm điểm hồ sơ khách quan dựa trên các tiêu chí cứng của pháp luật.</p>
                    </div>
                  </div>
                  <div className="flex gap-4 lg:gap-6">
                    <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-400 shrink-0">
                      <Globe size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm lg:text-base mb-1 lg:mb-2">Kết nối không giới hạn</h4>
                      <p className="text-zinc-400 text-xs lg:text-sm leading-relaxed">Phá bỏ rào cản địa lý, cho phép người dân ở bất cứ đâu cũng có thể tiếp cận và nộp hồ sơ.</p>
                    </div>
                  </div>
                  <div className="flex gap-4 lg:gap-6">
                    <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-purple-400 shrink-0">
                      <CheckCircle2 size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm lg:text-base mb-1 lg:mb-2">Xác thực tức thì</h4>
                      <p className="text-zinc-400 text-xs lg:text-sm leading-relaxed">Tích hợp với cơ sở dữ liệu quốc gia giúp xác thực thông tin nhân thân chỉ trong vài giây.</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-12 lg:mt-0 relative">
                <div className="aspect-[4/3] lg:aspect-[4/5] rounded-[32px] lg:rounded-[40px] overflow-hidden border-4 lg:border-8 border-white/10">
                  <img 
                    src="https://picsum.photos/seed/noxh-tech/800/1000" 
                    alt="Technology" 
                    className="w-full h-full object-cover opacity-80"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 lg:-bottom-10 lg:-left-10 bg-emerald-600 p-6 lg:p-8 rounded-2xl lg:rounded-3xl shadow-2xl max-w-[200px] lg:max-w-xs">
                  <p className="text-3xl lg:text-4xl font-bold mb-1 lg:mb-2">92%</p>
                  <p className="text-emerald-100 text-[10px] lg:text-sm font-medium">Tỷ lệ hồ sơ được xử lý chính xác ngay từ lần đầu tiên nhờ AI.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team/Partners Section */}
      <section className="py-20 lg:py-32 bg-zinc-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-3xl lg:text-4xl font-bold text-zinc-900 mb-4 tracking-tight">Đồng hành cùng chúng tôi</h2>
            <p className="text-zinc-500 text-sm lg:text-lg max-w-2xl mx-auto">
              noxh.ai tự hào nhận được sự tin tưởng và đồng hành từ các cơ quan quản lý và các tập đoàn hàng đầu.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8 items-center opacity-50 grayscale hover:grayscale-0 transition-all">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="flex justify-center">
                <div className="h-10 lg:h-12 w-24 lg:w-32 bg-zinc-300 rounded-lg animate-pulse" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-emerald-600 rounded-[32px] lg:rounded-[40px] p-8 lg:p-20 text-center relative overflow-hidden shadow-2xl shadow-emerald-200">
            <div className="relative z-10">
              <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6 lg:mb-8 tracking-tight">Cùng nhau kiến tạo tương lai</h2>
              <p className="text-emerald-100 text-base lg:text-xl max-w-2xl mx-auto mb-8 lg:mb-12 leading-relaxed">
                Dù bạn là người dân đang tìm kiếm tổ ấm, hay chủ đầu tư muốn số hoá quy trình, chúng tôi luôn sẵn sàng hỗ trợ.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4 lg:gap-6">
                <Link to="/register" className="px-8 lg:px-10 py-4 lg:py-5 bg-white text-emerald-600 rounded-xl lg:rounded-2xl font-bold text-base lg:text-lg hover:bg-emerald-50 transition-all">
                  Bắt đầu ngay
                </Link>
                <Link to="/marketplace" className="px-8 lg:px-10 py-4 lg:py-5 border border-white/30 text-white rounded-xl lg:rounded-2xl font-bold text-base lg:text-lg hover:bg-white/10 transition-all">
                  Khám phá dịch vụ
                </Link>
              </div>
            </div>
            
            {/* Abstract shapes */}
            <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 lg:w-96 lg:h-96 bg-white/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-64 h-64 lg:w-96 lg:h-96 bg-black/10 rounded-full blur-3xl" />
          </div>
        </div>
      </section>
    </div>
  );
};
