import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Clock, 
  CheckCircle2, 
  BarChart3, 
  PlusCircle, 
  Search,
  ChevronRight,
  Filter,
  Download,
  Users,
  AlertCircle,
  TrendingUp,
  MapPin,
  FileText,
  MessageSquare,
  MoreVertical,
  ArrowUpRight,
  ArrowDownRight,
  X,
  Check,
  Eye,
  ShieldCheck,
  Settings,
  Layers,
  Activity,
  Calendar
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

// Mock Data
const ANALYTICS_DATA = [
  { name: 'Tháng 1', value: 400, applications: 240 },
  { name: 'Tháng 2', value: 300, applications: 139 },
  { name: 'Tháng 3', value: 200, applications: 980 },
  { name: 'Tháng 4', value: 278, applications: 390 },
  { name: 'Tháng 5', value: 189, applications: 480 },
  { name: 'Tháng 6', value: 239, applications: 380 },
];

const PIE_DATA = [
  { name: 'Công nhân', value: 400 },
  { name: 'Thu nhập thấp', value: 300 },
  { name: 'Viên chức', value: 300 },
  { name: 'Khác', value: 200 },
];

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

const MOCK_DEVELOPER_PROJECTS = [
  { 
    id: 'P1', 
    name: 'Evergreen Bắc Giang', 
    location: 'Bắc Giang', 
    units: 1200, 
    sold: 850, 
    status: 'OPEN', 
    progress: 70,
    phases: [
      { name: 'Giai đoạn 1', status: 'COMPLETED', units: 400 },
      { name: 'Giai đoạn 2', status: 'IN_PROGRESS', units: 400 },
      { name: 'Giai đoạn 3', status: 'UPCOMING', units: 400 }
    ]
  },
  { id: 'P2', name: 'Rice City Tố Hữu', location: 'Hà Nội', units: 500, sold: 480, status: 'OPEN', progress: 96 },
  { id: 'P3', name: 'Evergreen Tràng Duệ', location: 'Hải Phòng', units: 2000, sold: 0, status: 'UPCOMING', progress: 0 },
];

const MOCK_APPLICATIONS = [
  { id: 'APP-001', name: 'Trần Thị B', project: 'Evergreen Bắc Giang', score: 92, type: 'Công nhân', status: 'PENDING', date: '2024-03-01' },
  { id: 'APP-002', name: 'Lê Văn C', project: 'Evergreen Bắc Giang', score: 78, type: 'Thu nhập thấp', status: 'NEED_INFO', date: '2024-03-02' },
  { id: 'APP-003', name: 'Phạm Minh D', project: 'Rice City Tố Hữu', score: 85, type: 'Viên chức', status: 'PENDING', date: '2024-03-03' },
  { id: 'APP-004', name: 'Hoàng Văn E', project: 'Evergreen Bắc Giang', score: 45, type: 'Tự do', status: 'REJECTED', date: '2024-03-04' },
  { id: 'APP-005', name: 'Nguyễn Thị F', project: 'Rice City Tố Hữu', score: 95, type: 'Công nhân', status: 'APPROVED', date: '2024-03-05' },
];

const ApplicationReviewModal = ({ app, onClose }: { app: any, onClose: () => void }) => {
  if (!app) return null;
  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
        <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="relative w-full max-w-4xl bg-white rounded-[32px] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
          <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center">
                <Users size={20} />
              </div>
              <div>
                <h3 className="font-bold text-zinc-900">Thẩm định hồ sơ</h3>
                <p className="text-xs text-zinc-500">Mã: {app.id} • {app.name}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
              <X size={20} className="text-zinc-400" />
            </button>
          </div>

          <div className="flex-grow overflow-y-auto p-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <section>
                  <h4 className="text-sm font-bold text-zinc-900 mb-4 flex items-center gap-2">
                    <FileText size={16} className="text-emerald-600" /> Thông tin nhân thân (VNeID)
                  </h4>
                  <div className="grid grid-cols-2 gap-4 p-6 bg-zinc-50 rounded-2xl border border-zinc-100">
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Họ và tên</p>
                      <p className="text-sm font-bold text-zinc-900">{app.name.toUpperCase()}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Số định danh</p>
                      <p className="text-sm font-bold text-zinc-900">00109200****</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Đối tượng</p>
                      <p className="text-sm font-bold text-zinc-900">{app.type}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Xác thực</p>
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">VNeID Level 2</span>
                    </div>
                  </div>
                </section>

                <section>
                  <h4 className="text-sm font-bold text-zinc-900 mb-4 flex items-center gap-2">
                    <ShieldCheck size={16} className="text-emerald-600" /> Tài liệu đính kèm
                  </h4>
                  <div className="space-y-3">
                    {['CCCD_MatTruoc.jpg', 'XacNhanCuTru.pdf', 'GiayXacNhanThuNhap.pdf'].map((doc, i) => (
                      <div key={i} className="flex items-center justify-between p-4 bg-white border border-zinc-200 rounded-xl hover:border-emerald-200 transition-colors cursor-pointer group">
                        <div className="flex items-center gap-3">
                          <FileText size={18} className="text-zinc-400 group-hover:text-emerald-600" />
                          <span className="text-sm font-medium text-zinc-700">{doc}</span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Hợp lệ</span>
                          <Eye size={16} className="text-zinc-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>

              <div className="space-y-6">
                <div className="bg-zinc-900 rounded-3xl p-6 text-white relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
                  <div className="relative z-10">
                    <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-4">Phân tích AI</p>
                    <div className="flex items-end gap-2 mb-4">
                      <span className="text-5xl font-black text-white">{app.score}</span>
                      <span className="text-xl text-zinc-500 font-bold mb-1">/100</span>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-xs text-emerald-400">
                        <CheckCircle2 size={14} /> Pháp lý hoàn thiện
                      </div>
                      <div className="flex items-center gap-2 text-xs text-emerald-400">
                        <CheckCircle2 size={14} /> Đúng đối tượng ưu tiên
                      </div>
                      <div className="flex items-center gap-2 text-xs text-amber-400">
                        <AlertCircle size={14} /> Thu nhập cận biên
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-zinc-50 rounded-3xl border border-zinc-200">
                  <h5 className="font-bold text-zinc-900 mb-4 text-sm">Ghi chú nội bộ</h5>
                  <textarea className="w-full h-24 bg-white border border-zinc-200 rounded-xl p-3 text-xs outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Nhập ghi chú thẩm định..." />
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-between items-center">
            <button className="flex items-center gap-2 text-zinc-500 font-bold hover:text-zinc-900 transition-colors">
              <MessageSquare size={18} /> Phản hồi khách hàng
            </button>
            <div className="flex gap-3">
              <button className="px-6 py-2.5 bg-white border border-zinc-200 text-red-600 rounded-xl text-sm font-bold hover:bg-red-50 transition-all">
                Từ chối
              </button>
              <button className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 transition-all flex items-center gap-2">
                <Check size={18} /> Phê duyệt hồ sơ
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export const DeveloperView = () => {
  const [activeTab, setActiveTab] = useState('OVERVIEW');
  const [selectedApp, setSelectedApp] = useState<any>(null);
  const [isAddingProject, setIsAddingProject] = useState(false);

  const tabs = [
    { id: 'OVERVIEW', label: 'Tổng quan', icon: BarChart3 },
    { id: 'PROJECTS', label: 'Dự án của tôi', icon: Building2 },
    { id: 'APPLICATIONS', label: 'Hồ sơ khách hàng', icon: Users },
    { id: 'MESSAGES', label: 'Tin nhắn', icon: MessageSquare },
    { id: 'ANALYTICS', label: 'Báo cáo & Phân tích', icon: TrendingUp },
    { id: 'SETTINGS', label: 'Cài đặt', icon: Settings },
  ];

  return (
    <div className="space-y-8 pb-20 lg:pb-0">
      <ApplicationReviewModal app={selectedApp} onClose={() => setSelectedApp(null)} />
      
      {/* Add Project Modal */}
      <AnimatePresence>
        {isAddingProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsAddingProject(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center">
                    <PlusCircle size={20} />
                  </div>
                  <h3 className="font-bold text-zinc-900">Đăng dự án NOXH mới</h3>
                </div>
                <button onClick={() => setIsAddingProject(false)} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                  <X size={20} className="text-zinc-400" />
                </button>
              </div>
              <div className="p-8 overflow-y-auto space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tên dự án</label>
                    <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: Evergreen City" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Vị trí</label>
                    <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: Hà Nội" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tổng số căn</label>
                    <input type="number" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: 500" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Giá dự kiến (tr/m2)</label>
                    <input type="number" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: 15" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Mô tả dự án</label>
                  <textarea className="w-full h-32 bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Nhập thông tin chi tiết về dự án..." />
                </div>
                <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-start gap-3">
                  <AlertCircle className="text-emerald-600 mt-0.5" size={18} />
                  <p className="text-xs text-emerald-700 leading-relaxed">
                    Dự án sau khi đăng sẽ được AI kiểm duyệt pháp lý sơ bộ trước khi hiển thị công khai trên sàn NOXH.ai.
                  </p>
                </div>
              </div>
              <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-end gap-3">
                <button onClick={() => setIsAddingProject(false)} className="px-6 py-2.5 bg-white border border-zinc-200 text-zinc-600 rounded-xl text-sm font-bold hover:bg-zinc-50 transition-all">
                  Hủy bỏ
                </button>
                <button className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 transition-all">
                  Xác nhận đăng dự án
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">Quản trị Chủ đầu tư</h1>
          <p className="text-zinc-500 mt-1">Evergreen Group • 12 dự án đang vận hành</p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-3 bg-white border border-zinc-200 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-50 transition-all flex items-center gap-2 shadow-sm">
            <Download size={18} /> Xuất báo cáo
          </button>
          <button 
            onClick={() => setIsAddingProject(true)}
            className="px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100"
          >
            <PlusCircle size={18} /> Đăng dự án mới
          </button>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="flex gap-1 bg-zinc-100 p-1 rounded-2xl w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
              activeTab === tab.id 
                ? 'bg-white text-zinc-900 shadow-sm' 
                : 'text-zinc-500 hover:text-zinc-900'
            }`}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { label: 'Tổng hồ sơ', value: '2,840', change: '+12%', trend: 'up', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
              { label: 'Đang chờ duyệt', value: '1,240', change: '-5%', trend: 'down', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
              { label: 'Đã phê duyệt', value: '450', change: '+18%', trend: 'up', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
              { label: 'Tỷ lệ lấp đầy', value: '68%', change: '+2%', trend: 'up', icon: BarChart3, color: 'text-purple-600', bg: 'bg-purple-50' },
            ].map((stat, i) => (
              <div key={i} className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-3 rounded-2xl ${stat.bg} ${stat.color}`}>
                    <stat.icon size={24} />
                  </div>
                  <div className={`flex items-center gap-1 text-[10px] font-bold ${stat.trend === 'up' ? 'text-emerald-600' : 'text-red-600'}`}>
                    {stat.trend === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    {stat.change}
                  </div>
                </div>
                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{stat.label}</p>
                <p className="text-2xl font-black text-zinc-900 mt-1">{stat.value}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-lg font-bold text-zinc-900">Lưu lượng hồ sơ</h3>
                  <p className="text-xs text-zinc-500">Thống kê hồ sơ nộp theo tháng</p>
                </div>
                <select className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                  <option>6 tháng gần nhất</option>
                  <option>1 năm gần nhất</option>
                </select>
              </div>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={ANALYTICS_DATA}>
                    <defs>
                      <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Area type="monotone" dataKey="applications" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorVal)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h3 className="text-lg font-bold text-zinc-900 mb-6">Cơ cấu đối tượng</h3>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={PIE_DATA}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {PIE_DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-3 mt-6">
                {PIE_DATA.map((item, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                      <span className="text-xs text-zinc-500 font-medium">{item.name}</span>
                    </div>
                    <span className="text-xs font-bold text-zinc-900">{Math.round(item.value / 1200 * 100)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'PROJECTS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {MOCK_DEVELOPER_PROJECTS.map((project) => (
            <div key={project.id} className="bg-white rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden group hover:shadow-xl transition-all duration-500">
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                    <Building2 size={24} />
                  </div>
                  <button className="p-2 text-zinc-400 hover:text-zinc-900">
                    <MoreVertical size={20} />
                  </button>
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2">{project.name}</h3>
                <p className="text-xs text-zinc-500 flex items-center gap-2 mb-6">
                  <MapPin size={14} /> {project.location}
                </p>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-xs font-bold mb-2">
                      <span className="text-zinc-500">Tỷ lệ lấp đầy</span>
                      <span className="text-zinc-900">{Math.round(project.sold / project.units * 100)}%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-emerald-600 rounded-full" 
                        style={{ width: `${(project.sold / project.units * 100)}%` }} 
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div>
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Đã bán</p>
                      <p className="text-lg font-bold text-zinc-900">{project.sold}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Tổng căn</p>
                      <p className="text-lg font-bold text-zinc-900">{project.units}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="px-8 py-4 bg-zinc-50 border-t border-zinc-100 flex justify-between items-center">
                <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest ${
                  project.status === 'OPEN' ? 'bg-emerald-100 text-emerald-600' : 'bg-zinc-200 text-zinc-500'
                }`}>
                  {project.status === 'OPEN' ? 'Đang mở bán' : 'Sắp mở bán'}
                </span>
                <button className="text-xs font-bold text-emerald-600 hover:underline">Chi tiết dự án</button>
              </div>
            </div>
          ))}
          <button 
            onClick={() => setIsAddingProject(true)}
            className="border-2 border-dashed border-zinc-200 rounded-[32px] p-8 flex flex-col items-center justify-center gap-4 text-zinc-400 hover:border-emerald-500 hover:text-emerald-600 transition-all group"
          >
            <div className="w-16 h-16 bg-zinc-50 rounded-full flex items-center justify-center group-hover:bg-emerald-50 transition-all">
              <PlusCircle size={32} />
            </div>
            <span className="font-bold">Thêm dự án mới</span>
          </button>
        </div>
      )}

      {activeTab === 'APPLICATIONS' && (
        <section className="bg-white rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden">
          <div className="p-8 border-b border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-6">
            <h2 className="text-xl font-bold text-zinc-900">Danh sách hồ sơ nộp</h2>
            <div className="flex gap-3 w-full md:w-auto">
              <div className="relative flex-grow md:flex-grow-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input type="text" placeholder="Tìm tên, mã hồ sơ..." className="pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none w-full md:w-64" />
              </div>
              <button className="p-2.5 border border-zinc-200 rounded-xl text-zinc-500 hover:bg-zinc-50">
                <Filter size={20} />
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-zinc-50 text-zinc-500 font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-8 py-4">Khách hàng</th>
                  <th className="px-8 py-4">Dự án</th>
                  <th className="px-8 py-4">Điểm AI</th>
                  <th className="px-8 py-4">Đối tượng</th>
                  <th className="px-8 py-4">Trạng thái</th>
                  <th className="px-8 py-4 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {MOCK_APPLICATIONS.map((row) => (
                  <tr key={row.id} className="hover:bg-zinc-50 transition-colors">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-500 font-bold text-xs">
                          {row.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-zinc-900">{row.name}</p>
                          <p className="text-[10px] text-zinc-500">{row.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-zinc-500 font-medium">{row.project}</td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-2">
                        <span className={`font-black text-lg ${
                          row.score >= 90 ? 'text-emerald-600' : 
                          row.score >= 70 ? 'text-amber-600' : 'text-red-600'
                        }`}>{row.score}</span>
                        <span className="text-[10px] text-zinc-400">/100</span>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-zinc-500 font-medium">{row.type}</td>
                    <td className="px-8 py-5">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${
                        row.status === 'PENDING' ? 'bg-blue-50 text-blue-600' : 
                        row.status === 'NEED_INFO' ? 'bg-amber-50 text-amber-600' :
                        row.status === 'APPROVED' ? 'bg-emerald-50 text-emerald-600' :
                        'bg-red-50 text-red-600'
                      }`}>
                        {row.status === 'PENDING' ? 'Chờ duyệt' : 
                         row.status === 'NEED_INFO' ? 'Cần bổ sung' :
                         row.status === 'APPROVED' ? 'Đã duyệt' : 'Từ chối'}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button 
                        onClick={() => setSelectedApp(row)}
                        className="px-4 py-2 bg-zinc-900 text-white rounded-xl text-xs font-bold hover:bg-zinc-800 transition-all"
                      >
                        Thẩm định
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {activeTab === 'MESSAGES' && (
        <div className="bg-white rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden flex h-[600px]">
          <div className="w-1/3 border-r border-zinc-100 flex flex-col">
            <div className="p-6 border-b border-zinc-100">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input type="text" placeholder="Tìm hội thoại..." className="pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-sm w-full outline-none focus:ring-2 focus:ring-emerald-500" />
              </div>
            </div>
            <div className="flex-grow overflow-y-auto">
              {[
                { name: 'Sở Xây dựng Hà Nội', lastMsg: 'Hồ sơ pháp lý dự án Rice City đã được...', time: '10:30', unread: 2, avatar: 'S' },
                { name: 'Nguyễn Văn A (Khách hàng)', lastMsg: 'Tôi muốn hỏi về tiến độ đóng tiền...', time: 'Hôm qua', unread: 0, avatar: 'A' },
                { name: 'Trần Thị B (Khách hàng)', lastMsg: 'Cảm ơn quý công ty đã hỗ trợ...', time: '2 ngày trước', unread: 0, avatar: 'B' },
                { name: 'Đơn vị Tư vấn AI', lastMsg: 'Phân tích rủi ro hồ sơ APP-004...', time: '3 ngày trước', unread: 1, avatar: 'AI' },
              ].map((chat, i) => (
                <div key={i} className={`p-4 flex gap-3 cursor-pointer hover:bg-zinc-50 transition-colors ${i === 0 ? 'bg-emerald-50/50 border-r-2 border-emerald-500' : ''}`}>
                  <div className="w-12 h-12 bg-zinc-200 rounded-full flex items-center justify-center font-bold text-zinc-500 text-sm">
                    {chat.avatar}
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-bold text-zinc-900 text-sm truncate">{chat.name}</h4>
                      <span className="text-[10px] text-zinc-400">{chat.time}</span>
                    </div>
                    <p className="text-xs text-zinc-500 truncate">{chat.lastMsg}</p>
                  </div>
                  {chat.unread > 0 && (
                    <div className="w-5 h-5 bg-emerald-600 text-white rounded-full flex items-center justify-center text-[10px] font-bold">
                      {chat.unread}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="flex-grow flex flex-col bg-zinc-50/30">
            <div className="p-6 border-b border-zinc-100 bg-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center font-bold text-zinc-500 text-xs">
                  S
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 text-sm">Sở Xây dựng Hà Nội</h4>
                  <p className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" /> Trực tuyến
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 text-zinc-400 hover:text-zinc-900"><Download size={20} /></button>
                <button className="p-2 text-zinc-400 hover:text-zinc-900"><MoreVertical size={20} /></button>
              </div>
            </div>
            <div className="flex-grow p-6 overflow-y-auto space-y-4">
              <div className="flex justify-center">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest bg-white px-3 py-1 rounded-full border border-zinc-100">Hôm nay</span>
              </div>
              <div className="flex gap-3 max-w-[80%]">
                <div className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center font-bold text-zinc-500 text-[10px] flex-shrink-0">S</div>
                <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-zinc-100 shadow-sm">
                  <p className="text-sm text-zinc-700 leading-relaxed">
                    Chào Evergreen Group, chúng tôi đã nhận được hồ sơ pháp lý bổ sung cho dự án Rice City Tố Hữu. Các chuyên viên đang tiến hành thẩm định cuối cùng.
                  </p>
                  <span className="text-[10px] text-zinc-400 mt-2 block">10:25</span>
                </div>
              </div>
              <div className="flex gap-3 max-w-[80%] ml-auto flex-row-reverse">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center font-bold text-white text-[10px] flex-shrink-0">EG</div>
                <div className="bg-emerald-600 p-4 rounded-2xl rounded-tr-none text-white shadow-md shadow-emerald-100">
                  <p className="text-sm leading-relaxed">
                    Vâng, cảm ơn Quý Sở. Nếu có bất kỳ thông tin nào cần làm rõ thêm, xin vui lòng phản hồi sớm để chúng tôi kịp thời xử lý.
                  </p>
                  <span className="text-[10px] text-emerald-200 mt-2 block text-right">10:30</span>
                </div>
              </div>
            </div>
            <div className="p-6 bg-white border-t border-zinc-100">
              <div className="flex gap-3">
                <button className="p-2 text-zinc-400 hover:text-emerald-600 transition-colors">
                  <PlusCircle size={24} />
                </button>
                <input type="text" placeholder="Nhập tin nhắn..." className="flex-grow bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                <button className="px-6 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all">
                  Gửi
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'ANALYTICS' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h3 className="text-lg font-bold text-zinc-900 mb-8">Doanh thu dự kiến</h3>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ANALYTICS_DATA}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <Tooltip cursor={{fill: '#f4f4f5'}} contentStyle={{ borderRadius: '16px', border: 'none' }} />
                    <Bar dataKey="value" fill="#10b981" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h3 className="text-lg font-bold text-zinc-900 mb-8">Tỷ lệ chuyển đổi hồ sơ</h3>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={ANALYTICS_DATA}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <Tooltip contentStyle={{ borderRadius: '16px', border: 'none' }} />
                    <Line type="monotone" dataKey="applications" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4, fill: '#3b82f6' }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="max-w-4xl space-y-8">
          <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
            <h3 className="text-xl font-bold text-zinc-900 mb-8">Thông tin Chủ đầu tư</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tên doanh nghiệp</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="Evergreen Group" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Người đại diện</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="Nguyễn Văn Phát" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Email liên hệ</label>
                  <input type="email" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="contact@evergreen.vn" />
                </div>
              </div>
              <div className="space-y-6">
                <div className="p-6 bg-blue-50 border border-blue-100 rounded-2xl">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center">
                      <ShieldCheck size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-blue-900 text-sm">Chứng nhận CĐT Uy tín</h4>
                      <p className="text-[10px] text-blue-600 font-bold uppercase tracking-widest">Hạng Kim Cương</p>
                    </div>
                  </div>
                  <p className="text-xs text-blue-700 leading-relaxed">
                    Evergreen Group đã vượt qua các vòng thẩm định khắt khe về năng lực tài chính và pháp lý dự án.
                  </p>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Thông báo hệ thống</label>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500" />
                      <span className="text-sm text-zinc-600">Email khi có hồ sơ mới</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4 rounded border-zinc-300 text-emerald-600 focus:ring-emerald-500" />
                      <span className="text-sm text-zinc-600">Thông báo đẩy trên trình duyệt</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t border-zinc-100 flex justify-end">
              <button className="px-8 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all">
                Lưu cấu hình
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

