import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Building2, 
  MapPin, 
  ArrowRight, 
  Sparkles, 
  Filter, 
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  Send,
  Info,
  CheckCircle2,
  Clock,
  Home,
  Bell,
  Heart
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_PROJECTS } from '../constants';
import { Link } from 'react-router-dom';

import { 
  collection, 
  query, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { db, auth } from '../firebase';

const AIProjectAssistant = () => {
  const [query, setQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    setIsTyping(true);
    setResponse(null);
    
    // Mock AI response
    setTimeout(() => {
      setIsTyping(false);
      setResponse(`Dựa trên yêu cầu của bạn, tôi tìm thấy 3 dự án phù hợp nhất tại khu vực Hà Nội với mức giá dưới 2 tỷ VNĐ. Nổi bật nhất là dự án **Evergreen Bắc Giang** với chính sách hỗ trợ vay 70% lãi suất ưu đãi.`);
    }, 1500);
  };

  return (
    <div className="bg-zinc-900 rounded-[32px] lg:rounded-[40px] p-6 lg:p-12 relative overflow-hidden text-white mb-12 lg:mb-16">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-emerald-500/10 to-transparent pointer-events-none" />
      
      <div className="relative z-10 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold tracking-widest uppercase mb-4 lg:mb-6 border border-emerald-500/20">
          <Sparkles size={12} /> AI Project Finder
        </div>
        <h2 className="text-2xl lg:text-4xl font-bold mb-4 lg:mb-6 tracking-tight">Tìm dự án phù hợp với <br /><span className="text-emerald-400">Điều kiện của bạn</span></h2>
        <p className="text-zinc-400 mb-8 lg:mb-10 text-sm lg:text-lg">Mô tả nhu cầu của bạn (khu vực, ngân sách, số phòng ngủ...), AI sẽ lọc ra những dự án bạn đủ điều kiện nộp hồ sơ.</p>
        
        <form onSubmit={handleSearch} className="relative mb-6 lg:mb-8">
          <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ví dụ: Hà Nội, giá dưới 1.5 tỷ..." 
            className="w-full bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl py-4 lg:py-5 px-5 lg:px-6 pr-14 lg:pr-16 text-white placeholder:text-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-all text-sm lg:text-lg"
          />
          <button 
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 lg:w-12 lg:h-12 bg-emerald-600 text-white rounded-lg lg:rounded-xl flex items-center justify-center hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-900/20"
          >
            <Send size={18} />
          </button>
        </form>

        <AnimatePresence>
          {(isTyping || response) && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="bg-white/5 border border-white/10 rounded-xl lg:rounded-2xl p-4 lg:p-6 backdrop-blur-md"
            >
              {isTyping ? (
                <div className="flex items-center gap-3 text-zinc-400">
                  <div className="flex gap-1">
                    <div className="w-1 h-1 lg:w-1.5 lg:h-1.5 bg-emerald-500 rounded-full animate-bounce" />
                    <div className="w-1 h-1 lg:w-1.5 lg:h-1.5 bg-emerald-500 rounded-full animate-bounce delay-100" />
                    <div className="w-1 h-1 lg:w-1.5 lg:h-1.5 bg-emerald-500 rounded-full animate-bounce delay-200" />
                  </div>
                  <span className="text-xs lg:text-sm font-medium">AI đang phân tích dữ liệu dự án...</span>
                </div>
              ) : (
                <div className="flex gap-3 lg:gap-4">
                  <div className="w-6 h-6 lg:w-8 lg:h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white font-bold text-[8px] lg:text-[10px] shrink-0">N</div>
                  <div>
                    <p className="text-zinc-200 leading-relaxed text-xs lg:text-sm">
                      {response}
                    </p>
                    <div className="mt-4 flex gap-3">
                      <button className="text-[8px] lg:text-[10px] font-bold uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors">Xem các dự án này</button>
                      <button className="text-[8px] lg:text-[10px] font-bold uppercase tracking-widest text-zinc-500 hover:text-zinc-400 transition-colors">Hỏi thêm</button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

interface ProjectCardProps {
  project: any;
  favorites: string[];
  toggleFavorite: (e: React.MouseEvent, id: string) => Promise<void> | void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ 
  project, 
  favorites, 
  toggleFavorite 
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const images = project.images || [project.image];

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group bg-white rounded-[24px] lg:rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden hover:shadow-2xl hover:shadow-emerald-50 transition-all duration-500 flex flex-col h-full"
    >
      <div className="h-56 lg:h-64 overflow-hidden relative shrink-0">
        <AnimatePresence mode="wait">
          <motion.img 
            key={currentImageIndex}
            src={images[currentImageIndex]} 
            alt={`${project.name} - ${currentImageIndex + 1}`} 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="w-full h-full object-cover" 
            referrerPolicy="no-referrer" 
          />
        </AnimatePresence>

        {images.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white/40 transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronLeft size={20} />
            </button>
            <button 
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white/40 transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronRight size={20} />
            </button>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
              {images.map((_: any, idx: number) => (
                <div 
                  key={idx}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${
                    idx === currentImageIndex ? 'bg-white w-4' : 'bg-white/40'
                  }`}
                />
              ))}
            </div>
          </>
        )}

        <div className="absolute top-4 left-4 flex gap-2">
          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
            project.status === 'OPEN' ? 'bg-emerald-500 text-white' : 'bg-zinc-500 text-white'
          }`}>
            {project.status === 'OPEN' ? 'Đang mở bán' : 'Sắp mở bán'}
          </span>
        </div>
        <button 
          onClick={(e) => toggleFavorite(e, project.id)}
          className={`absolute top-4 right-4 p-2.5 rounded-xl backdrop-blur-md border transition-all duration-300 z-10 ${
            favorites.includes(project.id) 
              ? 'bg-red-500 border-red-400 text-white shadow-lg shadow-red-200' 
              : 'bg-white/80 border-white/20 text-zinc-400 hover:text-red-500 hover:bg-white'
          }`}
        >
          <Heart size={18} fill={favorites.includes(project.id) ? "currentColor" : "none"} />
        </button>
        <div className="absolute bottom-4 left-4 right-4 z-10 pointer-events-none">
          <div className="bg-white/90 backdrop-blur-md p-3 rounded-2xl shadow-lg border border-white/20 w-fit">
            <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Giá từ</p>
            <p className="text-base lg:text-lg font-bold text-emerald-600">{project.priceRange}</p>
          </div>
        </div>
      </div>

      <Link to={`/projects/${project.id}`} className="flex-1 flex flex-col">
        <div className="p-6 lg:p-8 flex-1 flex flex-col">
          <div className="flex justify-between items-start mb-4">
            <h4 className="font-bold text-zinc-900 text-lg lg:text-xl leading-tight line-clamp-2 group-hover:text-emerald-600 transition-colors">{project.name}</h4>
          </div>
          <div className="space-y-3">
            <p className="text-xs lg:text-sm text-zinc-500 flex items-center gap-2">
              <Building2 size={16} className="text-emerald-500" /> {project.developer}
            </p>
            <p className="text-xs lg:text-sm text-zinc-500 flex items-center gap-2">
              <MapPin size={16} className="text-emerald-500" /> {project.location}
            </p>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 lg:gap-4">
            <div className="bg-zinc-50 p-3 rounded-xl lg:rounded-2xl border border-zinc-100">
              <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Quy mô</p>
              <div className="flex items-center gap-2">
                <Home size={14} className="text-zinc-400" />
                <span className="text-xs lg:text-sm font-bold text-zinc-900">{project.units} căn</span>
              </div>
            </div>
            <div className="bg-zinc-50 p-3 rounded-xl lg:rounded-2xl border border-zinc-100">
              <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-widest mb-1">Bàn giao</p>
              <div className="flex items-center gap-2">
                <Clock size={14} className="text-zinc-400" />
                <span className="text-xs lg:text-sm font-bold text-zinc-900">Q4/2025</span>
              </div>
            </div>
          </div>

          <div className="mt-auto pt-6 lg:pt-8 mt-6 lg:mt-8 pt-6 border-t border-zinc-100 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 lg:w-8 lg:h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                <CheckCircle2 size={14} />
              </div>
              <span className="text-[10px] lg:text-xs font-bold text-zinc-600">Đã kiểm duyệt</span>
            </div>
            <div className="flex items-center gap-1 text-emerald-600 font-bold text-xs lg:text-sm group-hover:translate-x-1 transition-transform">
              Chi tiết <ArrowRight size={16} />
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export const ProjectsView = () => {
  const [activeFilter, setActiveFilter] = useState('ALL');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [isLoadingFavs, setIsLoadingFavs] = useState(false);

  useEffect(() => {
    if (!auth.currentUser) return;

    setIsLoadingFavs(true);
    const favsRef = collection(db, 'users', auth.currentUser.uid, 'favorites');
    const q = query(favsRef);

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const favIds = snapshot.docs.map(doc => doc.data().projectId);
      setFavorites(favIds);
      setIsLoadingFavs(false);
    }, (error) => {
      console.error('Error fetching favorites:', error);
      setIsLoadingFavs(false);
    });

    return () => unsubscribe();
  }, []);

  const toggleFavorite = async (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();

    if (!auth.currentUser) {
      alert('Vui lòng đăng nhập để lưu dự án yêu thích.');
      return;
    }

    const userId = auth.currentUser.uid;
    const isFav = favorites.includes(id);
    const favDocId = `${userId}_${id}`;
    const favRef = doc(db, 'users', userId, 'favorites', favDocId);

    try {
      if (isFav) {
        await deleteDoc(favRef);
      } else {
        await setDoc(favRef, {
          userId,
          projectId: id,
          createdAt: serverTimestamp()
        });
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const filteredProjects = useMemo(() => {
    return MOCK_PROJECTS.filter(project => {
      if (activeFilter === 'ALL') return true;
      if (activeFilter === 'OPEN') return project.status === 'OPEN';
      if (activeFilter === 'UPCOMING') return project.status === 'UPCOMING';
      if (activeFilter === 'HANOI') return project.location.includes('Hà Nội');
      if (activeFilter === 'HCM') return project.location.includes('Hồ Chí Minh');
      if (activeFilter === 'DANANG') return project.location.includes('Đà Nẵng');
      return true;
    });
  }, [activeFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
      <header className="mb-8 lg:mb-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="text-3xl lg:text-4xl font-extrabold text-zinc-900 tracking-tight">Danh mục dự án</h1>
            <p className="text-zinc-500 mt-2 text-base lg:text-lg">Khám phá 150+ dự án nhà ở xã hội đang mở bán trên toàn quốc.</p>
          </div>
          <div className="flex items-center gap-3 lg:gap-4 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            <div className="flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 rounded-xl shadow-sm shrink-0">
              <MapPin size={18} className="text-zinc-400" />
              <span className="text-sm font-bold text-zinc-900">Toàn quốc</span>
              <ChevronDown size={16} className="text-zinc-400" />
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 rounded-xl shadow-sm shrink-0">
              <Filter size={18} className="text-zinc-400" />
              <span className="text-sm font-bold text-zinc-900">Bộ lọc</span>
            </div>
          </div>
        </div>
      </header>

      <AIProjectAssistant />

      <div className="flex gap-2 mb-8 lg:mb-10 overflow-x-auto pb-4 no-scrollbar -mx-4 px-4 lg:mx-0 lg:px-0 scroll-smooth">
        {['ALL', 'OPEN', 'UPCOMING', 'HANOI', 'HCM', 'DANANG'].map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all shrink-0 ${
              activeFilter === filter 
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' 
                : 'bg-white text-zinc-500 border border-zinc-200 hover:border-emerald-200 hover:text-emerald-600'
            }`}
          >
            {filter === 'ALL' ? 'Tất cả' : 
             filter === 'OPEN' ? 'Đang mở bán' : 
             filter === 'UPCOMING' ? 'Sắp mở bán' : 
             filter === 'HANOI' ? 'Hà Nội' : 
             filter === 'HCM' ? 'TP. Hồ Chí Minh' : 'Đà Nẵng'}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
        {filteredProjects.map((project) => (
          <ProjectCard 
            key={project.id} 
            project={project} 
            favorites={favorites} 
            toggleFavorite={toggleFavorite} 
          />
        ))}
      </div>

      <div className="mt-20 text-center">
        <p className="text-zinc-500 mb-6">Bạn không tìm thấy dự án mong muốn?</p>
        <button className="px-8 py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all flex items-center gap-2 mx-auto">
          <Bell size={20} /> Nhận thông báo dự án mới
        </button>
      </div>
    </div>
  );
};
