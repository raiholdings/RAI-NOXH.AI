import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Building2, 
  MapPin, 
  Calendar, 
  Users, 
  ShieldCheck, 
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  FileText,
  Info,
  Clock
} from 'lucide-react';
import { MOCK_PROJECTS } from '../constants';

export const ProjectDetailView = () => {
  const { id } = useParams();
  const project = MOCK_PROJECTS.find(p => p.id === id);

  if (!project) return <div>Project not found</div>;

  return (
    <div className="space-y-8">
      <Link to="/projects" className="flex items-center gap-2 text-zinc-500 hover:text-zinc-900 transition-colors">
        <ArrowLeft size={20} /> Quay lại danh sách
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
            <div className="h-96 overflow-hidden">
              <img src={project.image} alt={project.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div className="p-8">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-3xl font-bold text-zinc-900">{project.name}</h1>
                  <p className="text-zinc-500 mt-2 flex items-center gap-2">
                    <MapPin size={18} /> {project.location}
                  </p>
                  <div className="mt-4 w-full h-48 rounded-2xl overflow-hidden border border-zinc-100 shadow-inner bg-zinc-50 relative">
                    <iframe
                      width="100%"
                      height="100%"
                      frameBorder="0"
                      style={{ border: 0 }}
                      src={`https://maps.google.com/maps?q=${encodeURIComponent(project.location)}&t=&z=13&ie=UTF8&iwloc=&output=embed`}
                      allowFullScreen
                      title="Project Location Map"
                    ></iframe>
                    <div className="absolute bottom-4 right-4 pointer-events-none">
                      <div className="bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-sm border border-white/20 flex items-center gap-2">
                        <MapPin size={12} className="text-emerald-600" />
                        <span className="text-[10px] font-bold text-zinc-900 uppercase tracking-wider">Vị trí dự án</span>
                      </div>
                    </div>
                  </div>
                </div>
                <span className="px-4 py-1.5 bg-emerald-500 text-white rounded-full text-xs font-bold uppercase tracking-wider">
                  {project.status === 'OPEN' ? 'Đang mở bán' : 'Sắp mở bán'}
                </span>
              </div>

              <div className="mt-8 grid grid-cols-3 gap-4">
                <div className="p-4 bg-zinc-50 rounded-2xl">
                  <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Giá dự kiến</p>
                  <p className="text-lg font-bold text-zinc-900 mt-1">{project.priceRange}</p>
                </div>
                <div className="p-4 bg-zinc-50 rounded-2xl">
                  <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Số lượng căn</p>
                  <p className="text-lg font-bold text-zinc-900 mt-1">{project.units} căn</p>
                </div>
                <div className="p-4 bg-zinc-50 rounded-2xl">
                  <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Chủ đầu tư</p>
                  <p className="text-lg font-bold text-zinc-900 mt-1">{project.developer}</p>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="text-xl font-bold text-zinc-900">Mô tả dự án</h3>
                <p className="text-zinc-600 mt-4 leading-relaxed">
                  {project.description}
                </p>
                <div className="mt-6">
                  <Link 
                    to={`/marketplace?project=${encodeURIComponent(project.name)}&location=${encodeURIComponent(project.location)}`}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-100"
                  >
                    Yêu cầu dịch vụ hỗ trợ <ArrowRight size={18} />
                  </Link>
                </div>
              </div>

              <div className="mt-8">
                <h3 className="text-xl font-bold text-zinc-900">Tiêu chí xét duyệt</h3>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                  {project.criteria.map((c, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100">
                      <CheckCircle2 size={18} />
                      <span className="text-sm font-medium">{c}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
            <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4">Chủ đầu tư</h3>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl overflow-hidden border border-zinc-100 shrink-0">
                <img 
                  src={project.developerLogo || 'https://picsum.photos/seed/dev/100/100'} 
                  alt={project.developer} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <p className="font-bold text-zinc-900">{project.developer}</p>
                <p className="text-xs text-zinc-500">Đã xác thực bởi noxh.ai</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm sticky top-24">
            <h3 className="text-xl font-bold text-zinc-900">Tiến độ dự án</h3>
            <div className="mt-6 space-y-6 relative">
              <div className="absolute left-4 top-2 bottom-2 w-0.5 bg-zinc-100" />
              {project.timeline.map((item, i) => (
                <div key={i} className="flex gap-4 relative z-10">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    item.status === 'completed' ? 'bg-emerald-500 text-white' :
                    item.status === 'current' ? 'bg-white border-2 border-emerald-500 text-emerald-500' :
                    'bg-white border-2 border-zinc-200 text-zinc-300'
                  }`}>
                    {item.status === 'completed' ? <CheckCircle2 size={16} /> : <Clock size={16} />}
                  </div>
                  <div>
                    <p className={`text-sm font-bold ${item.status === 'upcoming' ? 'text-zinc-400' : 'text-zinc-900'}`}>
                      {item.label}
                    </p>
                    <p className="text-xs text-zinc-500 mt-0.5">{item.date}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-8 border-t border-zinc-100">
              <div className="flex items-start gap-3 p-4 bg-blue-50 text-blue-700 rounded-2xl mb-6">
                <Info size={20} className="shrink-0" />
                <p className="text-xs leading-relaxed">
                  Dự án này yêu cầu hồ sơ đã được xác thực VNeID và xác nhận thu nhập từ cơ quan công tác.
                </p>
              </div>
              <Link 
                to={`/apply/${project.id}`}
                className="block w-full py-4 bg-emerald-600 text-white text-center rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
              >
                Nộp hồ sơ ngay
              </Link>
              <Link 
                to={`/marketplace?project=${encodeURIComponent(project.name)}&location=${encodeURIComponent(project.location)}`}
                className="block w-full py-4 mt-3 border border-zinc-200 text-zinc-900 text-center rounded-2xl font-bold hover:bg-zinc-50 transition-all"
              >
                Yêu cầu dịch vụ hỗ trợ
              </Link>
              <p className="text-center text-[10px] text-zinc-400 mt-4 uppercase tracking-widest font-bold">
                Hạn cuối: 30/03/2024
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
