import React, { useState, useMemo } from 'react';
import { 
  Briefcase, 
  Users, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  BarChart3, 
  PlusCircle,
  Star,
  ExternalLink,
  Search,
  Filter,
  Download,
  MoreVertical,
  TrendingUp,
  DollarSign,
  Calendar,
  ChevronRight,
  X,
  Check,
  Eye,
  AlertCircle,
  FileText,
  ShieldCheck,
  ArrowUpRight,
  ArrowDownRight,
  Settings,
  MessageCircle,
  Award,
  User
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

// Mock Data
const ANALYTICS_DATA = [
  { name: 'Tháng 1', revenue: 45, orders: 24 },
  { name: 'Tháng 2', revenue: 52, orders: 32 },
  { name: 'Tháng 3', revenue: 48, orders: 28 },
  { name: 'Tháng 4', revenue: 61, orders: 42 },
  { name: 'Tháng 5', revenue: 55, orders: 38 },
  { name: 'Tháng 6', revenue: 72, orders: 50 },
];

const SERVICE_STATS = [
  { name: 'Tư vấn vay', value: 400 },
  { name: 'Thẩm định', value: 300 },
  { name: 'Pháp lý', value: 200 },
  { name: 'Bảo hiểm', value: 100 },
];

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

const MOCK_SERVICES = [
  { 
    id: 'S1', 
    name: 'Gói vay ưu đãi 4.8%', 
    category: 'Tài chính', 
    status: 'ACTIVE', 
    leads: 124, 
    price: 'Lãi suất 4.8%', 
    rating: 4.9,
    packages: [
      { name: 'Cơ bản', price: 'Miễn phí', features: ['Tư vấn hồ sơ', 'Kiểm tra điểm tín dụng'] },
      { name: 'Nâng cao', price: '500k', features: ['Hỗ trợ làm hồ sơ', 'Kết nối ngân hàng'] },
      { name: 'VIP', price: '2tr', features: ['Cam kết giải ngân', 'Hỗ trợ tận nơi'] }
    ]
  },
  { 
    id: 'S2', 
    name: 'Thẩm định hồ sơ nhanh', 
    category: 'Pháp lý', 
    status: 'ACTIVE', 
    leads: 85, 
    price: '500k/hồ sơ', 
    rating: 4.8,
    packages: [
      { name: 'Tiêu chuẩn', price: '500k', features: ['Thẩm định trong 24h', 'Báo cáo chi tiết'] }
    ]
  },
  { id: 'S3', name: 'Tư vấn pháp lý 1-1', category: 'Tư vấn', status: 'PAUSED', leads: 42, price: '1tr/giờ', rating: 4.7 },
  { id: 'S4', name: 'Bảo hiểm nhà ở xã hội', category: 'Bảo hiểm', status: 'ACTIVE', leads: 30, price: '2tr/năm', rating: 4.9 },
];

const MOCK_REVIEWS = [
  { id: 'R1', user: 'Nguyễn Văn A', rating: 5, comment: 'Dịch vụ rất chuyên nghiệp, hỗ trợ nhiệt tình.', date: '2024-03-10' },
  { id: 'R2', user: 'Trần Thị B', rating: 4, comment: 'Hồ sơ được xử lý nhanh, tuy nhiên phí hơi cao.', date: '2024-03-08' },
  { id: 'R3', user: 'Lê Văn C', rating: 5, comment: 'Rất hài lòng với gói vay ưu đãi này.', date: '2024-03-05' },
];

const MOCK_ORDERS = [
  { id: 'ORD-001', customer: 'Nguyễn Văn A', service: 'Gói vay ưu đãi 4.8%', status: 'PENDING', date: '2024-03-01', amount: '2.5 tỷ' },
  { id: 'ORD-002', customer: 'Trần Thị B', service: 'Thẩm định hồ sơ nhanh', status: 'IN_PROGRESS', date: '2024-03-02', amount: '500k' },
  { id: 'ORD-003', customer: 'Lê Văn C', service: 'Tư vấn pháp lý 1-1', status: 'COMPLETED', date: '2024-03-03', amount: '1tr' },
  { id: 'ORD-004', customer: 'Phạm Minh D', service: 'Gói vay ưu đãi 4.8%', status: 'CANCELLED', date: '2024-03-04', amount: '1.8 tỷ' },
  { id: 'ORD-005', customer: 'Hoàng Văn E', service: 'Thẩm định hồ sơ nhanh', status: 'PENDING', date: '2024-03-05', amount: '500k' },
];

const OrderDetailModal = ({ order, isOpen, onClose }: { order: any, isOpen: boolean, onClose: () => void }) => {
  if (!order) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden"
          >
            <div className="p-8 border-b border-zinc-100 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-zinc-900">Chi tiết đơn hàng</h3>
                <p className="text-xs text-zinc-500 mt-1">Mã đơn: {order.id} • Ngày đặt: {order.date}</p>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="p-8 space-y-8 overflow-y-auto max-h-[70vh]">
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Thông tin khách hàng</h4>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-500">
                      <User size={20} />
                    </div>
                    <div>
                      <p className="font-bold text-zinc-900">{order.customer}</p>
                      <p className="text-xs text-zinc-500">Khách hàng NOXH</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <h4 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Trạng thái</h4>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    order.status === 'COMPLETED' ? 'bg-emerald-50 text-emerald-600' :
                    order.status === 'PENDING' ? 'bg-amber-50 text-amber-600' :
                    'bg-blue-50 text-blue-600'
                  }`}>
                    {order.status === 'COMPLETED' ? 'Hoàn thành' :
                     order.status === 'PENDING' ? 'Chờ xử lý' : 'Đang thực hiện'}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Dịch vụ đã đặt</h4>
                <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                  <div className="flex justify-between items-center">
                    <p className="font-bold text-zinc-900">{order.service}</p>
                    <p className="font-bold text-zinc-900">{order.amount}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tiến độ công việc</h4>
                <div className="space-y-4">
                  {[
                    { step: 'Tiếp nhận hồ sơ', date: '10/02/2024', done: true },
                    { step: 'Thẩm định sơ bộ', date: '12/02/2024', done: true },
                    { step: 'Xử lý chuyên môn', date: '-', done: false },
                    { step: 'Bàn giao kết quả', date: '-', done: false },
                  ].map((step, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${step.done ? 'bg-emerald-500 text-white' : 'bg-zinc-200 text-zinc-400'}`}>
                        {step.done ? <Check size={14} /> : <div className="w-2 h-2 bg-current rounded-full" />}
                      </div>
                      <div className="flex-1 flex justify-between items-center">
                        <p className={`text-sm ${step.done ? 'text-zinc-900 font-medium' : 'text-zinc-400'}`}>{step.step}</p>
                        <p className="text-xs text-zinc-400">{step.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-8 bg-zinc-50 border-t border-zinc-100 flex gap-4">
              <button className="flex-1 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all">
                Cập nhật tiến độ
              </button>
              <button className="px-6 py-3 border border-zinc-200 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-100 transition-all">
                Liên hệ khách
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export const ProviderView = () => {
  const [activeTab, setActiveTab] = useState('DASHBOARD');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isAddingService, setIsAddingService] = useState(false);

  const tabs = [
    { id: 'DASHBOARD', label: 'Tổng quan', icon: BarChart3 },
    { id: 'ORDERS', label: 'Yêu cầu dịch vụ', icon: Briefcase },
    { id: 'SERVICES', label: 'Gói dịch vụ', icon: PlusCircle },
    { id: 'REVIEWS', label: 'Đánh giá', icon: Award },
    { id: 'MESSAGES', label: 'Tin nhắn', icon: MessageSquare },
    { id: 'ANALYTICS', label: 'Báo cáo', icon: TrendingUp },
    { id: 'SETTINGS', label: 'Cài đặt', icon: Settings },
  ];

  return (
    <div className="space-y-8 pb-20 lg:pb-0">
      <OrderDetailModal 
        order={selectedOrder} 
        isOpen={isOrderModalOpen} 
        onClose={() => {
          setIsOrderModalOpen(false);
          setSelectedOrder(null);
        }} 
      />
      
      {/* Add Service Modal */}
      <AnimatePresence>
        {isAddingService && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsAddingService(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 20 }} className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
              <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center">
                    <PlusCircle size={20} />
                  </div>
                  <h3 className="font-bold text-zinc-900">Tạo gói dịch vụ mới</h3>
                </div>
                <button onClick={() => setIsAddingService(false)} className="p-2 hover:bg-zinc-100 rounded-full transition-colors">
                  <X size={20} className="text-zinc-400" />
                </button>
              </div>
              <div className="p-8 overflow-y-auto space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tên dịch vụ</label>
                    <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: Tư vấn vay vốn ưu đãi" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Danh mục</label>
                    <select className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500">
                      <option>Tài chính</option>
                      <option>Pháp lý</option>
                      <option>Bảo hiểm</option>
                      <option>Tư vấn</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Giá dịch vụ</label>
                    <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: 500k/hồ sơ" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Thời gian xử lý dự kiến</label>
                    <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="VD: 3-5 ngày làm việc" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Mô tả chi tiết</label>
                  <textarea className="w-full h-32 bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Nhập thông tin chi tiết về gói dịch vụ..." />
                </div>
              </div>
              <div className="p-6 border-t border-zinc-100 bg-zinc-50/50 flex justify-end gap-3">
                <button onClick={() => setIsAddingService(false)} className="px-6 py-2.5 bg-white border border-zinc-200 text-zinc-600 rounded-xl text-sm font-bold hover:bg-zinc-50 transition-all">
                  Hủy bỏ
                </button>
                <button className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 transition-all">
                  Xác nhận tạo dịch vụ
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">Trung tâm Đối tác</h1>
          <p className="text-zinc-500 mt-1">Chào mừng trở lại, Techcombank Partner.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-3 bg-white border border-zinc-200 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-50 transition-all flex items-center gap-2 shadow-sm">
            <Download size={18} /> Xuất báo cáo
          </button>
          <button 
            onClick={() => setIsAddingService(true)}
            className="px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100"
          >
            <PlusCircle size={18} /> Thêm dịch vụ mới
          </button>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="flex gap-1 bg-zinc-100 p-1 rounded-2xl w-fit overflow-x-auto max-w-full">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
              activeTab === tab.id 
                ? 'bg-white text-zinc-900 shadow-sm' 
                : 'text-zinc-500 hover:text-zinc-900'
            }`}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'DASHBOARD' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { label: 'Doanh thu tháng', value: '125.5tr', change: '+15%', trend: 'up', icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
              { label: 'Yêu cầu mới', value: '45', change: '+8%', trend: 'up', icon: Briefcase, color: 'text-blue-600', bg: 'bg-blue-50' },
              { label: 'Hoàn thành', value: '128', change: '+22%', trend: 'up', icon: CheckCircle2, color: 'text-purple-600', bg: 'bg-purple-50' },
              { label: 'Đánh giá', value: '4.9/5', change: '+0.1', trend: 'up', icon: Star, color: 'text-amber-600', bg: 'bg-amber-50' },
            ].map((stat, i) => (
              <div key={i} className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-3 rounded-2xl ${stat.bg} ${stat.color}`}>
                    <stat.icon size={24} />
                  </div>
                  <div className={`flex items-center gap-1 text-[10px] font-bold ${stat.trend === 'up' ? 'text-emerald-600' : 'text-red-600'}`}>
                    {stat.trend === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    {stat.change}
                  </div>
                </div>
                <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{stat.label}</p>
                <p className="text-2xl font-black text-zinc-900 mt-1">{stat.value}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-lg font-bold text-zinc-900">Hiệu suất kinh doanh</h3>
                  <p className="text-xs text-zinc-500">Doanh thu và số lượng đơn hàng theo tháng</p>
                </div>
                <select className="bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                  <option>6 tháng gần nhất</option>
                  <option>1 năm gần nhất</option>
                </select>
              </div>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={ANALYTICS_DATA}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#a1a1aa'}} />
                    <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
              <h3 className="text-lg font-bold text-zinc-900 mb-6">Cơ cấu dịch vụ</h3>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={SERVICE_STATS}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {SERVICE_STATS.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-3 mt-6">
                {SERVICE_STATS.map((item, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                      <span className="text-xs text-zinc-500 font-medium">{item.name}</span>
                    </div>
                    <span className="text-xs font-bold text-zinc-900">{item.value} đơn</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'ORDERS' && (
        <section className="bg-white rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden">
          <div className="p-8 border-b border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-6">
            <h2 className="text-xl font-bold text-zinc-900">Danh sách yêu cầu dịch vụ</h2>
            <div className="flex gap-3 w-full md:w-auto">
              <div className="relative flex-grow md:flex-grow-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input type="text" placeholder="Tìm khách hàng, mã đơn..." className="pl-10 pr-4 py-2.5 bg-zinc-50 border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none w-full md:w-64" />
              </div>
              <button className="p-2.5 border border-zinc-200 rounded-xl text-zinc-500 hover:bg-zinc-50">
                <Filter size={20} />
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-zinc-50 text-zinc-500 font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-8 py-4">Khách hàng</th>
                  <th className="px-8 py-4">Dịch vụ</th>
                  <th className="px-8 py-4">Ngày yêu cầu</th>
                  <th className="px-8 py-4">Giá trị dự kiến</th>
                  <th className="px-8 py-4">Trạng thái</th>
                  <th className="px-8 py-4 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {MOCK_ORDERS.map((order) => (
                  <tr 
                    key={order.id} 
                    className="hover:bg-zinc-50 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedOrder(order);
                      setIsOrderModalOpen(true);
                    }}
                  >
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-500 font-bold text-xs">
                          {order.customer.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-zinc-900">{order.customer}</p>
                          <p className="text-[10px] text-zinc-500">{order.id}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-zinc-500 font-medium">{order.service}</td>
                    <td className="px-8 py-5 text-zinc-500 font-medium">{order.date}</td>
                    <td className="px-8 py-5 font-bold text-zinc-900">{order.amount}</td>
                    <td className="px-8 py-5">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${
                        order.status === 'PENDING' ? 'bg-amber-50 text-amber-600' : 
                        order.status === 'IN_PROGRESS' ? 'bg-blue-50 text-blue-600' :
                        order.status === 'COMPLETED' ? 'bg-emerald-50 text-emerald-600' :
                        'bg-red-50 text-red-600'
                      }`}>
                        {order.status === 'PENDING' ? 'Chờ xử lý' : 
                         order.status === 'IN_PROGRESS' ? 'Đang thực hiện' :
                         order.status === 'COMPLETED' ? 'Hoàn thành' : 'Đã hủy'}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button 
                        onClick={() => setSelectedOrder(order)}
                        className="px-4 py-2 bg-zinc-900 text-white rounded-xl text-xs font-bold hover:bg-zinc-800 transition-all"
                      >
                        Chi tiết
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {activeTab === 'SERVICES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {MOCK_SERVICES.map((service) => (
            <div key={service.id} className="bg-white rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden group hover:shadow-xl transition-all duration-500">
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                    <Briefcase size={24} />
                  </div>
                  <button className="p-2 text-zinc-400 hover:text-zinc-900">
                    <MoreVertical size={20} />
                  </button>
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2">{service.name}</h3>
                <div className="flex items-center gap-4 mb-6">
                  <span className="text-xs text-zinc-500 font-medium">{service.category}</span>
                  <div className="flex items-center gap-1 text-amber-500">
                    <Star size={14} fill="currentColor" />
                    <span className="text-xs font-bold">{service.rating}</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-zinc-50 rounded-2xl">
                    <div>
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Giá dịch vụ</p>
                      <p className="text-sm font-bold text-zinc-900">{service.price}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Lượt quan tâm</p>
                      <p className="text-sm font-bold text-zinc-900">{service.leads}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="px-8 py-4 bg-zinc-50 border-t border-zinc-100 flex justify-between items-center">
                <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest ${
                  service.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-600' : 'bg-zinc-200 text-zinc-500'
                }`}>
                  {service.status === 'ACTIVE' ? 'Đang hiển thị' : 'Đã tạm dừng'}
                </span>
                <button className="text-xs font-bold text-emerald-600 hover:underline">Chỉnh sửa</button>
              </div>
            </div>
          ))}
          <button 
            onClick={() => setIsAddingService(true)}
            className="border-2 border-dashed border-zinc-200 rounded-[32px] p-8 flex flex-col items-center justify-center gap-4 text-zinc-400 hover:border-emerald-500 hover:text-emerald-600 transition-all group"
          >
            <div className="w-16 h-16 bg-zinc-50 rounded-full flex items-center justify-center group-hover:bg-emerald-50 transition-all">
              <PlusCircle size={32} />
            </div>
            <span className="font-bold">Thêm dịch vụ mới</span>
          </button>
        </div>
      )}

      {activeTab === 'MESSAGES' && (
        <div className="bg-white rounded-[32px] border border-zinc-200 shadow-sm overflow-hidden flex h-[600px]">
          <div className="w-1/3 border-r border-zinc-100 flex flex-col">
            <div className="p-6 border-b border-zinc-100">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input type="text" placeholder="Tìm hội thoại..." className="pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl text-sm w-full outline-none focus:ring-2 focus:ring-emerald-500" />
              </div>
            </div>
            <div className="flex-grow overflow-y-auto">
              {[
                { name: 'Nguyễn Văn A', lastMsg: 'Tôi đã gửi hồ sơ thu nhập, bạn kiểm tra...', time: '10:30', unread: 2, avatar: 'A' },
                { name: 'Trần Thị B', lastMsg: 'Cảm ơn bạn đã tư vấn nhiệt tình...', time: 'Hôm qua', unread: 0, avatar: 'B' },
                { name: 'Lê Văn C', lastMsg: 'Gói vay này có áp dụng cho công nhân...', time: '2 ngày trước', unread: 0, avatar: 'C' },
                { name: 'Hệ thống NOXH.ai', lastMsg: 'Bạn có 5 yêu cầu dịch vụ mới cần xử lý...', time: '3 ngày trước', unread: 1, avatar: 'AI' },
              ].map((chat, i) => (
                <div key={i} className={`p-4 flex gap-3 cursor-pointer hover:bg-zinc-50 transition-colors ${i === 0 ? 'bg-blue-50/50 border-r-2 border-blue-500' : ''}`}>
                  <div className="w-12 h-12 bg-zinc-200 rounded-full flex items-center justify-center font-bold text-zinc-500 text-sm">
                    {chat.avatar}
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-bold text-zinc-900 text-sm truncate">{chat.name}</h4>
                      <span className="text-[10px] text-zinc-400">{chat.time}</span>
                    </div>
                    <p className="text-xs text-zinc-500 truncate">{chat.lastMsg}</p>
                  </div>
                  {chat.unread > 0 && (
                    <div className="w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-[10px] font-bold">
                      {chat.unread}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="flex-grow flex flex-col bg-zinc-50/30">
            <div className="p-6 border-b border-zinc-100 bg-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center font-bold text-zinc-500 text-xs">
                  A
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 text-sm">Nguyễn Văn A</h4>
                  <p className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" /> Trực tuyến
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 text-zinc-400 hover:text-zinc-900"><Download size={20} /></button>
                <button className="p-2 text-zinc-400 hover:text-zinc-900"><MoreVertical size={20} /></button>
              </div>
            </div>
            <div className="flex-grow p-6 overflow-y-auto space-y-4">
              <div className="flex justify-center">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest bg-white px-3 py-1 rounded-full border border-zinc-100">Hôm nay</span>
              </div>
              <div className="flex gap-3 max-w-[80%]">
                <div className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center font-bold text-zinc-500 text-[10px] flex-shrink-0">A</div>
                <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-zinc-100 shadow-sm">
                  <p className="text-sm text-zinc-700 leading-relaxed">
                    Chào bạn, tôi đã tải lên hồ sơ xác nhận thu nhập trong kho tài liệu. Bạn kiểm tra giúp tôi xem có đủ điều kiện đăng ký gói vay 4.8% không nhé.
                  </p>
                  <span className="text-[10px] text-zinc-400 mt-2 block">10:25</span>
                </div>
              </div>
              <div className="flex gap-3 max-w-[80%] ml-auto flex-row-reverse">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center font-bold text-white text-[10px] flex-shrink-0">P</div>
                <div className="bg-blue-600 p-4 rounded-2xl rounded-tr-none text-white shadow-md shadow-blue-100">
                  <p className="text-sm leading-relaxed">
                    Chào anh A, tôi đã nhận được thông báo. Tôi sẽ tiến hành thẩm định sơ bộ hồ sơ của anh ngay bây giờ và phản hồi lại trong vòng 30 phút tới.
                  </p>
                  <span className="text-[10px] text-blue-200 mt-2 block text-right">10:30</span>
                </div>
              </div>
            </div>
            <div className="p-6 bg-white border-t border-zinc-100">
              <div className="flex gap-3">
                <button className="p-2 text-zinc-400 hover:text-blue-600 transition-colors">
                  <PlusCircle size={24} />
                </button>
                <input type="text" placeholder="Nhập tin nhắn..." className="flex-grow bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500" />
                <button className="px-6 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all">
                  Gửi
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'REVIEWS' && (
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-xl font-bold text-zinc-900">Đánh giá từ khách hàng</h3>
                <p className="text-sm text-zinc-500">Quản lý phản hồi và cải thiện chất lượng dịch vụ</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-2xl font-black text-zinc-900">4.9/5</p>
                  <div className="flex items-center gap-1 text-amber-500">
                    {[1, 2, 3, 4, 5].map(s => <Star key={s} size={14} fill="currentColor" />)}
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              {MOCK_REVIEWS.map((review) => (
                <div key={review.id} className="p-6 bg-zinc-50 rounded-2xl border border-zinc-100">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-zinc-200 rounded-full flex items-center justify-center font-bold text-zinc-500">
                        {review.user.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-zinc-900">{review.user}</h4>
                        <p className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">{review.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-amber-500">
                      {Array.from({ length: review.rating }).map((_, i) => (
                        <Star key={i} size={14} fill="currentColor" />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-zinc-600 leading-relaxed italic">"{review.comment}"</p>
                  <div className="mt-4 flex gap-3">
                    <button className="text-xs font-bold text-blue-600 hover:underline">Phản hồi</button>
                    <button className="text-xs font-bold text-zinc-400 hover:text-zinc-600">Báo cáo</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="max-w-4xl space-y-8">
          <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
            <h3 className="text-xl font-bold text-zinc-900 mb-8">Thông tin đối tác</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tên đơn vị</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="Techcombank Partner" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Mã số thuế</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="0101234567" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Địa chỉ trụ sở</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="191 Bà Triệu, Hai Bà Trưng, Hà Nội" />
                </div>
              </div>
              <div className="space-y-6">
                <div className="p-6 bg-emerald-50 border border-emerald-100 rounded-2xl">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center">
                      <ShieldCheck size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-emerald-900 text-sm">Trạng thái xác thực</h4>
                      <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest">Đã xác minh</p>
                    </div>
                  </div>
                  <p className="text-xs text-emerald-700 leading-relaxed">
                    Tài khoản của bạn đã được xác thực chính thức bởi NOXH.ai. Bạn có quyền truy cập đầy đủ các tính năng nâng cao.
                  </p>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tài khoản nhận thanh toán</label>
                  <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-white rounded-lg border border-zinc-100 flex items-center justify-center">
                        <DollarSign size={16} className="text-zinc-400" />
                      </div>
                      <span className="text-sm font-bold text-zinc-900">Techcombank **** 8888</span>
                    </div>
                    <button className="text-xs font-bold text-blue-600">Thay đổi</button>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t border-zinc-100 flex justify-end">
              <button className="px-8 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all">
                Lưu thay đổi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

