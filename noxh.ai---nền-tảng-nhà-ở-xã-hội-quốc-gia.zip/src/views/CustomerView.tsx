import React, { useState } from 'react';
import { 
  FileText, 
  ShieldCheck, 
  Briefcase, 
  Building2, 
  ChevronRight, 
  Search, 
  ArrowRight,
  Plus,
  Trash2,
  Download,
  AlertCircle,
  Sparkles,
  CheckCircle2,
  XCircle,
  Info,
  Smartphone,
  X,
  Clock,
  MessageSquare,
  Settings as SettingsIcon,
  CreditCard,
  User as UserIcon,
  Bell,
  Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_APPLICATIONS, MOCK_PROJECTS } from '../constants';
import { Link } from 'react-router-dom';

const VNeIDModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-md bg-white rounded-[32px] shadow-2xl overflow-hidden"
          >
            <div className="bg-red-600 p-6 text-white text-center">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Smartphone size={32} />
              </div>
              <h3 className="text-xl font-bold">Định danh điện tử VNeID</h3>
              <p className="text-red-100 text-sm mt-1">Dữ liệu được đồng bộ từ Bộ Công An</p>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="flex items-center gap-4 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                <div className="w-12 h-12 rounded-full bg-zinc-200 overflow-hidden flex items-center justify-center text-zinc-400">
                  <User size={24} />
                </div>
                <div>
                  <p className="text-sm font-bold text-zinc-900">NGUYỄN VĂN A</p>
                  <p className="text-xs text-zinc-500">Số định danh: 00109200****</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-zinc-100">
                  <span className="text-xs text-zinc-500">Ngày sinh</span>
                  <span className="text-sm font-bold">01/01/1992</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-zinc-100">
                  <span className="text-xs text-zinc-500">Giới tính</span>
                  <span className="text-sm font-bold">Nam</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-zinc-100">
                  <span className="text-xs text-zinc-500">Quê quán</span>
                  <span className="text-sm font-bold">Hà Nội</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-zinc-100">
                  <span className="text-xs text-zinc-500">Trạng thái định danh</span>
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Mức độ 2</span>
                </div>
              </div>

              <button 
                onClick={onClose}
                className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all"
              >
                Đóng
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const User = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);

const AIDocumentAnalysis = () => {
  const insights = [
    { 
      type: 'success', 
      title: 'Định danh VNeID', 
      desc: 'Thông tin nhân thân khớp 100% với CSDL quốc gia.',
      icon: CheckCircle2
    },
    { 
      type: 'warning', 
      title: 'Xác nhận thu nhập', 
      desc: 'Mẫu số 03 của bạn đã cũ (hơn 6 tháng). Cần cập nhật bản mới.',
      icon: AlertCircle
    },
    { 
      type: 'error', 
      title: 'Đơn đăng ký', 
      desc: 'Thiếu chữ ký tại trang 3 của Đơn đăng ký mua NOXH.',
      icon: XCircle
    }
  ];

  return (
    <div className="bg-white rounded-2xl lg:rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
      <div className="p-5 lg:p-6 border-b border-zinc-100 bg-zinc-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-100">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="font-bold text-zinc-900 text-sm lg:text-base">Phân tích hồ sơ bởi AI</h3>
            <p className="text-[10px] lg:text-xs text-zinc-500">Cập nhật 2 phút trước • 4 tài liệu</p>
          </div>
        </div>
        <div className="text-left sm:text-right">
          <p className="text-[8px] lg:text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Điểm tin cậy</p>
          <p className="text-xl lg:text-2xl font-black text-emerald-600">85<span className="text-xs lg:text-sm text-zinc-400 font-medium">/100</span></p>
        </div>
      </div>
      <div className="p-5 lg:p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {insights.map((insight, i) => (
            <div key={i} className={`p-4 rounded-xl lg:rounded-2xl border ${
              insight.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-900' :
              insight.type === 'warning' ? 'bg-amber-50 border-amber-100 text-amber-900' :
              'bg-red-50 border-red-100 text-red-900'
            }`}>
              <div className="flex items-center gap-2 mb-2">
                <insight.icon size={16} className={
                  insight.type === 'success' ? 'text-emerald-600' :
                  insight.type === 'warning' ? 'text-amber-600' :
                  'text-red-600'
                } />
                <span className="text-[10px] font-bold uppercase tracking-wider">{insight.title}</span>
              </div>
              <p className="text-xs lg:text-sm leading-relaxed opacity-80">{insight.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 p-4 bg-zinc-900 text-white rounded-xl lg:rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Info size={18} className="text-emerald-400 shrink-0" />
            <p className="text-xs lg:text-sm font-medium">Bạn có thể tăng điểm lên 95+ bằng cách cập nhật Xác nhận thu nhập.</p>
          </div>
          <button className="w-full sm:w-auto text-[10px] lg:text-xs font-bold bg-white/10 hover:bg-white/20 px-4 py-2.5 rounded-xl transition-colors">
            Tối ưu ngay
          </button>
        </div>
      </div>
    </div>
  );
};

export const CustomerDashboard = () => {
  const [isVNeIDOpen, setIsVNeIDOpen] = useState(false);

  return (
    <div className="space-y-6 lg:space-y-8 pb-20 lg:pb-0">
      <VNeIDModal isOpen={isVNeIDOpen} onClose={() => setIsVNeIDOpen(false)} />
      <header>
        <h1 className="text-2xl lg:text-3xl font-bold text-zinc-900">Chào mừng, Nguyễn Văn A</h1>
        <p className="text-sm lg:text-base text-zinc-500 mt-1">Dưới đây là tóm tắt hồ sơ và các dự án phù hợp.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
        <div className="bg-white p-5 lg:p-6 rounded-2xl border border-zinc-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
              <FileText size={24} />
            </div>
            <span className="text-[10px] lg:text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">85% Hoàn thiện</span>
          </div>
          <h3 className="font-bold text-zinc-900">Gói hồ sơ chuẩn</h3>
          <p className="text-xs lg:text-sm text-zinc-500 mt-1">Hồ sơ đã được AI kiểm tra và sẵn sàng nộp.</p>
          <Link to="/vault" className="mt-4 block w-full py-2.5 bg-zinc-900 text-white text-center rounded-xl text-sm font-medium hover:bg-zinc-800 transition-colors">
            Cập nhật hồ sơ
          </Link>
        </div>

        <div className="bg-white p-5 lg:p-6 rounded-2xl border border-zinc-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
              <ShieldCheck size={24} />
            </div>
            <span className="text-[10px] lg:text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">Đã định danh</span>
          </div>
          <h3 className="font-bold text-zinc-900">Định danh VNeID</h3>
          <p className="text-xs lg:text-sm text-zinc-500 mt-1">Thông tin nhân thân đã được xác thực từ CSDL quốc gia.</p>
          <button 
            onClick={() => setIsVNeIDOpen(true)}
            className="mt-4 w-full py-2.5 border border-zinc-200 text-zinc-900 rounded-xl text-sm font-medium hover:bg-zinc-50 transition-colors"
          >
            Xem chi tiết
          </button>
        </div>

        <div className="bg-white p-5 lg:p-6 rounded-2xl border border-zinc-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-amber-100 text-amber-600 rounded-lg">
              <Briefcase size={24} />
            </div>
            <span className="text-[10px] lg:text-xs font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded">2 Yêu cầu</span>
          </div>
          <h3 className="font-bold text-zinc-900">Dịch vụ hỗ trợ</h3>
          <p className="text-xs lg:text-sm text-zinc-500 mt-1">Bạn có 2 báo giá từ ngân hàng và công chứng viên.</p>
          <Link to="/marketplace" className="mt-4 block w-full py-2.5 border border-zinc-200 text-zinc-900 text-center rounded-xl text-sm font-medium hover:bg-zinc-50 transition-colors">
            Xem báo giá
          </Link>
        </div>
      </div>

      <AIDocumentAnalysis />

      <section>
        <div className="flex justify-between items-end mb-6">
          <div>
            <h2 className="text-lg lg:text-xl font-bold text-zinc-900">Hồ sơ của tôi</h2>
            <p className="text-xs lg:text-sm text-zinc-500">Theo dõi tiến độ xét duyệt các dự án.</p>
          </div>
          <Link to="/applications" className="text-xs lg:text-sm font-medium text-emerald-600 hover:underline">Xem tất cả</Link>
        </div>
        <div className="space-y-3 lg:space-y-4">
          {MOCK_APPLICATIONS.map(app => (
            <div key={app.id} className="bg-white p-4 rounded-xl lg:rounded-2xl border border-zinc-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 lg:w-12 lg:h-12 bg-zinc-100 rounded-lg lg:rounded-xl flex items-center justify-center text-zinc-400">
                  <Building2 size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 text-sm lg:text-base">{app.projectName}</h4>
                  <p className="text-[10px] lg:text-xs text-zinc-500">Mã: {app.id} • {app.submittedAt}</p>
                </div>
              </div>
              <div className="flex items-center justify-between sm:justify-end gap-4 lg:gap-8 border-t sm:border-t-0 pt-3 sm:pt-0">
                <div className="text-left sm:text-right">
                  <p className="text-[10px] text-zinc-400 mb-0.5">Điểm xét duyệt</p>
                  <p className="font-bold text-zinc-900 text-sm">{app.score > 0 ? `${app.score}/100` : '-'}</p>
                </div>
                <div className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                  app.status === 'REVIEWING' ? 'bg-blue-50 text-blue-600' :
                  app.status === 'DRAFT' ? 'bg-zinc-100 text-zinc-500' :
                  'bg-emerald-50 text-emerald-600'
                }`}>
                  {app.status === 'REVIEWING' ? 'Đang xét duyệt' :
                   app.status === 'DRAFT' ? 'Bản nháp' : 'Đã duyệt'}
                </div>
                <Link to="/applications" className="p-2 text-zinc-400 hover:text-zinc-900 hidden sm:block">
                  <ChevronRight size={20} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-end gap-4 mb-6">
          <div>
            <h2 className="text-lg lg:text-xl font-bold text-zinc-900">Dự án đang mở bán</h2>
            <p className="text-xs lg:text-sm text-zinc-500">Các dự án phù hợp với điều kiện của bạn.</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
            <input 
              type="text" 
              placeholder="Tìm dự án..." 
              className="pl-10 pr-4 py-2 bg-white border border-zinc-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none w-full sm:w-64"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MOCK_PROJECTS.map(project => (
            <Link to={`/projects/${project.id}`} key={project.id} className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden group hover:shadow-md transition-shadow">
              <div className="h-40 lg:h-48 overflow-hidden relative">
                <img src={project.image} alt={project.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                <div className="absolute top-4 left-4">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    project.status === 'OPEN' ? 'bg-emerald-500 text-white' : 'bg-zinc-500 text-white'
                  }`}>
                    {project.status === 'OPEN' ? 'Đang mở bán' : 'Sắp mở bán'}
                  </span>
                </div>
              </div>
              <div className="p-5">
                <h4 className="font-bold text-zinc-900 text-sm lg:text-base line-clamp-1">{project.name}</h4>
                <p className="text-[10px] lg:text-xs text-zinc-500 mt-1 flex items-center gap-1">
                  <Building2 size={12} /> {project.developer}
                </p>
                <div className="mt-4 flex justify-between items-center">
                  <div>
                    <p className="text-[8px] lg:text-[10px] text-zinc-400 uppercase font-bold tracking-wider">Giá dự kiến</p>
                    <p className="text-xs lg:text-sm font-bold text-zinc-900">{project.priceRange}</p>
                  </div>
                  <div className="p-2 bg-zinc-100 text-zinc-900 rounded-lg group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                    <ArrowRight size={18} />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
};

export const DocumentVault = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleUpload = () => {
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      setUploadSuccess(true);
      setTimeout(() => setUploadSuccess(false), 3000);
    }, 2000);
  };

  const docs = [
    { id: '1', name: 'CCCD_NguyenVanA_MatTruoc.jpg', type: 'ID_CARD', status: 'VERIFIED', date: '12/02/2024' },
    { id: '2', name: 'XacNhanCuTru_HaNoi.pdf', type: 'RESIDENCY', status: 'VERIFIED', date: '14/02/2024' },
    { id: '3', name: 'GiayXacNhanThuNhap_2023.pdf', type: 'INCOME', status: 'PENDING', date: '20/02/2024' },
    { id: '4', name: 'DonDangKy_Mau01.docx', type: 'FORM', status: 'MISSING', date: '-' },
  ];

  return (
    <div className="space-y-6 lg:space-y-8 pb-20 lg:pb-0">
      <header className="flex flex-col sm:flex-row justify-between items-start gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-zinc-900">Kho tài liệu</h1>
          <p className="text-sm lg:text-base text-zinc-500 mt-1">Quản lý và lưu trữ hồ sơ pháp lý của bạn.</p>
        </div>
        <button 
          onClick={handleUpload}
          disabled={isUploading}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-100 disabled:opacity-50"
        >
          {isUploading ? <Clock className="animate-spin" size={20} /> : <Plus size={20} />}
          {isUploading ? 'Đang tải lên...' : 'Tải lên'}
        </button>
      </header>

      <AnimatePresence>
        {uploadSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center gap-3 text-emerald-600"
          >
            <CheckCircle2 size={20} />
            <span className="text-sm font-bold">Tải lên tài liệu thành công! AI đang tiến hành phân tích...</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-emerald-50 border border-emerald-100 p-4 lg:p-5 rounded-2xl flex items-start gap-3">
        <AlertCircle className="text-emerald-600 shrink-0" size={20} />
        <div>
          <p className="text-sm font-bold text-emerald-900">AI Gợi ý</p>
          <p className="text-xs lg:text-sm text-emerald-700 mt-0.5 leading-relaxed">
            Bạn đang thiếu "Đơn đăng ký mua NOXH (Mẫu 01)". Hãy sử dụng AI Copilot để được hướng dẫn điền mẫu này chính xác nhất.
          </p>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden lg:block bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-zinc-50 text-zinc-500 font-bold uppercase text-[10px] tracking-wider">
            <tr>
              <th className="px-6 py-4">Tên tài liệu</th>
              <th className="px-6 py-4">Loại</th>
              <th className="px-6 py-4">Trạng thái</th>
              <th className="px-6 py-4">Ngày cập nhật</th>
              <th className="px-6 py-4 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100">
            {docs.map((doc) => (
              <tr key={doc.id} className="hover:bg-zinc-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-zinc-100 rounded-lg text-zinc-400">
                      <FileText size={18} />
                    </div>
                    <span className="font-medium text-zinc-900">{doc.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-zinc-500">{doc.type}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${
                    doc.status === 'VERIFIED' ? 'bg-emerald-50 text-emerald-600' :
                    doc.status === 'PENDING' ? 'bg-amber-50 text-amber-600' :
                    doc.status === 'MISSING' ? 'bg-red-50 text-red-600' :
                    'bg-zinc-100 text-zinc-500'
                  }`}>
                    {doc.status === 'VERIFIED' ? 'Đã xác thực' :
                     doc.status === 'PENDING' ? 'Đang chờ' :
                     doc.status === 'MISSING' ? 'Thiếu' : 'Lỗi'}
                  </span>
                </td>
                <td className="px-6 py-4 text-zinc-500">{doc.date}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button className="p-2 text-zinc-400 hover:text-zinc-900"><Download size={16} /></button>
                    <button className="p-2 text-zinc-400 hover:text-red-600"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden space-y-4">
        {docs.map((doc) => (
          <div key={doc.id} className="bg-white p-4 rounded-2xl border border-zinc-200 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-zinc-100 rounded-lg text-zinc-400">
                  <FileText size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900 text-sm line-clamp-1">{doc.name}</h4>
                  <p className="text-[10px] text-zinc-500">{doc.type} • {doc.date}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-wider ${
                doc.status === 'VERIFIED' ? 'bg-emerald-50 text-emerald-600' :
                doc.status === 'PENDING' ? 'bg-amber-50 text-amber-600' :
                doc.status === 'MISSING' ? 'bg-red-50 text-red-600' :
                'bg-zinc-100 text-zinc-500'
              }`}>
                {doc.status === 'VERIFIED' ? 'Đã duyệt' :
                 doc.status === 'PENDING' ? 'Chờ' :
                 doc.status === 'MISSING' ? 'Thiếu' : 'Lỗi'}
              </span>
            </div>
            <div className="flex gap-2">
              <button className="flex-1 py-2 bg-zinc-50 text-zinc-600 rounded-xl text-xs font-bold flex items-center justify-center gap-2">
                <Download size={14} /> Tải xuống
              </button>
              <button className="p-2 bg-red-50 text-red-600 rounded-xl">
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const CustomerMessages = () => {
  const [activeChat, setActiveChat] = useState('AI');
  
  const chats = [
    { id: 'AI', name: 'AI Trợ lý NOXH', lastMsg: 'Bạn cần hỗ trợ gì về thủ tục nộp hồ sơ không?', time: 'Vừa xong', online: true, avatar: '✨' },
    { id: 'P1', name: 'Ngân hàng BIDV', lastMsg: 'Gói vay ưu đãi 4.8% đã được phê duyệt sơ bộ.', time: '10:30', online: true, avatar: '🏦' },
    { id: 'P2', name: 'Văn phòng Công chứng số 1', lastMsg: 'Hẹn bạn 9:00 sáng mai tại văn phòng.', time: 'Hôm qua', online: false, avatar: '⚖️' },
  ];

  return (
    <div className="h-[calc(100vh-180px)] lg:h-[calc(100vh-120px)] flex flex-col lg:flex-row gap-6">
      <div className="w-full lg:w-80 bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden flex flex-col">
        <div className="p-6 border-b border-zinc-100">
          <h2 className="text-xl font-bold text-zinc-900">Tin nhắn</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {chats.map(chat => (
            <button 
              key={chat.id}
              onClick={() => setActiveChat(chat.id)}
              className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all ${
                activeChat === chat.id ? 'bg-zinc-900 text-white' : 'hover:bg-zinc-50 text-zinc-900'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center text-xl shadow-inner">
                {chat.avatar}
              </div>
              <div className="flex-1 text-left min-w-0">
                <div className="flex justify-between items-center mb-1">
                  <p className="font-bold text-sm truncate">{chat.name}</p>
                  <span className={`text-[10px] ${activeChat === chat.id ? 'text-zinc-400' : 'text-zinc-500'}`}>{chat.time}</span>
                </div>
                <p className={`text-xs truncate ${activeChat === chat.id ? 'text-zinc-400' : 'text-zinc-500'}`}>{chat.lastMsg}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="hidden lg:flex flex-1 bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden flex flex-col">
        <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-zinc-100 flex items-center justify-center text-lg">
              {chats.find(c => c.id === activeChat)?.avatar}
            </div>
            <div>
              <h3 className="font-bold text-zinc-900">{chats.find(c => c.id === activeChat)?.name}</h3>
              <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest">Đang trực tuyến</p>
            </div>
          </div>
        </div>
        <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-zinc-50/50">
          <div className="flex justify-center">
            <span className="px-3 py-1 bg-zinc-200 text-zinc-500 text-[10px] font-bold rounded-full uppercase tracking-widest">Hôm nay</span>
          </div>
          <div className="flex gap-3 max-w-[80%]">
            <div className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-sm shrink-0">
              {chats.find(c => c.id === activeChat)?.avatar}
            </div>
            <div className="p-4 bg-white rounded-2xl rounded-tl-none border border-zinc-100 shadow-sm">
              <p className="text-sm text-zinc-800 leading-relaxed">
                Chào bạn, tôi là trợ lý AI. Tôi đã xem qua hồ sơ của bạn và thấy điểm tin cậy đang ở mức 85. Bạn có muốn tôi hướng dẫn cách bổ sung giấy tờ để đạt 95+ không?
              </p>
            </div>
          </div>
        </div>
        <div className="p-6 border-t border-zinc-100">
          <div className="flex gap-4">
            <input 
              type="text" 
              placeholder="Nhập tin nhắn..." 
              className="flex-1 bg-zinc-50 border border-zinc-200 rounded-2xl px-6 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
            <button className="px-8 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all">
              Gửi
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const CustomerSettings = () => {
  return (
    <div className="max-w-4xl space-y-8 pb-20 lg:pb-0">
      <header>
        <h1 className="text-2xl lg:text-3xl font-bold text-zinc-900">Cài đặt tài khoản</h1>
        <p className="text-sm lg:text-base text-zinc-500 mt-1">Quản lý thông tin cá nhân và bảo mật.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-4">
          <nav className="space-y-1">
            {[
              { id: 'profile', label: 'Thông tin cá nhân', icon: UserIcon },
              { id: 'security', label: 'Bảo mật', icon: Lock },
              { id: 'notifications', label: 'Thông báo', icon: Bell },
              { id: 'billing', label: 'Thanh toán', icon: CreditCard },
            ].map(item => (
              <button 
                key={item.id}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                  item.id === 'profile' ? 'bg-zinc-900 text-white shadow-lg shadow-zinc-200' : 'text-zinc-500 hover:bg-zinc-50'
                }`}
              >
                <item.icon size={18} />
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[32px] border border-zinc-200 shadow-sm">
            <h3 className="text-lg font-bold text-zinc-900 mb-6">Thông tin cơ bản</h3>
            <div className="space-y-6">
              <div className="flex items-center gap-6 mb-8">
                <div className="w-20 h-20 rounded-3xl bg-zinc-100 flex items-center justify-center text-3xl border-4 border-white shadow-xl">
                  👨‍💼
                </div>
                <button className="text-xs font-bold text-emerald-600 hover:underline">Thay đổi ảnh đại diện</button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Họ và tên</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="Nguyễn Văn A" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Số điện thoại</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="0987 654 321" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Email</label>
                  <input type="email" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="vana@gmail.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Địa chỉ thường trú</label>
                  <input type="text" className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-sm outline-none" defaultValue="Quận Cầu Giấy, Hà Nội" />
                </div>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t border-zinc-100 flex justify-end">
              <button className="px-8 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all">
                Lưu thay đổi
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
