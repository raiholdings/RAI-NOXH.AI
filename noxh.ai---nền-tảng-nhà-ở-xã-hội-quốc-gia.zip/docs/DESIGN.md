# noxh.ai - National Social Housing Platform Design Document

## 1. Product PRD (Product Requirements Document)

### 1.1. Executive Summary
`noxh.ai` is a centralized platform designed to transparently digitize the entire lifecycle of Social Housing (NOXH) in Vietnam. It connects Government/Consultants, Developers, Citizens (Customers), and Legal Service Providers.

### 1.2. User Roles & JTBD (Jobs-to-be-Done)

| Role | Jobs-to-be-Done |
| :--- | :--- |
| **Consultant (National)** | Regulate the market, verify developers, monitor progress, and ensure compliance with national housing laws. |
| **Developer (Chủ đầu tư)** | Announce projects, manage sales batches, receive and score applications automatically, and communicate with applicants. |
| **Customer (Khách hàng)** | Find suitable projects, get AI guidance on complex paperwork, submit applications online, and track status in real-time. |
| **Service Provider** | Offer legal, financial (banking/loans), or notary services to help customers complete their applications. |

### 1.3. Core Features
- **Project Management**: Developers post project details, units, and eligibility rules.
- **AI Application Assistant**: RAG-based chatbot to guide users through Decree 100/2015/ND-CP and related laws.
- **Doc Intelligence**: OCR and validation of ID cards, residency certificates, and income statements.
- **Marketplace**: Verified providers for notary, banking, and legal aid.
- **Workflow Engine**: State machine for application status (Draft -> Submitted -> Under Review -> Approved -> Contracting).

---

## 2. UX Sitemap & Wireframe Descriptions

### 2.1. Sitemap
- **Home**: Landing page with project search and AI Assistant entry.
- **Dashboard (Role-based)**:
    - **Customer**: My Applications, Document Vault, Recommended Projects, Service Requests.
    - **Developer**: Project Listing, Sales Batch Management, Application Review Queue, Analytics.
    - **Provider**: Service Catalog, Incoming Leads, Active Contracts.
- **Project Detail**: Gallery, Pricing, Eligibility Rules, Timeline, "Apply Now" button.
- **AI Assistant**: Full-screen chat interface with document upload/preview.

### 2.2. Wireframe Descriptions
- **Customer Dashboard**: Minimalist grid showing active application cards with progress bars. A prominent "AI Copilot" floating button.
- **Review Queue (Developer)**: A data-dense table with filters for "Score", "Priority Group", and "Status". Quick action buttons for "Request Info" or "Approve".

---

## 3. System Architecture & Tech Stack

### 3.1. Logical Architecture
- **Frontend**: Next.js (React) + Tailwind CSS + Framer Motion.
- **Backend**: Node.js (Express) with TypeScript.
- **Database**: 
    - **PostgreSQL**: Primary OLTP (Users, Projects, Applications).
    - **Vector DB (Pinecone/Weaviate)**: For RAG (Housing Laws, Project Rules).
- **Storage**: S3-compatible (MinIO/AWS S3) for encrypted document storage.
- **AI Engine**: 
    - **Gemini 2.0 Flash**: For RAG and Chat.
    - **Gemini 2.0 Flash Image**: For OCR/Document Intelligence.
- **Workflow**: Temporal.io for long-running application approval processes.

---

## 4. Data Model & API

### 4.1. Conceptual ERD
- **User**: {id, email, role, kyc_status}
- **Project**: {id, developer_id, name, location, total_units}
- **SaleBatch**: {id, project_id, start_date, end_date, criteria_json}
- **Application**: {id, user_id, batch_id, status, score, metadata}
- **Document**: {id, application_id, type, s3_url, verified_status}

### 4.2. Key API Endpoints
- `POST /api/projects`: Create project (Developer)
- `GET /api/projects/search`: Search with filters (Customer)
- `POST /api/applications/submit`: Submit bundle (Customer)
- `POST /api/ai/chat`: RAG-based assistance
- `POST /api/docs/verify`: Trigger OCR/Validation

---

## 5. AI Design

### 5.1. RAG (Retrieval-Augmented Generation)
- **Data Source**: PDF/Markdown of Law on Housing, Decree 100, Decree 49, and specific Project Handbooks.
- **Guardrails**: System prompt strictly forbids "hallucinations" about eligibility; must cite specific articles.

### 5.2. Document Intelligence
- **Input**: Photos/PDFs of "Giấy xác nhận đối tượng", "Xác nhận cư trú".
- **Logic**: OCR extracts Name, DOB, Address. Cross-references with User Profile and Project Criteria.

---

## 6. Security & Compliance
- **PII Protection**: Encryption at rest (AES-256). Masking of sensitive data in logs.
- **Audit Log**: Immutable ledger of every status change in an application.
- **Digital Signatures**: Integration with VNPT/Viettel CA for legally binding application forms.

---

## 7. MVP Plan (90 Days)
- **Day 1-30**: Core Auth, Project Listing, Simple Application Form.
- **Day 31-60**: AI Copilot (RAG), Document Upload & S3 Integration.
- **Day 61-90**: Developer Dashboard (Review/Score), Basic Marketplace.

---

## 8. Roadmap
- **Phase 2**: Integration with National Population Database (VNeID).
- **Phase 3**: Automated Credit Scoring with Partner Banks.
- **Phase 4**: Blockchain-based Audit Trail for ultimate transparency.
