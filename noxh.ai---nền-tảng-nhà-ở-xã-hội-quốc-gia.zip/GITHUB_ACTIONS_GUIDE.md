# Hướng dẫn cấu hình GitHub Actions cho noxh.ai

## 1. GitHub Container Registry (GHCR)
Workflow sử dụng `GITHUB_TOKEN` mặc định để push image lên GHCR. Bạn cần đảm bảo:
- Repository settings > Actions > General > Workflow permissions được set thành **Read and write permissions**.
- Nếu push lần đầu, bạn có thể cần vào phần **Packages** của user/org để set visibility thành Public hoặc Private.

## 2. GitHub Secrets
Bạn cần cấu hình các secret sau trong repo **noxh-app** (repo code):

| Secret Name | Mô tả |
| :--- | :--- |
| `INFRA_REPO_TOKEN` | Một **Personal Access Token (PAT)** có quyền `repo` để checkout và tạo Pull Request trên repository chứa code Helm/K8s (ví dụ: `noxh-infra`). |

## 3. Cấu trúc Repo Infra (GitOps)
Workflow giả định bạn có một repo riêng tên là `noxh-infra` (hoặc tương tự) chứa các file Helm values. 
- Đường dẫn ví dụ trong workflow: `./charts/noxh-stack/values.yaml`
- Workflow sẽ tự động tạo một branch mới và mở PR vào branch `main` của repo infra mỗi khi có code mới được merge vào `main` của repo app.

## 4. Bảo mật (Trivy)
- Workflow đã tích hợp **Trivy** để scan image. 
- Hiện tại `exit-code` đang để là `0` để không block pipeline nếu có lỗi, bạn nên đổi thành `1` khi đã fix hết các lỗ hổng nghiêm trọng (CRITICAL/HIGH).

## 5. Biến môi trường
- `REGISTRY`: Mặc định là `ghcr.io`. Nếu dùng ECR, hãy đổi thành `<aws_account_id>.dkr.ecr.<region>.amazonaws.com`.
- `IMAGE_NAME_PREFIX`: Mặc định là `<owner>/noxh`.
