from pydantic import BaseModel
from typing import List, Optional

class IndexRequest(BaseModel):
    source: str
    title: str
    text: str

class IndexResponse(BaseModel):
    status: str
    chunks_indexed: int

class AskRequest(BaseModel):
    question: str

class AskResponse(BaseModel):
    answer: str
    citations: List[str]
