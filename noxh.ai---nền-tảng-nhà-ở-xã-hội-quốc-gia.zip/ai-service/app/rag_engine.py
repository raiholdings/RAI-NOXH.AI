from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
from sentence_transformers import SentenceTransformer
import uuid
from .core.config import settings
import logging

logger = logging.getLogger(__name__)

class RAGEngine:
    def __init__(self):
        self.client = QdrantClient(url=settings.QDRANT_URL)
        self.model = SentenceTransformer(settings.EMBEDDING_MODEL_NAME)
        self._ensure_collection()

    def _ensure_collection(self):
        try:
            collections = self.client.get_collections().collections
            exists = any(c.name == settings.QDRANT_COLLECTION for c in collections)
            if not exists:
                self.client.create_collection(
                    collection_name=settings.QDRANT_COLLECTION,
                    vectors_config=qmodels.VectorParams(
                        size=384, # Size for all-MiniLM-L6-v2
                        distance=qmodels.Distance.COSINE
                    )
                )
                logger.info(f"Created collection: {settings.QDRANT_COLLECTION}")
        except Exception as e:
            logger.error(f"Error ensuring collection: {e}")

    def index_document(self, source: str, title: str, text: str):
        # Simple chunking by sentences or fixed length for MVP
        chunks = [text[i:i+500] for i in range(0, len(text), 400)]
        
        points = []
        for chunk in chunks:
            vector = self.model.encode(chunk).tolist()
            point_id = str(uuid.uuid4())
            points.append(qmodels.PointStruct(
                id=point_id,
                vector=vector,
                payload={
                    "source": source,
                    "title": title,
                    "text": chunk
                }
            ))
        
        self.client.upsert(
            collection_name=settings.QDRANT_COLLECTION,
            points=points
        )
        return len(points)

    def query(self, question: str):
        vector = self.model.encode(question).tolist()
        
        search_result = self.client.search(
            collection_name=settings.QDRANT_COLLECTION,
            query_vector=vector,
            limit=settings.TOP_K,
            score_threshold=settings.SIMILARITY_THRESHOLD
        )
        
        if not search_result:
            return None
            
        contexts = []
        sources = []
        for res in search_result:
            contexts.append(res.payload["text"])
            sources.append(f"{res.payload['title']} ({res.payload['source']})")
            
        # MVP Extractive Answer: Combine contexts
        answer = " ".join(contexts)
        unique_sources = list(set(sources))
        
        return {
            "answer": answer,
            "citations": unique_sources
        }

rag_engine = RAGEngine()
