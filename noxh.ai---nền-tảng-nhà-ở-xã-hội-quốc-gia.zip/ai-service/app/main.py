from fastapi import FastAPI, HTTPException
from prometheus_fastapi_instrumentator import Instrumentator
from .schemas import IndexRequest, IndexResponse, AskRequest, AskResponse
from .rag_engine import rag_engine
from .core.config import settings
import logging
import sys
import json
from datetime import datetime

# Logging
class JsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "service": settings.PROJECT_NAME
        })

logger = logging.getLogger()
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
logger.addHandler(handler)
logger.setLevel(logging.INFO)

app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION)

# Metrics
Instrumentator().instrument(app).expose(app)

@app.post(f"{settings.API_V1_STR}/rag/index", response_model=IndexResponse)
async def index_knowledge(req: IndexRequest):
    try:
        count = rag_engine.index_document(req.source, req.title, req.text)
        return {"status": "success", "chunks_indexed": count}
    except Exception as e:
        logger.error(f"Indexing error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post(f"{settings.API_V1_STR}/rag/ask", response_model=AskResponse)
async def ask_question(req: AskRequest):
    result = rag_engine.query(req.question)
    if not result:
        return {
            "answer": "Xin lỗi, tôi không tìm thấy đủ dữ liệu trong kho tri thức để trả lời câu hỏi này.",
            "citations": []
        }
    return result

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

@app.get("/readyz")
def readyz():
    # Check Qdrant connection
    try:
        rag_engine.client.get_collections()
        return {"status": "ready"}
    except Exception:
        raise HTTPException(status_code=503, detail="Qdrant unavailable")
