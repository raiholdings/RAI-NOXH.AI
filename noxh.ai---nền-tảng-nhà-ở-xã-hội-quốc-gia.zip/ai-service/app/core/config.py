from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "noxh-ai-service"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Qdrant
    QDRANT_URL: str = "http://localhost:6333"
    QDRANT_COLLECTION: str = "noxh_knowledge"
    
    # Model
    EMBEDDING_MODEL_NAME: str = "all-MiniLM-L6-v2"
    
    # RAG Config
    TOP_K: int = 3
    SIMILARITY_THRESHOLD: float = 0.5

    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
