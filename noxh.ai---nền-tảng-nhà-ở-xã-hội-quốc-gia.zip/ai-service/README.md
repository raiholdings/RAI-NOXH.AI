# noxh.ai AI Service (MVP RAG)

## Overview
Dịch vụ AI cung cấp khả năng RAG (Retrieval-Augmented Generation) cơ bản. Sử dụng **Qdrant** làm Vector Database và **Sentence-Transformers** để tạo embeddings.

## Features
- **Indexing**: Chuyển đổi văn bản thành vector và lưu vào Qdrant.
- **Retrieval**: Tìm kiếm các đoạn văn bản liên quan nhất dựa trên câu hỏi.
- **Extractive QA**: Trả lời dựa trên ngữ cảnh tìm được kèm theo trích dẫn nguồn.
- **Guardrails**: Trả về thông báo "không đủ dữ liệu" nếu độ tương đồng thấp.

## API Endpoints
- `POST /api/v1/rag/index`: Index tài liệu mới.
- `POST /api/v1/rag/ask`: Hỏi đáp dựa trên kho tri thức.

## Local Setup
1. `pip install -r requirements.txt`
2. Đảm bảo Qdrant đang chạy (mặc định port 6333).
3. `uvicorn app.main:app --reload`
