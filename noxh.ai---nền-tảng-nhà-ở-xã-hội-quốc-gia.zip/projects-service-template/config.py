from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    SERVICE_NAME: str = "projects-service"
    VERSION: str = "1.0.0"
    ENV: str = "development"
    PORT: int = 8000
    LOG_LEVEL: str = "INFO"
    
    DATABASE_URL: Optional[str] = None
    REDIS_URL: Optional[str] = None

    class Config:
        env_file = ".env"

settings = Settings()
