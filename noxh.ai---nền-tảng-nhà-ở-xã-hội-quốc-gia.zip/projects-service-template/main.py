import time
import uuid
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from prometheus_client import make_asgi_app, Counter, Histogram
from .config import settings
from .logging_config import setup_logging

# Setup Logging
logger = setup_logging(settings.LOG_LEVEL)

app = FastAPI(
    title=settings.SERVICE_NAME,
    version=settings.VERSION,
    openapi_url="/openapi.json"
)

# Prometheus Metrics
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

REQUEST_COUNT = Counter("http_requests_total", "Total HTTP Requests", ["method", "endpoint", "status"])
REQUEST_LATENCY = Histogram("http_request_duration_seconds", "HTTP Request Latency", ["method", "endpoint"])

# Middlewares
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_process_time_and_request_id(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    start_time = time.time()
    
    # Inject request_id into logs
    request.state.request_id = request_id
    
    response: Response = await call_next(request)
    
    process_time = (time.time() - start_time) * 1000
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time"] = str(process_time)
    
    # Log request details in JSON
    log_data = {
        "service": settings.SERVICE_NAME,
        "request_id": request_id,
        "path": request.url.path,
        "method": request.method,
        "status": response.status_code,
        "latency_ms": round(process_time, 2)
    }
    logger.info(f"Request processed", extra=log_data)
    
    # Metrics
    REQUEST_COUNT.labels(method=request.method, endpoint=request.url.path, status=response.status_code).inc()
    REQUEST_LATENCY.labels(method=request.method, endpoint=request.url.path).observe(process_time / 1000)
    
    return response

# Endpoints
@app.get("/healthz", tags=["Probes"])
async def healthz():
    return {"status": "ok"}

@app.get("/readyz", tags=["Probes"])
async def readyz():
    # Add DB/Redis check logic here
    return {"status": "ready"}

@app.get("/version", tags=["Metadata"])
async def version():
    return {"service": settings.SERVICE_NAME, "version": settings.VERSION, "env": settings.ENV}

@app.get("/", tags=["Root"])
async def root():
    return {"message": f"Welcome to {settings.SERVICE_NAME}"}
