# Production-Ready FastAPI Service Template: projects-service

## Features
- **JSON Logging**: Structured logs for ELK/Loki.
- **Metrics**: Prometheus `/metrics` endpoint.
- **Probes**: `/healthz` and `/readyz` for K8s.
- **Middleware**: Gzip, CORS, Request ID.
- **Config**: Pydantic Settings (Environment variables).
- **Docker**: Multi-stage build.

## Local Development (Docker)

1. Build the image:
   ```bash
   docker build -t projects-service .
   ```

2. Run the container:
   ```bash
   docker run -p 8000:8000 \
     -e ENV=production \
     -e LOG_LEVEL=INFO \
     projects-service
   ```

3. Access endpoints:
   - API: http://localhost:8000
   - Docs: http://localhost:8000/docs
   - Metrics: http://localhost:8000/metrics
   - Health: http://localhost:8000/healthz

## Testing
Run tests using pytest:
```bash
pytest
```

## Kubernetes Deployment
Apply the manifests:
```bash
kubectl apply -f k8s/manifests.yaml
```
